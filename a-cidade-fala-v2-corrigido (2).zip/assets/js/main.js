/**
 * A Cidade Fala v2.0 - JavaScript Principal
 */

(function() {
    'use strict';

    // ============================================================
    // CONFIGURAÇÃO
    // ============================================================
    const ACF = window.ACF || {
        baseUrl: '',
        apiUrl: '/api'
    };

    // ============================================================
    // UTILITÁRIOS
    // ============================================================
    
    // Debounce
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // Formato de data
    function formatDate(date) {
        const d = new Date(date);
        return d.toLocaleDateString('pt-BR');
    }

    // ============================================================
    // BUSCA EM TEMPO REAL
    // ============================================================
    const searchInput = document.querySelector('.search-input');
    const searchResults = document.createElement('div');
    searchResults.className = 'search-results';
    
    if (searchInput) {
        searchInput.parentElement.style.position = 'relative';
        searchInput.parentElement.appendChild(searchResults);
        
        searchInput.addEventListener('input', debounce(async function() {
            const query = this.value.trim();
            
            if (query.length < 3) {
                searchResults.innerHTML = '';
                searchResults.style.display = 'none';
                return;
            }
            
            try {
                const response = await fetch(`${ACF.apiUrl}/search?q=${encodeURIComponent(query)}`);
                const posts = await response.json();
                
                if (posts.length === 0) {
                    searchResults.innerHTML = '<div class="search-no-results">Nenhum resultado encontrado</div>';
                } else {
                    searchResults.innerHTML = posts.slice(0, 5).map(post => `
                        <a href="${ACF.baseUrl}/${post.tipo}/${post.slug}" class="search-result-item">
                            <span class="search-result-title">${post.titulo}</span>
                            <span class="search-result-type">${post.tipo}</span>
                        </a>
                    `).join('');
                }
                
                searchResults.style.display = 'block';
            } catch (error) {
                console.error('Erro na busca:', error);
            }
        }, 300));
        
        // Fechar resultados ao clicar fora
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.header-search')) {
                searchResults.style.display = 'none';
            }
        });
    }

    // ============================================================
    // LAZY LOADING DE IMAGENS
    // ============================================================
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                    }
                    observer.unobserve(img);
                }
            });
        });

        document.querySelectorAll('img[data-src]').forEach(img => {
            imageObserver.observe(img);
        });
    }

    // ============================================================
    // SCROLL TO TOP
    // ============================================================
    const scrollToTopBtn = document.createElement('button');
    scrollToTopBtn.className = 'scroll-to-top';
    scrollToTopBtn.innerHTML = '<i class="lucide-chevron-up"></i>';
    scrollToTopBtn.setAttribute('aria-label', 'Voltar ao topo');
    document.body.appendChild(scrollToTopBtn);

    window.addEventListener('scroll', function() {
        if (window.scrollY > 300) {
            scrollToTopBtn.classList.add('visible');
        } else {
            scrollToTopBtn.classList.remove('visible');
        }
    });

    scrollToTopBtn.addEventListener('click', function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    // ============================================================
    // COMPARTILHAMENTO
    // ============================================================
    document.querySelectorAll('[data-share]').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const network = this.dataset.share;
            const url = encodeURIComponent(window.location.href);
            const title = encodeURIComponent(document.title);
            
            let shareUrl = '';
            switch(network) {
                case 'facebook':
                    shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${url}`;
                    break;
                case 'twitter':
                    shareUrl = `https://twitter.com/intent/tweet?text=${title}&url=${url}`;
                    break;
                case 'whatsapp':
                    shareUrl = `https://wa.me/?text=${title}%20${url}`;
                    break;
                case 'telegram':
                    shareUrl = `https://t.me/share/url?url=${url}&text=${title}`;
                    break;
                case 'linkedin':
                    shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${url}`;
                    break;
            }
            
            if (shareUrl) {
                window.open(shareUrl, '_blank', 'width=600,height=400');
            }
        });
    });

    // ============================================================
    // MÁSCARAS DE INPUT
    // ============================================================
    document.querySelectorAll('input[type="tel"]').forEach(input => {
        input.addEventListener('input', function() {
            let value = this.value.replace(/\D/g, '');
            if (value.length <= 11) {
                if (value.length > 2) {
                    value = '(' + value.substring(0, 2) + ') ' + value.substring(2);
                }
                if (value.length > 10) {
                    value = value.substring(0, 10) + '-' + value.substring(10);
                }
            }
            this.value = value;
        });
    });

    // ============================================================
    // CONFIRMAÇÃO DE AÇÕES
    // ============================================================
    document.querySelectorAll('[data-confirm]').forEach(element => {
        element.addEventListener('click', function(e) {
            const message = this.dataset.confirm || 'Tem certeza?';
            if (!confirm(message)) {
                e.preventDefault();
                e.stopPropagation();
            }
        });
    });

    // ============================================================
    // LOADING STATE PARA FORMS
    // ============================================================
    document.querySelectorAll('form[data-ajax]').forEach(form => {
        form.addEventListener('submit', function() {
            const btn = this.querySelector('button[type="submit"]');
            if (btn) {
                btn.disabled = true;
                btn.dataset.originalText = btn.innerHTML;
                btn.innerHTML = '<i class="lucide-loader-2" style="animation:spin 1s linear infinite;"></i> Aguarde...';
            }
        });
    });

    // ============================================================
    // STICKY HEADER
    // ============================================================
    let lastScroll = 0;
    const header = document.querySelector('.site-header');
    
    if (header) {
        window.addEventListener('scroll', function() {
            const currentScroll = window.scrollY;
            
            if (currentScroll > 100) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
            
            lastScroll = currentScroll;
        });
    }

    // ============================================================
    // DARK MODE
    // ============================================================
    function setTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('theme', theme);
        
        const icon = document.querySelector('.theme-toggle i');
        if (icon) {
            icon.className = theme === 'dark' ? 'lucide-sun' : 'lucide-moon';
        }
    }

    // Aplicar tema salvo
    const savedTheme = localStorage.getItem('theme') || 'light';
    setTheme(savedTheme);

    // Toggle theme
    window.toggleTheme = function() {
        const current = document.documentElement.getAttribute('data-theme');
        setTheme(current === 'dark' ? 'light' : 'dark');
    };

    // ============================================================
    // NEWSLETTER FORM
    // ============================================================
    const newsletterForm = document.getElementById('newsletterForm');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const email = this.querySelector('input[type="email"]').value;
            const btn = this.querySelector('button[type="submit"]');
            
            btn.disabled = true;
            
            try {
                const response = await fetch(`${ACF.apiUrl}/newsletter`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `email=${encodeURIComponent(email)}`
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showToast('Inscrição realizada com sucesso!', 'success');
                    this.reset();
                } else {
                    showToast(result.error || 'Erro ao inscrever', 'error');
                }
            } catch (error) {
                showToast('Erro de conexão', 'error');
            }
            
            btn.disabled = false;
        });
    }

    // ============================================================
    // CONTADOR DE CARACTERES
    // ============================================================
    document.querySelectorAll('[data-maxlength]').forEach(input => {
        const max = parseInt(input.dataset.maxlength);
        const counter = document.createElement('span');
        counter.className = 'char-counter';
        counter.textContent = `0/${max}`;
        input.parentElement.appendChild(counter);
        
        input.addEventListener('input', function() {
            counter.textContent = `${this.value.length}/${max}`;
            counter.style.color = this.value.length > max * 0.9 ? 'var(--color-error)' : '';
        });
    });

    // ============================================================
    // INICIALIZAÇÃO
    // ============================================================
    console.log('A Cidade Fala v2.0 - Carregado');

})();

// Estilos CSS inline para componentes JS
const style = document.createElement('style');
style.textContent = `
    .search-results {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: var(--color-white);
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow-xl);
        margin-top: var(--space-2);
        display: none;
        z-index: 1000;
        max-height: 300px;
        overflow-y: auto;
    }
    
    .search-result-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: var(--space-3) var(--space-4);
        border-bottom: 1px solid var(--color-border);
        color: var(--color-gray-700);
        text-decoration: none;
    }
    
    .search-result-item:hover {
        background: var(--color-gray-50);
    }
    
    .search-result-title {
        font-weight: var(--font-medium);
    }
    
    .search-result-type {
        font-size: var(--text-xs);
        color: var(--color-gray-500);
        text-transform: uppercase;
    }
    
    .search-no-results {
        padding: var(--space-4);
        text-align: center;
        color: var(--color-gray-500);
    }
    
    .scroll-to-top {
        position: fixed;
        bottom: var(--space-6);
        right: var(--space-6);
        width: 48px;
        height: 48px;
        background: var(--color-primary);
        color: var(--color-white);
        border: none;
        border-radius: var(--radius-full);
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: var(--shadow-lg);
        opacity: 0;
        visibility: hidden;
        transition: all var(--transition-fast);
        z-index: 1000;
    }
    
    .scroll-to-top.visible {
        opacity: 1;
        visibility: visible;
    }
    
    .scroll-to-top:hover {
        transform: translateY(-4px);
    }
    
    .site-header.scrolled {
        box-shadow: var(--shadow-md);
    }
    
    @keyframes spin {
        to { transform: rotate(360deg); }
    }
`;
document.head.appendChild(style);
