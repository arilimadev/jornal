<?php
/**
 * A Cidade Fala v2.0 - Portal de Jornalismo Colaborativo
 * Arquivo de entrada da aplicação
 */

// Exibir erros durante desenvolvimento
error_reporting(E_ALL);
ini_set('display_errors', '1');

// Definir caminho base
define('BASE_PATH', __DIR__);
define('SRC_PATH', BASE_PATH . '/src');

// Autoload simples
spl_autoload_register(function ($class) {
    $class = str_replace('ACidadeFala\\', '', $class);
    $class = str_replace('\\', '/', $class);
    $file = SRC_PATH . '/' . $class . '.php';
    if (file_exists($file)) {
        require_once $file;
        return true;
    }
    return false;
});

// Verificar se arquivos existem
$requiredFiles = [
    SRC_PATH . '/Config/Config.php',
    SRC_PATH . '/Config/Database.php',
    SRC_PATH . '/Config/SupabaseAuth.php',
    SRC_PATH . '/Router.php'
];

foreach ($requiredFiles as $file) {
    if (!file_exists($file)) {
        die("Erro: Arquivo não encontrado - " . basename($file));
    }
}

// Carregar configurações
require_once SRC_PATH . '/Config/Config.php';
require_once SRC_PATH . '/Config/Database.php';
require_once SRC_PATH . '/Config/SupabaseAuth.php';

// Inicializar configurações
use ACidadeFala\Config\Config;
Config::init();

// Carregar funções helper globais
require_once SRC_PATH . '/helpers.php';

// Carregar Router e executar
require_once SRC_PATH . '/Router.php';

try {
    $router = new \ACidadeFala\Router();
    $router->handle();
} catch (Exception $e) {
    if (Config::DEBUG_MODE) {
        echo "<pre>Erro: " . $e->getMessage() . "\n" . $e->getTraceAsString() . "</pre>";
    } else {
        http_response_code(500);
        echo "Erro interno do servidor";
    }
}
