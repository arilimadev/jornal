<?php
/**
 * A Cidade Fala v2.0 - Funções Helper
 */

use ACidadeFala\Config\Config;

// Data por extenso em português
if (!function_exists('dataExtenso')) {
    function dataExtenso($timestamp = null) {
        $timestamp = $timestamp ?? time();
        
        $diasSemana = [
            'Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira',
            'Quinta-feira', 'Sexta-feira', 'Sábado'
        ];
        
        $meses = [
            1 => 'janeiro', 2 => 'fevereiro', 3 => 'março', 4 => 'abril',
            5 => 'maio', 6 => 'junho', 7 => 'julho', 8 => 'agosto',
            9 => 'setembro', 10 => 'outubro', 11 => 'novembro', 12 => 'dezembro'
        ];
        
        $diaSemana = $diasSemana[date('w', $timestamp)];
        $dia = date('d', $timestamp);
        $mes = $meses[(int)date('n', $timestamp)];
        $ano = date('Y', $timestamp);
        
        return "{$diaSemana}, {$dia} de {$mes} de {$ano}";
    }
}

// Escape HTML
if (!function_exists('e')) {
    function e($string) {
        return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
    }
}

// URL base
if (!function_exists('url')) {
    function url($path = '') {
        return Config::getBaseUrl() . '/' . ltrim($path, '/');
    }
}

// Assets URL
if (!function_exists('asset')) {
    function asset($path) {
        return Config::getBaseUrl() . '/assets/' . ltrim($path, '/');
    }
}

// Upload URL
if (!function_exists('upload')) {
    function upload($path) {
        return Config::getBaseUrl() . '/uploads/' . ltrim($path, '/');
    }
}

// Time ago
if (!function_exists('timeAgo')) {
    function timeAgo($datetime) {
        return Config::timeAgo($datetime);
    }
}

// Format date
if (!function_exists('formatDate')) {
    function formatDate($date, $format = 'd/m/Y') {
        return Config::formatDate($date, $format);
    }
}

// URL para post
if (!function_exists('postUrl')) {
    function postUrl($post) {
        // Se temos estado_uf e cidade_slug diretamente no post
        if (!empty($post['estado_uf']) && !empty($post['cidade_slug'])) {
            return url($post['estado_uf'] . '/' . $post['cidade_slug'] . '/' . $post['slug']);
        }
        
        // Caso contrário, precisa buscar do banco
        $db = \ACidadeFala\Config\Database::getInstance();
        
        if (!empty($post['cidade_id'])) {
            $cidade = $db->select('cidades', ['id' => $post['cidade_id']], 1);
            if (!empty($cidade)) {
                $cidade = $cidade[0];
                $estado = $db->select('estados', ['id' => $cidade['estado_id']], 1);
                if (!empty($estado)) {
                    return url($estado[0]['uf'] . '/' . $cidade['slug'] . '/' . $post['slug']);
                }
            }
        }
        
        // Fallback - não deveria acontecer
        return url('post/' . $post['slug']);
    }
}

// Purificar HTML - permite tags seguras
if (!function_exists('purifyHtml')) {
    function purifyHtml($html) {
        if (empty($html)) return '';
        
        // Tags permitidas
        $allowedTags = '<p><br><strong><b><em><i><u><h1><h2><h3><h4><h5><h6><ul><ol><li><a><img><blockquote><pre><code><hr><table><thead><tbody><tr><th><td><figure><figcaption><div><span>';
        
        // Remove scripts e eventos
        $html = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', '', $html);
        $html = preg_replace('/\s+on\w+\s*=\s*["\'][^"\']*["\']/i', '', $html);
        $html = preg_replace('/\s+on\w+\s*=\s*[^\s>]*/i', '', $html);
        
        // Remove javascript: em href/src
        $html = preg_replace('/href\s*=\s*["\']?\s*javascript:[^"\'>\s]*/i', 'href="#"', $html);
        $html = preg_replace('/src\s*=\s*["\']?\s*javascript:[^"\'>\s]*/i', 'src=""', $html);
        
        // Aplica strip_tags com tags permitidas
        $html = strip_tags($html, $allowedTags);
        
        return $html;
    }
}
