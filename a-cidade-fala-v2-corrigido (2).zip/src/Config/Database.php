<?php
/**
 * A Cidade Fala v2.0 - Conexão Supabase via REST API
 */

namespace ACidadeFala\Config;

class Database {
    private static $instance = null;
    
    private $supabaseUrl;
    private $supabaseKey;
    private $supabaseServiceKey;
    private $lastError = null;
    
    private function __construct() {
        // Configurações do Supabase - ALTERE PARA SUAS CREDENCIAIS
        $this->supabaseUrl = 'https://ydegyrhmqprtfrdcsgwy.supabase.co';
        $this->supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlkZWd5cmhtcXBydGZyZGNzZ3d5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjgyNDUzNzksImV4cCI6MjA4MzgyMTM3OX0.nUI07zt4YxrufA2y5FL5GXdYw8XlzdLyuUijKKHrPx8';
        $this->supabaseServiceKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlkZWd5cmhtcXBydGZyZGNzZ3d5Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2ODI0NTM3OSwiZXhwIjoyMDgzODIxMzc5fQ.2N6ifXtVDeVlu2xy62l_pLxalO0TSOLHtC8bwipBM84';
    }
    
    public static function getInstance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getLastError(): ?string {
        return $this->lastError;
    }
    
    public function getConnection() {
        return $this;
    }
    
    public function getSupabaseUrl(): string {
        return $this->supabaseUrl;
    }
    
    public function getSupabaseKey(): string {
        return $this->supabaseKey;
    }
    
    /**
     * SELECT - Buscar dados
     */
    public function select(string $table, array $where = [], ?int $limit = null, int $offset = 0, array $order = [], string $select = '*'): array {
        $url = "{$this->supabaseUrl}/rest/v1/{$table}?select={$select}&";
        
        // Filtros WHERE
        foreach ($where as $key => $value) {
            if (is_array($value)) {
                // Operador customizado: ['operator' => 'in', 'value' => '(1,2,3)']
                if (isset($value['operator'])) {
                    $url .= "{$key}={$value['operator']}.{$value['value']}&";
                } else {
                    // Array simples com operador e valor
                    $url .= "{$key}={$value[0]}." . urlencode($value[1]) . '&';
                }
            } elseif ($value === null) {
                $url .= "{$key}=is.null&";
            } else {
                $url .= "{$key}=eq." . urlencode($value) . '&';
            }
        }
        
        // Ordenação
        if (!empty($order)) {
            $orderParts = [];
            foreach ($order as $column => $direction) {
                $orderParts[] = "{$column}." . strtolower($direction);
            }
            $url .= "order=" . implode(',', $orderParts) . '&';
        }
        
        // Limit e Offset
        if ($limit !== null) {
            $url .= "limit={$limit}&";
        }
        if ($offset > 0) {
            $url .= "offset={$offset}&";
        }
        
        $url = rtrim($url, '&?');
        
        $result = $this->request('GET', $url);
        return $result ?? [];
    }
    
    /**
     * SELECT com JOIN (usando foreign key)
     */
    public function selectWithJoin(string $table, string $select, array $where = [], ?int $limit = null, array $order = []): array {
        $url = "{$this->supabaseUrl}/rest/v1/{$table}?select=" . urlencode($select) . "&";
        
        foreach ($where as $key => $value) {
            if (is_array($value)) {
                $url .= "{$key}={$value[0]}." . urlencode($value[1]) . '&';
            } elseif ($value === null) {
                $url .= "{$key}=is.null&";
            } else {
                $url .= "{$key}=eq." . urlencode($value) . '&';
            }
        }
        
        if (!empty($order)) {
            $orderParts = [];
            foreach ($order as $column => $direction) {
                $orderParts[] = "{$column}." . strtolower($direction);
            }
            $url .= "order=" . implode(',', $orderParts) . '&';
        }
        
        if ($limit !== null) {
            $url .= "limit={$limit}&";
        }
        
        $url = rtrim($url, '&?');
        
        $result = $this->request('GET', $url);
        return $result ?? [];
    }
    
    /**
     * SELECT com busca textual (ILIKE)
     */
    public function search(string $table, string $column, string $term, ?int $limit = null, array $order = []): array {
        $url = "{$this->supabaseUrl}/rest/v1/{$table}?{$column}=ilike.*" . urlencode($term) . "*&";
        
        if (!empty($order)) {
            $orderParts = [];
            foreach ($order as $col => $direction) {
                $orderParts[] = "{$col}." . strtolower($direction);
            }
            $url .= "order=" . implode(',', $orderParts) . '&';
        }
        
        if ($limit !== null) {
            $url .= "limit={$limit}&";
        }
        
        $url = rtrim($url, '&?');
        
        $result = $this->request('GET', $url);
        return $result ?? [];
    }
    
    /**
     * COUNT - Contar registros
     */
    public function count(string $table, array $where = []): int {
        $url = "{$this->supabaseUrl}/rest/v1/{$table}?select=count&";
        
        foreach ($where as $key => $value) {
            if (is_array($value)) {
                $url .= "{$key}={$value[0]}." . urlencode($value[1]) . '&';
            } elseif ($value === null) {
                $url .= "{$key}=is.null&";
            } else {
                $url .= "{$key}=eq." . urlencode($value) . '&';
            }
        }
        
        $url = rtrim($url, '&?');
        
        $result = $this->request('GET', $url, null, [
            'Prefer' => 'count=exact'
        ], true);
        
        return $result['count'] ?? 0;
    }
    
    /**
     * INSERT - Inserir dados
     */
    public function insert(string $table, array $data, bool $useServiceKey = false): ?array {
        $url = "{$this->supabaseUrl}/rest/v1/{$table}";
        $result = $this->request('POST', $url, $data, ['Prefer' => 'return=representation']);
        return $result[0] ?? null;
    }
    
    /**
     * INSERT múltiplo
     */
    public function insertMany(string $table, array $data): ?array {
        $url = "{$this->supabaseUrl}/rest/v1/{$table}";
        $result = $this->request('POST', $url, $data, ['Prefer' => 'return=representation']);
        return $result ?? null;
    }
    
    /**
     * UPDATE - Atualizar dados
     */
    public function update(string $table, array $data, array $where): bool {
        $url = "{$this->supabaseUrl}/rest/v1/{$table}?";
        
        foreach ($where as $key => $value) {
            if ($value === null) {
                $url .= "{$key}=is.null&";
            } else {
                $url .= "{$key}=eq." . urlencode($value) . '&';
            }
        }
        
        $url = rtrim($url, '&');
        $result = $this->request('PATCH', $url, $data);
        
        return $result !== null;
    }
    
    /**
     * UPDATE com retorno dos dados atualizados
     */
    public function updateReturning(string $table, array $data, array $where): ?array {
        $url = "{$this->supabaseUrl}/rest/v1/{$table}?";
        
        foreach ($where as $key => $value) {
            if ($value === null) {
                $url .= "{$key}=is.null&";
            } else {
                $url .= "{$key}=eq." . urlencode($value) . '&';
            }
        }
        
        $url = rtrim($url, '&');
        $result = $this->request('PATCH', $url, $data, ['Prefer' => 'return=representation']);
        
        return $result[0] ?? null;
    }
    
    /**
     * DELETE - Deletar dados
     */
    public function delete(string $table, array $where): bool {
        $url = "{$this->supabaseUrl}/rest/v1/{$table}?";
        
        foreach ($where as $key => $value) {
            if ($value === null) {
                $url .= "{$key}=is.null&";
            } else {
                $url .= "{$key}=eq." . urlencode($value) . '&';
            }
        }
        
        $url = rtrim($url, '&');
        $result = $this->request('DELETE', $url);
        
        return $result !== null;
    }
    
    /**
     * UPSERT - Inserir ou atualizar
     */
    public function upsert(string $table, array $data, string $onConflict = 'id'): ?array {
        $url = "{$this->supabaseUrl}/rest/v1/{$table}?on_conflict={$onConflict}";
        $result = $this->request('POST', $url, $data, [
            'Prefer' => 'return=representation,resolution=merge-duplicates'
        ]);
        return $result[0] ?? null;
    }
    
    /**
     * RPC - Chamar função SQL
     */
    public function rpc(string $functionName, array $params = []): array {
        $url = "{$this->supabaseUrl}/rest/v1/rpc/{$functionName}";
        $result = $this->request('POST', $url, $params);
        return $result ?? [];
    }
    
    /**
     * Requisição HTTP genérica
     */
    private function request(string $method, string $url, ?array $data = null, array $extraHeaders = [], bool $getCount = false): ?array {
        $ch = curl_init($url);
        
        // Usar SERVICE KEY para bypass RLS
        $headers = [
            'apikey: ' . $this->supabaseServiceKey,
            'Authorization: Bearer ' . $this->supabaseServiceKey,
            'Content-Type: application/json'
        ];
        
        foreach ($extraHeaders as $key => $value) {
            $headers[] = "{$key}: {$value}";
        }
        
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_HEADER, $getCount);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        
        if ($data !== null && in_array($method, ['POST', 'PATCH', 'PUT'])) {
            $jsonData = json_encode($data);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
        }
        
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        
        // Se houver erro de curl
        if ($curlError) {
            $this->lastError = "CURL Error: " . $curlError;
            curl_close($ch);
            return null;
        }
        
        if ($getCount) {
            $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            $headersStr = substr($response, 0, $headerSize);
            $body = substr($response, $headerSize);
            
            // Extrair count do header Content-Range
            preg_match('/content-range: \d+-\d+\/(\d+)/i', $headersStr, $matches);
            $count = isset($matches[1]) ? (int)$matches[1] : 0;
            
            curl_close($ch);
            return ['count' => $count, 'data' => json_decode($body, true)];
        }
        
        curl_close($ch);
        
        if ($httpCode >= 200 && $httpCode < 300) {
            $this->lastError = null;
            $decoded = json_decode($response, true);
            return $decoded ?? [];
        }
        
        // Capturar erro detalhado
        $decoded = json_decode($response, true);
        if ($decoded) {
            $this->lastError = $decoded['message'] ?? $decoded['error'] ?? $decoded['msg'] ?? json_encode($decoded);
        } else {
            // Resposta não é JSON (pode ser HTML de erro)
            $this->lastError = "HTTP {$httpCode} - URL: {$url}";
        }
        
        return null;
    }
    
    // ==========================================
    // MÉTODOS DE COMPATIBILIDADE SQL
    // ==========================================
    
    /**
     * fetchAll - Executar query SQL via RPC
     * @param string $sql Query SQL
     * @param array $params Parâmetros (opcional)
     * @return array
     */
    public function fetchAll(string $sql, array $params = []): array {
        // Substituir placeholders ? por valores
        $sql = $this->interpolateQuery($sql, $params);
        
        // Chamar função RPC do Supabase
        $result = $this->rpc('execute_sql', ['query_text' => $sql]);
        
        return $result ?? [];
    }
    
    /**
     * fetchOne - Buscar apenas um registro
     * @param string $sql Query SQL
     * @param array $params Parâmetros (opcional)
     * @return array|null
     */
    public function fetchOne(string $sql, array $params = []): ?array {
        // Adicionar LIMIT 1 se não tiver
        if (stripos($sql, 'LIMIT') === false) {
            $sql = rtrim($sql, ';') . ' LIMIT 1';
        }
        
        $result = $this->fetchAll($sql, $params);
        return $result[0] ?? null;
    }
    
    /**
     * query - Executar query sem retorno (INSERT, UPDATE, DELETE)
     * @param string $sql Query SQL
     * @param array $params Parâmetros (opcional)
     * @return bool
     */
    public function query(string $sql, array $params = []): bool {
        $sql = $this->interpolateQuery($sql, $params);
        
        $result = $this->rpc('execute_sql', ['query_text' => $sql]);
        
        return $result !== null;
    }
    
    /**
     * Interpolar query substituindo ? por valores
     */
    private function interpolateQuery(string $sql, array $params): string {
        if (empty($params)) {
            return $sql;
        }
        
        $parts = explode('?', $sql);
        $result = '';
        
        foreach ($parts as $i => $part) {
            $result .= $part;
            if (isset($params[$i])) {
                $value = $params[$i];
                if ($value === null) {
                    $result .= 'NULL';
                } elseif (is_bool($value)) {
                    $result .= $value ? 'TRUE' : 'FALSE';
                } elseif (is_int($value) || is_float($value)) {
                    $result .= $value;
                } else {
                    // Escapar string
                    $result .= "'" . str_replace("'", "''", $value) . "'";
                }
            }
        }
        
        return $result;
    }
    
    private function __clone() {}
    
    public function __wakeup() {
        throw new \Exception("Cannot unserialize");
    }
}
