<?php
/**
 * A Cidade Fala v2.0 - Supabase Authentication
 */

namespace ACidadeFala\Config;

class SupabaseAuth {
    private $supabaseUrl;
    private $supabaseKey;
    private $supabaseServiceKey;
    
    public function __construct() {
        $this->supabaseUrl = 'https://ydegyrhmqprtfrdcsgwy.supabase.co';
        $this->supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlkZWd5cmhtcXBydGZyZGNzZ3d5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjgyNDUzNzksImV4cCI6MjA4MzgyMTM3OX0.nUI07zt4YxrufA2y5FL5GXdYw8XlzdLyuUijKKHrPx8';
        $this->supabaseServiceKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlkZWd5cmhtcXBydGZyZGNzZ3d5Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2ODI0NTM3OSwiZXhwIjoyMDgzODIxMzc5fQ.2N6ifXtVDeVlu2xy62l_pLxalO0TSOLHtC8bwipBM84';
    }
    
    /**
     * Registrar novo usuário
     */
    public function signUp(string $email, string $password, array $metadata = []): array {
        $url = "{$this->supabaseUrl}/auth/v1/signup";
        
        $data = [
            'email' => $email,
            'password' => $password
        ];
        
        // Só adiciona data se tiver metadata (e como objeto, não array)
        if (!empty($metadata)) {
            $data['data'] = (object) $metadata;
        }
        
        $response = $this->request('POST', $url, $data);
        
        if ($response && isset($response['user'])) {
            return [
                'success' => true,
                'user' => $response['user'],
                'session' => $response['session'] ?? null
            ];
        }
        
        return [
            'success' => false,
            'error' => $response['error_description'] ?? $response['msg'] ?? $response['message'] ?? 'Erro ao criar conta'
        ];
    }
    
    /**
     * Login com email e senha
     */
    public function signIn(string $email, string $password): array {
        $url = "{$this->supabaseUrl}/auth/v1/token?grant_type=password";
        
        $data = [
            'email' => $email,
            'password' => $password
        ];
        
        $response = $this->request('POST', $url, $data);
        
        if ($response && isset($response['access_token'])) {
            return [
                'success' => true,
                'user' => $response['user'],
                'access_token' => $response['access_token'],
                'refresh_token' => $response['refresh_token'],
                'expires_in' => $response['expires_in'] ?? 3600
            ];
        }
        
        return [
            'success' => false,
            'error' => $response['error_description'] ?? $response['msg'] ?? $response['message'] ?? 'Email ou senha inválidos'
        ];
    }
    
    /**
     * Obter usuário pelo token
     */
    public function getUser(string $accessToken): ?array {
        $url = "{$this->supabaseUrl}/auth/v1/user";
        
        return $this->request('GET', $url, null, [
            'Authorization' => "Bearer {$accessToken}"
        ]);
    }
    
    /**
     * Logout (revoga o token)
     */
    public function signOut(string $accessToken): bool {
        $url = "{$this->supabaseUrl}/auth/v1/logout";
        
        $response = $this->request('POST', $url, null, [
            'Authorization' => "Bearer {$accessToken}"
        ]);
        
        return $response !== null;
    }
    
    /**
     * Atualizar usuário
     */
    public function updateUser(string $accessToken, array $updates): ?array {
        $url = "{$this->supabaseUrl}/auth/v1/user";
        
        return $this->request('PUT', $url, $updates, [
            'Authorization' => "Bearer {$accessToken}"
        ]);
    }
    
    /**
     * Atualizar senha
     */
    public function updatePassword(string $accessToken, string $newPassword): array {
        $url = "{$this->supabaseUrl}/auth/v1/user";
        
        $response = $this->request('PUT', $url, ['password' => $newPassword], [
            'Authorization' => "Bearer {$accessToken}"
        ]);
        
        if ($response && isset($response['id'])) {
            return ['success' => true];
        }
        
        return [
            'success' => false,
            'error' => $response['error_description'] ?? $response['msg'] ?? 'Erro ao atualizar senha'
        ];
    }
    
    /**
     * Solicitar reset de senha
     */
    public function resetPasswordRequest(string $email, string $redirectTo = ''): bool {
        $url = "{$this->supabaseUrl}/auth/v1/recover";
        
        $data = ['email' => $email];
        if ($redirectTo) {
            $data['redirect_to'] = $redirectTo;
        }
        
        $response = $this->request('POST', $url, $data);
        
        return $response !== null && !isset($response['error']);
    }
    
    /**
     * Verificar email
     */
    public function verifyEmail(string $token, string $type = 'signup'): array {
        $url = "{$this->supabaseUrl}/auth/v1/verify";
        
        $data = [
            'token' => $token,
            'type' => $type
        ];
        
        $response = $this->request('POST', $url, $data);
        
        if ($response && isset($response['access_token'])) {
            return [
                'success' => true,
                'user' => $response['user'],
                'access_token' => $response['access_token']
            ];
        }
        
        return [
            'success' => false,
            'error' => $response['error_description'] ?? 'Token inválido ou expirado'
        ];
    }
    
    /**
     * Refresh token
     */
    public function refreshToken(string $refreshToken): ?array {
        $url = "{$this->supabaseUrl}/auth/v1/token?grant_type=refresh_token";
        
        $data = ['refresh_token' => $refreshToken];
        
        $response = $this->request('POST', $url, $data);
        
        if ($response && isset($response['access_token'])) {
            return [
                'success' => true,
                'access_token' => $response['access_token'],
                'refresh_token' => $response['refresh_token'],
                'user' => $response['user']
            ];
        }
        
        return null;
    }
    
    /**
     * Criar usuário via Admin API (sem confirmação de email)
     */
    public function adminCreateUser(string $email, string $password, array $metadata = [], bool $emailConfirm = true): array {
        $url = "{$this->supabaseUrl}/auth/v1/admin/users";
        
        $data = [
            'email' => $email,
            'password' => $password,
            'email_confirm' => $emailConfirm,
            'user_metadata' => $metadata
        ];
        
        $response = $this->request('POST', $url, $data, [
            'Authorization' => "Bearer {$this->supabaseServiceKey}"
        ]);
        
        if ($response && isset($response['id'])) {
            return [
                'success' => true,
                'user' => $response
            ];
        }
        
        return [
            'success' => false,
            'error' => $response['error_description'] ?? $response['msg'] ?? 'Erro ao criar usuário'
        ];
    }
    
    /**
     * Deletar usuário via Admin API
     */
    public function adminDeleteUser(string $userId): bool {
        $url = "{$this->supabaseUrl}/auth/v1/admin/users/{$userId}";
        
        $response = $this->request('DELETE', $url, null, [
            'Authorization' => "Bearer {$this->supabaseServiceKey}"
        ]);
        
        return $response !== null;
    }
    
    /**
     * Atualizar usuário via Admin API
     */
    public function adminUpdateUser(string $userId, array $updates): ?array {
        $url = "{$this->supabaseUrl}/auth/v1/admin/users/{$userId}";
        
        return $this->request('PUT', $url, $updates, [
            'Authorization' => "Bearer {$this->supabaseServiceKey}"
        ]);
    }
    
    /**
     * Requisição HTTP
     */
    private function request(string $method, string $url, ?array $data = null, array $extraHeaders = []): ?array {
        $ch = curl_init($url);
        
        $headers = [
            'apikey: ' . $this->supabaseKey,
            'Content-Type: application/json'
        ];
        
        foreach ($extraHeaders as $key => $value) {
            $headers[] = "{$key}: {$value}";
        }
        
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        
        if ($data !== null && in_array($method, ['POST', 'PUT', 'PATCH'])) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
        
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        $decoded = json_decode($response, true);
        
        if ($httpCode >= 200 && $httpCode < 300) {
            return $decoded ?? [];
        }
        
        if (Config::DEBUG_MODE) {
            error_log("Supabase Auth Error {$httpCode}: {$response}");
        }
        
        return $decoded;
    }
    
    private function __clone() {}
    
    public function __wakeup() {
        throw new \Exception("Cannot unserialize");
    }
}
