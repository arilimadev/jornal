<?php
/**
 * A Cidade Fala v2.0 - Página 404
 */

use ACidadeFala\Config\Config;

$pageTitle = "Página não encontrada";

ob_start();
?>

<style>
.error-page {
    min-height: calc(100vh - 300px);
    display: flex;
    align-items: center;
    justify-content: center;
    padding: var(--space-8);
    text-align: center;
}

.error-content {
    max-width: 500px;
}

.error-code {
    font-size: 120px;
    font-weight: var(--font-extrabold);
    line-height: 1;
    background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-secondary) 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: var(--space-4);
}

.error-title {
    font-size: var(--text-2xl);
    margin-bottom: var(--space-4);
}

.error-message {
    color: var(--color-gray-600);
    margin-bottom: var(--space-8);
    line-height: var(--leading-relaxed);
}

.error-actions {
    display: flex;
    gap: var(--space-4);
    justify-content: center;
    flex-wrap: wrap;
}
</style>

<div class="error-page">
    <div class="error-content">
        <div class="error-code">404</div>
        <h1 class="error-title">Página não encontrada</h1>
        <p class="error-message">
            <?= e($message ?? 'A página que você está procurando não existe ou foi movida.') ?>
        </p>
        <div class="error-actions">
            <a href="<?= url('/') ?>" class="btn btn-primary">
                <i class="lucide-home"></i> Ir para o Início
            </a>
            <button onclick="history.back()" class="btn btn-outline">
                <i class="lucide-arrow-left"></i> Voltar
            </button>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../partials/layout.php';
?>
