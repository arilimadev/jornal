<?php
use ACidadeFala\Config\Config;
$pageTitle = "Sobre Nós";
ob_start();
?>

<div class="container" style="padding:var(--space-12) 0;">
    <div style="max-width:800px;margin:0 auto;">
        <h1 style="font-size:var(--text-4xl);margin-bottom:var(--space-6);">Sobre o <?= e(Config::SITE_NAME) ?></h1>
        
        <div style="font-size:var(--text-lg);line-height:var(--leading-relaxed);color:var(--color-gray-700);">
            <p style="margin-bottom:var(--space-6);">
                O <strong><?= e(Config::SITE_NAME) ?></strong> é uma plataforma de jornalismo colaborativo que conecta cidadãos 
                com as notícias mais relevantes de sua comunidade local.
            </p>
            
            <h2 style="font-size:var(--text-2xl);margin:var(--space-8) 0 var(--space-4);">Nossa Missão</h2>
            <p style="margin-bottom:var(--space-6);">
                Democratizar o acesso à informação local, permitindo que qualquer cidadão possa contribuir com notícias, 
                opiniões e denúncias relevantes para sua cidade, fortalecendo a transparência e a participação cidadã.
            </p>
            
            <h2 style="font-size:var(--text-2xl);margin:var(--space-8) 0 var(--space-4);">Nossos Valores</h2>
            <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(200px, 1fr));gap:var(--space-6);margin-bottom:var(--space-8);">
                <div style="background:var(--color-gray-50);padding:var(--space-6);border-radius:var(--radius-xl);text-align:center;">
                    <div style="font-size:32px;margin-bottom:var(--space-3);">🎯</div>
                    <h3 style="font-size:var(--text-lg);margin-bottom:var(--space-2);">Transparência</h3>
                    <p style="font-size:var(--text-sm);color:var(--color-gray-600);">Informação clara e acessível para todos.</p>
                </div>
                <div style="background:var(--color-gray-50);padding:var(--space-6);border-radius:var(--radius-xl);text-align:center;">
                    <div style="font-size:32px;margin-bottom:var(--space-3);">🤝</div>
                    <h3 style="font-size:var(--text-lg);margin-bottom:var(--space-2);">Colaboração</h3>
                    <p style="font-size:var(--text-sm);color:var(--color-gray-600);">Construindo juntos o jornalismo local.</p>
                </div>
                <div style="background:var(--color-gray-50);padding:var(--space-6);border-radius:var(--radius-xl);text-align:center;">
                    <div style="font-size:32px;margin-bottom:var(--space-3);">⚖️</div>
                    <h3 style="font-size:var(--text-lg);margin-bottom:var(--space-2);">Imparcialidade</h3>
                    <p style="font-size:var(--text-sm);color:var(--color-gray-600);">Fatos acima de opiniões políticas.</p>
                </div>
            </div>
            
            <h2 style="font-size:var(--text-2xl);margin:var(--space-8) 0 var(--space-4);">Como Funciona</h2>
            <ol style="margin-left:var(--space-6);margin-bottom:var(--space-6);">
                <li style="margin-bottom:var(--space-3);">Cadastre-se gratuitamente como <strong>Autor</strong> ou <strong>Anunciante</strong></li>
                <li style="margin-bottom:var(--space-3);">Selecione sua cidade para ver e publicar conteúdo local</li>
                <li style="margin-bottom:var(--space-3);">Publique notícias, opiniões ou denúncias</li>
                <li style="margin-bottom:var(--space-3);">Seu conteúdo passa por moderação para garantir qualidade</li>
                <li>Uma vez aprovado, sua publicação fica disponível para todos</li>
            </ol>
            
            <h2 style="font-size:var(--text-2xl);margin:var(--space-8) 0 var(--space-4);">Contato</h2>
            <p>
                Tem dúvidas, sugestões ou quer anunciar? <a href="<?= url('contato') ?>">Entre em contato conosco</a>.
            </p>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../partials/layout.php';
?>
