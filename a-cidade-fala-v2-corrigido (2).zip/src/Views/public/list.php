<?php
/**
 * A Cidade Fala v2.0 - Listagem de Posts
 */

use ACidadeFala\Config\Config;

// Garantir variáveis
$tipo = $tipo ?? 'noticia';
$posts = $posts ?? [];
$page = $page ?? 1;
$totalPages = $totalPages ?? 1;
$total = $total ?? 0;
$titulo = $titulo ?? 'Publicações';

$tipoLabels = [
    'noticia' => 'Notícias',
    'opiniao' => 'Opiniões',
    'denuncia' => 'Denúncias'
];

$pageTitle = $tipoLabels[$tipo] ?? $titulo;

ob_start();
?>

<div class="container" style="padding-top:var(--space-8);">
    
    <!-- Header da Listagem -->
    <div class="section-header" style="margin-bottom:var(--space-8);">
        <div>
            <nav class="post-breadcrumb" style="margin-bottom:var(--space-2);">
                <a href="<?= url('/') ?>">🏠</a>
                ›
                <span><?= e($pageTitle) ?></span>
            </nav>
            <h1 class="section-title" style="margin:0;border:none;padding:0;">
                <?php if ($tipo === 'noticia'): ?>
                <i class="lucide-newspaper section-title-icon"></i>
                <?php elseif ($tipo === 'opiniao'): ?>
                <i class="lucide-message-square section-title-icon"></i>
                <?php else: ?>
                <i class="lucide-alert-triangle section-title-icon"></i>
                <?php endif; ?>
                <?= e($pageTitle) ?>
                <span style="font-size:var(--text-base);font-weight:normal;color:var(--color-gray-500);margin-left:var(--space-3);">
                    <?= $total ?> publicações
                </span>
            </h1>
        </div>
    </div>
    
    <div class="content-layout">
        
        <!-- Conteúdo Principal -->
        <div class="content-main">
            
            <?php if (empty($posts)): ?>
            <div style="text-align:center;padding:var(--space-12);background:var(--color-gray-50);border-radius:var(--radius-xl);">
                <i class="lucide-inbox" style="font-size:64px;color:var(--color-gray-400);margin-bottom:var(--space-4);display:block;"></i>
                <h3 style="margin-bottom:var(--space-2);">Nenhuma publicação encontrada</h3>
                <p style="color:var(--color-gray-500);margin-bottom:var(--space-6);">
                    Seja o primeiro a publicar <?= $tipo === 'noticia' ? 'uma notícia' : ($tipo === 'opiniao' ? 'uma opinião' : 'uma denúncia') ?> na sua cidade!
                </p>
                <a href="<?= url('autor/publicar') ?>" class="btn btn-primary">
                    <i class="lucide-edit-3"></i> Publicar Agora
                </a>
            </div>
            <?php else: ?>
            
            <div class="news-grid">
                <?php foreach ($posts as $post): ?>
                <article class="news-card <?= $post['destaque'] ? 'featured' : '' ?>">
                    <div class="news-card-image-wrapper">
                        <?php if (!empty($post['imagem_capa'])): ?>
                        <img src="<?= upload($post['imagem_capa']) ?>" alt="<?= e($post['titulo']) ?>" class="news-card-image" loading="lazy">
                        <?php else: ?>
                        <div class="news-card-image" style="background:linear-gradient(135deg, var(--color-gray-300) 0%, var(--color-gray-400) 100%);display:flex;align-items:center;justify-content:center;">
                            <i class="lucide-image" style="font-size:48px;color:var(--color-gray-500);"></i>
                        </div>
                        <?php endif; ?>
                        <?php if ($post['categoria_id']): ?>
                            <?php $cat = Config::getCategory($post['categoria_id']); ?>
                            <?php if ($cat): ?>
                            <span style="position:absolute;top:var(--space-3);left:var(--space-3);">
                                <span class="badge" style="background:<?= $cat['color'] ?>;color:white;"><?= $cat['icon'] ?> <?= $cat['nome'] ?></span>
                            </span>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="news-card-content">
                        <h3 class="news-card-title">
                            <a href="<?= postUrl($post) ?>">
                                <?= e($post['titulo']) ?>
                            </a>
                        </h3>
                        <p class="news-card-excerpt">
                            <?= e(mb_substr(strip_tags($post['conteudo']), 0, 150)) ?>...
                        </p>
                        <div class="news-card-footer">
                            <span class="news-card-meta">
                                🕐
                                <?= timeAgo($post['publicado_em'] ?? $post['created_at']) ?>
                            </span>
                            <div class="news-card-stats">
                                <span>👁️ <?= number_format($post['visualizacoes'] ?? 0) ?></span>
                            </div>
                        </div>
                    </div>
                </article>
                <?php endforeach; ?>
            </div>
            
            <!-- Paginação -->
            <?php if ($totalPages > 1): ?>
            <nav class="pagination">
                <?php if ($page > 1): ?>
                <a href="?page=<?= $page - 1 ?>" class="pagination-item">
                    <i class="lucide-chevron-left"></i>
                </a>
                <?php endif; ?>
                
                <?php 
                $start = max(1, $page - 2);
                $end = min($totalPages, $page + 2);
                
                if ($start > 1): ?>
                <a href="?page=1" class="pagination-item">1</a>
                <?php if ($start > 2): ?>
                <span class="pagination-item" style="border:none;">...</span>
                <?php endif; ?>
                <?php endif; ?>
                
                <?php for ($i = $start; $i <= $end; $i++): ?>
                <a href="?page=<?= $i ?>" class="pagination-item <?= $i == $page ? 'active' : '' ?>">
                    <?= $i ?>
                </a>
                <?php endfor; ?>
                
                <?php if ($end < $totalPages): ?>
                <?php if ($end < $totalPages - 1): ?>
                <span class="pagination-item" style="border:none;">...</span>
                <?php endif; ?>
                <a href="?page=<?= $totalPages ?>" class="pagination-item"><?= $totalPages ?></a>
                <?php endif; ?>
                
                <?php if ($page < $totalPages): ?>
                <a href="?page=<?= $page + 1 ?>" class="pagination-item">
                    ›
                </a>
                <?php endif; ?>
            </nav>
            <?php endif; ?>
            
            <?php endif; ?>
            
        </div>
        
        <!-- Sidebar -->
        <aside class="sidebar">
            
            <!-- Filtros -->
            <div class="sidebar-widget">
                <h3 class="sidebar-widget-title">
                    <i class="lucide-filter"></i> Filtrar por Tipo
                </h3>
                <div style="display:flex;flex-direction:column;gap:var(--space-2);">
                    <a href="<?= url('noticias') ?>" class="btn <?= $tipo === 'noticia' ? 'btn-primary' : 'btn-ghost' ?> btn-block" style="justify-content:flex-start;">
                        <i class="lucide-newspaper"></i> Notícias
                    </a>
                    <a href="<?= url('opinioes') ?>" class="btn <?= $tipo === 'opiniao' ? 'btn-primary' : 'btn-ghost' ?> btn-block" style="justify-content:flex-start;">
                        <i class="lucide-message-square"></i> Opiniões
                    </a>
                    <a href="<?= url('denuncias') ?>" class="btn <?= $tipo === 'denuncia' ? 'btn-primary' : 'btn-ghost' ?> btn-block" style="justify-content:flex-start;">
                        <i class="lucide-alert-triangle"></i> Denúncias
                    </a>
                </div>
            </div>
            
            <!-- Categorias -->
            <div class="sidebar-widget">
                <h3 class="sidebar-widget-title">
                    <i class="lucide-grid"></i> Categorias
                </h3>
                <div style="display:flex;flex-wrap:wrap;gap:var(--space-2);">
                    <?php foreach (Config::CATEGORIES as $id => $cat): ?>
                    <a href="<?= url('categoria/' . $cat['slug']) ?>" 
                       class="badge" 
                       style="background:<?= $cat['color'] ?>20;color:<?= $cat['color'] ?>;text-transform:none;">
                        <?= $cat['icon'] ?> <?= e($cat['nome']) ?>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <!-- Banner -->
            <div class="ad-container">
                <div class="ad-label">Publicidade</div>
                <div class="ad-block ad-block-sidebar">
                    <span class="ad-placeholder">Anuncie aqui<br>300x250</span>
                </div>
            </div>
            
        </aside>
        
    </div>
    
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../partials/layout.php';
?>
