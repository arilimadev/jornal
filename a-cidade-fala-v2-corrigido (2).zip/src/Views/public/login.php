<?php
/**
 * A Cidade Fala v2.0 - Login
 */

use ACidadeFala\Config\Config;

$pageTitle = "Entrar";

ob_start();
?>

<style>
.auth-container {
    min-height: calc(100vh - 200px);
    display: flex;
    align-items: center;
    justify-content: center;
    padding: var(--space-8) var(--space-4);
    background: linear-gradient(135deg, var(--color-primary-50) 0%, var(--color-gray-100) 100%);
}

.auth-card {
    background: var(--color-white);
    border-radius: var(--radius-2xl);
    box-shadow: var(--shadow-xl);
    max-width: 440px;
    width: 100%;
    overflow: hidden;
}

.auth-header {
    background: var(--color-primary);
    color: var(--color-white);
    padding: var(--space-8);
    text-align: center;
}

.auth-logo {
    font-family: var(--font-heading);
    font-size: var(--text-2xl);
    font-weight: var(--font-extrabold);
    margin-bottom: var(--space-2);
}

.auth-title {
    font-size: var(--text-lg);
    opacity: 0.9;
}

.auth-body {
    padding: var(--space-8);
}

.auth-footer {
    padding: var(--space-6);
    background: var(--color-gray-50);
    text-align: center;
    border-top: 1px solid var(--color-border);
}

.auth-divider {
    display: flex;
    align-items: center;
    gap: var(--space-4);
    margin: var(--space-6) 0;
    color: var(--color-gray-400);
    font-size: var(--text-sm);
}

.auth-divider::before,
.auth-divider::after {
    content: '';
    flex: 1;
    height: 1px;
    background: var(--color-gray-200);
}

.social-login {
    display: flex;
    gap: var(--space-3);
}

.social-login-btn {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: var(--space-2);
    padding: var(--space-3);
    border: 2px solid var(--color-gray-200);
    border-radius: var(--radius-lg);
    background: var(--color-white);
    color: var(--color-gray-700);
    font-weight: var(--font-medium);
    cursor: pointer;
    transition: all var(--transition-fast);
}

.social-login-btn:hover {
    border-color: var(--color-primary);
    color: var(--color-primary);
}

.password-input-wrapper {
    position: relative;
}

.password-input-wrapper .form-input {
    padding-right: 48px;
}

.password-toggle {
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    cursor: pointer;
    color: var(--color-gray-400);
    padding: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.password-toggle:hover {
    color: var(--color-gray-600);
}
</style>

<script>
function togglePassword(inputId, btn) {
    const input = document.getElementById(inputId);
    const eyeIcon = btn.querySelector('.eye-icon');
    const eyeOffIcon = btn.querySelector('.eye-off-icon');
    
    if (input.type === 'password') {
        input.type = 'text';
        eyeIcon.style.display = 'none';
        eyeOffIcon.style.display = 'block';
    } else {
        input.type = 'password';
        eyeIcon.style.display = 'block';
        eyeOffIcon.style.display = 'none';
    }
}
</script>

<div class="auth-container">
    <div class="auth-card">
        <div class="auth-header">
            <div class="auth-logo"><?= e(Config::SITE_NAME) ?></div>
            <div class="auth-title">Entre na sua conta</div>
        </div>
        
        <div class="auth-body">
            <form id="loginForm">
                <div class="form-group">
                    <label class="form-label required">Email</label>
                    <input type="email" name="email" class="form-input" placeholder="seu@email.com" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label required">Senha</label>
                    <div class="password-input-wrapper">
                        <input type="password" name="senha" id="senhaInput" class="form-input" placeholder="••••••••" required>
                        <button type="button" class="password-toggle" onclick="togglePassword('senhaInput', this)">
                            <svg class="eye-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                            <svg class="eye-off-icon" style="display:none" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>
                        </button>
                    </div>
                </div>
                
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--space-6);">
                    <label class="form-check" style="margin:0;">
                        <input type="checkbox" name="lembrar" class="form-check-input">
                        <span class="form-check-label">Lembrar de mim</span>
                    </label>
                    <a href="<?= url('esqueci-senha') ?>" style="font-size:var(--text-sm);">Esqueceu a senha?</a>
                </div>
                
                <div id="loginError" class="alert alert-error" style="display:none;"></div>
                
                <button type="submit" class="btn btn-primary btn-lg btn-block" id="btnLogin">
                    🔐
                    Entrar
                </button>
            </form>
        </div>
        
        <div class="auth-footer">
            <p>Não tem uma conta? <a href="<?= url('registro') ?>"><strong>Cadastre-se grátis</strong></a></p>
        </div>
    </div>
</div>

<script>
document.getElementById('loginForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const btn = document.getElementById('btnLogin');
    const errorDiv = document.getElementById('loginError');
    
    btn.disabled = true;
    btn.innerHTML = '⏳ Entrando...';
    errorDiv.style.display = 'none';
    
    const data = {
        email: this.email.value,
        senha: this.senha.value
    };
    
    try {
        const response = await fetch(window.ACF.apiUrl + '/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (result.success) {
            window.location.href = result.redirect || window.ACF.baseUrl + '/autor';
        } else {
            errorDiv.textContent = result.error || 'Email ou senha inválidos';
            errorDiv.style.display = 'block';
            btn.disabled = false;
            btn.innerHTML = '🔐 Entrar';
        }
    } catch (error) {
        console.error(error);
        errorDiv.textContent = 'Erro de conexão. Verifique sua internet.';
        errorDiv.style.display = 'block';
        btn.disabled = false;
        btn.innerHTML = '🔐 Entrar';
    }
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/../partials/layout.php';
?>
