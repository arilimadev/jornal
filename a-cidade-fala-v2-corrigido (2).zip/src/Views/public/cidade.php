<?php
/**
 * A Cidade Fala v2.0 - Página da Cidade
 */

use ACidadeFala\Config\Config;

$cidade = $cidade ?? [];
$estado = $estado ?? [];
$posts = $posts ?? [];
$maisLidas = $maisLidas ?? [];
$rankingAutores = $rankingAutores ?? [];
$categorias = $categorias ?? [];
$banners = $banners ?? [];

$pageTitle = ($cidade['nome'] ?? 'Cidade') . ' - ' . ($estado['uf'] ?? '');
$pageDescription = "Notícias de " . ($cidade['nome'] ?? 'sua cidade') . ". Acompanhe as últimas novidades, denúncias e opiniões da sua região.";

ob_start();
?>

<style>
.city-header {
    background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-dark) 100%);
    color: white;
    padding: var(--space-8) 0;
    margin-bottom: var(--space-8);
}

.city-header-content {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 var(--space-4);
}

.city-breadcrumb {
    display: flex;
    align-items: center;
    gap: var(--space-2);
    font-size: var(--text-sm);
    opacity: 0.9;
    margin-bottom: var(--space-4);
}

.city-breadcrumb a { color: white; text-decoration: none; }
.city-breadcrumb a:hover { text-decoration: underline; }

.city-title {
    font-size: var(--text-4xl);
    font-weight: var(--font-extrabold);
    margin-bottom: var(--space-2);
}

.city-subtitle {
    font-size: var(--text-lg);
    opacity: 0.9;
}

.city-stats {
    display: flex;
    gap: var(--space-6);
    margin-top: var(--space-6);
}

.city-stat {
    text-align: center;
}

.city-stat-value {
    font-size: var(--text-2xl);
    font-weight: var(--font-bold);
}

.city-stat-label {
    font-size: var(--text-sm);
    opacity: 0.8;
}

.city-page {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 var(--space-4);
}

.city-layout {
    display: grid;
    grid-template-columns: 1fr 320px;
    gap: var(--space-8);
}

@media (max-width: 1024px) {
    .city-layout { grid-template-columns: 1fr; }
}

/* Posts Grid */
.posts-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: var(--space-6);
}

.post-card {
    background: var(--color-white);
    border-radius: var(--radius-xl);
    overflow: hidden;
    box-shadow: var(--shadow-sm);
    transition: all var(--transition-normal);
}

.post-card:hover {
    transform: translateY(-4px);
    box-shadow: var(--shadow-lg);
}

.post-card-image {
    width: 100%;
    height: 180px;
    object-fit: cover;
    background: var(--color-gray-100);
}

.post-card-body {
    padding: var(--space-5);
}

.post-card-category {
    display: inline-block;
    padding: var(--space-1) var(--space-3);
    background: var(--color-primary-50);
    color: var(--color-primary);
    font-size: var(--text-xs);
    font-weight: var(--font-semibold);
    border-radius: var(--radius-full);
    margin-bottom: var(--space-3);
}

.post-card-title {
    font-size: var(--text-lg);
    font-weight: var(--font-bold);
    margin-bottom: var(--space-2);
    line-height: 1.3;
}

.post-card-title a {
    color: var(--color-gray-900);
    text-decoration: none;
}

.post-card-title a:hover {
    color: var(--color-primary);
}

.post-card-meta {
    display: flex;
    gap: var(--space-4);
    font-size: var(--text-sm);
    color: var(--color-gray-500);
}

.post-card-featured {
    border: 2px solid var(--color-primary);
}

.post-card-featured .post-card-badge {
    position: absolute;
    top: var(--space-3);
    left: var(--space-3);
    background: var(--color-primary);
    color: white;
    padding: var(--space-1) var(--space-3);
    font-size: var(--text-xs);
    font-weight: var(--font-semibold);
    border-radius: var(--radius-full);
}

/* Sidebar */
.sidebar-widget {
    background: var(--color-white);
    border-radius: var(--radius-xl);
    padding: var(--space-5);
    margin-bottom: var(--space-6);
    box-shadow: var(--shadow-sm);
}

.sidebar-title {
    font-size: var(--text-lg);
    font-weight: var(--font-bold);
    margin-bottom: var(--space-4);
    padding-bottom: var(--space-3);
    border-bottom: 2px solid var(--color-primary);
    display: flex;
    align-items: center;
    gap: var(--space-2);
}

/* Mais Lidas */
.mais-lida-item {
    display: flex;
    gap: var(--space-3);
    padding: var(--space-3) 0;
    border-bottom: 1px solid var(--color-gray-100);
}

.mais-lida-item:last-child { border-bottom: none; }

.mais-lida-rank {
    width: 28px;
    height: 28px;
    background: var(--color-primary);
    color: white;
    border-radius: var(--radius-full);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: var(--font-bold);
    font-size: var(--text-sm);
    flex-shrink: 0;
}

.mais-lida-content { flex: 1; }

.mais-lida-title {
    font-size: var(--text-sm);
    font-weight: var(--font-semibold);
    line-height: 1.3;
    margin-bottom: var(--space-1);
}

.mais-lida-title a {
    color: var(--color-gray-800);
    text-decoration: none;
}

.mais-lida-title a:hover {
    color: var(--color-primary);
}

.mais-lida-views {
    font-size: var(--text-xs);
    color: var(--color-gray-500);
}

/* Ranking Autores */
.autor-rank-item {
    display: flex;
    align-items: center;
    gap: var(--space-3);
    padding: var(--space-3) 0;
    border-bottom: 1px solid var(--color-gray-100);
}

.autor-rank-item:last-child { border-bottom: none; }

.autor-rank-position {
    font-size: var(--text-lg);
    font-weight: var(--font-bold);
    color: var(--color-gray-400);
    width: 24px;
}

.autor-rank-position.top-3 { color: var(--color-primary); }

.autor-rank-avatar {
    width: 40px;
    height: 40px;
    border-radius: var(--radius-full);
    background: var(--color-gray-200);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: var(--font-semibold);
    color: var(--color-gray-600);
}

.autor-rank-info { flex: 1; }

.autor-rank-name {
    font-weight: var(--font-semibold);
    font-size: var(--text-sm);
}

.autor-rank-name a {
    color: var(--color-gray-800);
    text-decoration: none;
}

.autor-rank-name a:hover { color: var(--color-primary); }

.autor-rank-stats {
    font-size: var(--text-xs);
    color: var(--color-gray-500);
}

/* Categorias */
.category-list {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
}

.category-link {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: var(--space-2) var(--space-3);
    background: var(--color-gray-50);
    border-radius: var(--radius-md);
    text-decoration: none;
    color: var(--color-gray-700);
    font-size: var(--text-sm);
    transition: all var(--transition-fast);
}

.category-link:hover {
    background: var(--color-primary-50);
    color: var(--color-primary);
}

.category-count {
    background: var(--color-gray-200);
    padding: var(--space-1) var(--space-2);
    border-radius: var(--radius-full);
    font-size: var(--text-xs);
}

/* Banner */
.sidebar-banner {
    width: 100%;
    border-radius: var(--radius-lg);
    overflow: hidden;
}

.sidebar-banner img {
    width: 100%;
    display: block;
}

/* Filtros */
.filters-bar {
    display: flex;
    gap: var(--space-3);
    margin-bottom: var(--space-6);
    flex-wrap: wrap;
}

.filter-btn {
    padding: var(--space-2) var(--space-4);
    background: var(--color-white);
    border: 1px solid var(--color-gray-200);
    border-radius: var(--radius-full);
    font-size: var(--text-sm);
    color: var(--color-gray-600);
    cursor: pointer;
    transition: all var(--transition-fast);
    text-decoration: none;
}

.filter-btn:hover, .filter-btn.active {
    background: var(--color-primary);
    border-color: var(--color-primary);
    color: white;
}

/* Empty state */
.empty-posts {
    text-align: center;
    padding: var(--space-12);
    color: var(--color-gray-500);
}

.empty-posts-icon {
    font-size: 64px;
    opacity: 0.3;
    margin-bottom: var(--space-4);
}
</style>

<!-- Header da Cidade -->
<div class="city-header">
    <div class="city-header-content">
        <div class="city-breadcrumb">
            <a href="<?= url('/') ?>">Início</a>
            <span>›</span>
            <a href="<?= url($estado['uf'] ?? '') ?>"><?= e($estado['nome'] ?? '') ?></a>
            <span>›</span>
            <span><?= e($cidade['nome'] ?? '') ?></span>
        </div>
        
        <h1 class="city-title">📍 <?= e($cidade['nome'] ?? 'Cidade') ?></h1>
        <p class="city-subtitle">Notícias, opiniões e denúncias da sua cidade</p>
        
        <div class="city-stats">
            <div class="city-stat">
                <div class="city-stat-value"><?= number_format($stats['total_posts'] ?? 0) ?></div>
                <div class="city-stat-label">Publicações</div>
            </div>
            <div class="city-stat">
                <div class="city-stat-value"><?= number_format($stats['total_autores'] ?? 0) ?></div>
                <div class="city-stat-label">Autores</div>
            </div>
            <div class="city-stat">
                <div class="city-stat-value"><?= number_format($stats['total_visualizacoes'] ?? 0) ?></div>
                <div class="city-stat-label">Visualizações</div>
            </div>
        </div>
    </div>
</div>

<div class="city-page">
    <!-- Filtros -->
    <div class="filters-bar">
        <a href="?tipo=" class="filter-btn <?= empty($_GET['tipo']) ? 'active' : '' ?>">📋 Todas</a>
        <a href="?tipo=noticia" class="filter-btn <?= ($_GET['tipo'] ?? '') === 'noticia' ? 'active' : '' ?>">📰 Notícias</a>
        <a href="?tipo=opiniao" class="filter-btn <?= ($_GET['tipo'] ?? '') === 'opiniao' ? 'active' : '' ?>">💭 Opiniões</a>
        <a href="?tipo=denuncia" class="filter-btn <?= ($_GET['tipo'] ?? '') === 'denuncia' ? 'active' : '' ?>">🚨 Denúncias</a>
    </div>
    
    <div class="city-layout">
        <!-- Posts -->
        <main>
            <?php if (!empty($posts)): ?>
                <div class="posts-grid">
                    <?php foreach ($posts as $post): ?>
                        <article class="post-card <?= $post['destaque'] ? 'post-card-featured' : '' ?>">
                            <?php if ($post['imagem_capa']): ?>
                                <img src="<?= upload($post['imagem_capa']) ?>" class="post-card-image" alt="<?= e($post['titulo']) ?>">
                            <?php else: ?>
                                <div class="post-card-image" style="display:flex;align-items:center;justify-content:center;font-size:48px;color:#d1d5db;">📰</div>
                            <?php endif; ?>
                            
                            <div class="post-card-body">
                                <?php if (!empty($post['categoria_nome'])): ?>
                                    <span class="post-card-category"><?= e($post['categoria_icone'] ?? '') ?> <?= e($post['categoria_nome']) ?></span>
                                <?php endif; ?>
                                
                                <h3 class="post-card-title">
                                    <a href="<?= url($estado['uf'] . '/' . $cidade['slug'] . '/' . $post['slug']) ?>">
                                        <?= e($post['titulo']) ?>
                                    </a>
                                </h3>
                                
                                <div class="post-card-meta">
                                    <span>👤 <?= $post['anonimo'] ? 'Anônimo' : e($post['autor_nome'] ?? 'Autor') ?></span>
                                    <span>📅 <?= timeAgo($post['publicado_em'] ?? $post['created_at']) ?></span>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
                
                <!-- Paginação -->
                <?php if (($totalPages ?? 1) > 1): ?>
                <div style="display:flex;justify-content:center;gap:8px;margin-top:var(--space-8);">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?page=<?= $i ?>&tipo=<?= e($_GET['tipo'] ?? '') ?>" 
                           style="padding:8px 14px;border:1px solid #e2e8f0;border-radius:6px;text-decoration:none;color:<?= ($page ?? 1) == $i ? 'white' : '#475569' ?>;background:<?= ($page ?? 1) == $i ? 'var(--color-primary)' : 'white' ?>;">
                            <?= $i ?>
                        </a>
                    <?php endfor; ?>
                </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="empty-posts">
                    <div class="empty-posts-icon">📭</div>
                    <h3>Nenhuma publicação ainda</h3>
                    <p>Seja o primeiro a publicar nesta cidade!</p>
                    <a href="<?= url('autor/publicar') ?>" class="btn btn-primary" style="margin-top:16px;">
                        ✍️ Criar Publicação
                    </a>
                </div>
            <?php endif; ?>
        </main>
        
        <!-- Sidebar -->
        <aside>
            <!-- Mais Lidas -->
            <?php if (!empty($maisLidas)): ?>
            <div class="sidebar-widget">
                <h3 class="sidebar-title">🔥 Mais Lidas (7 dias)</h3>
                <?php foreach (array_slice($maisLidas, 0, 5) as $i => $post): ?>
                    <div class="mais-lida-item">
                        <div class="mais-lida-rank"><?= $i + 1 ?></div>
                        <div class="mais-lida-content">
                            <div class="mais-lida-title">
                                <a href="<?= url($estado['uf'] . '/' . $cidade['slug'] . '/' . $post['slug']) ?>">
                                    <?= e($post['titulo']) ?>
                                </a>
                            </div>
                            <div class="mais-lida-views">
                                👁️ <?= number_format($post['visualizacoes']) ?> visualizações
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            
            <!-- Ranking de Autores -->
            <?php if (!empty($rankingAutores)): ?>
            <div class="sidebar-widget">
                <h3 class="sidebar-title">🏆 Ranking de Autores</h3>
                <?php foreach (array_slice($rankingAutores, 0, 5) as $i => $autor): ?>
                    <div class="autor-rank-item">
                        <div class="autor-rank-position <?= $i < 3 ? 'top-3' : '' ?>"><?= $i + 1 ?>º</div>
                        <div class="autor-rank-avatar">
                            <?= strtoupper(substr($autor['nome'], 0, 1)) ?>
                        </div>
                        <div class="autor-rank-info">
                            <div class="autor-rank-name">
                                <a href="<?= url('autor/' . $autor['id']) ?>"><?= e($autor['nome']) ?></a>
                            </div>
                            <div class="autor-rank-stats">
                                <?= $autor['total_posts'] ?> posts • <?= number_format($autor['total_visualizacoes']) ?> views
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            
            <!-- Banner -->
            <?php if (!empty($banners)): ?>
                <?php foreach ($banners as $banner): ?>
                <div class="sidebar-widget" style="padding:0;overflow:hidden;">
                    <a href="<?= url('banner/click/' . $banner['id']) ?>" target="_blank" class="sidebar-banner">
                        <img src="<?= upload($banner['imagem_url']) ?>" alt="<?= e($banner['titulo']) ?>">
                    </a>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
            
            <!-- Categorias -->
            <div class="sidebar-widget">
                <h3 class="sidebar-title">🏷️ Categorias</h3>
                <div class="category-list">
                    <?php foreach ($categorias as $cat): ?>
                        <a href="<?= url($estado['uf'] . '/' . $cidade['slug'] . '/categoria/' . $cat['slug']) ?>" class="category-link">
                            <span><?= $cat['icone'] ?? '📌' ?> <?= e($cat['nome']) ?></span>
                            <span class="category-count"><?= $cat['total'] ?? 0 ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <!-- Anunciar -->
            <div class="sidebar-widget" style="background:linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-dark) 100%);color:white;">
                <h3 class="sidebar-title" style="color:white;border-bottom-color:rgba(255,255,255,0.3);">📢 Anuncie aqui!</h3>
                <p style="font-size:14px;margin-bottom:16px;">Alcance milhares de pessoas em <?= e($cidade['nome']) ?>.</p>
                <a href="<?= url('anunciar') ?>" class="btn" style="background:white;color:var(--color-primary);width:100%;justify-content:center;">
                    Ver Planos
                </a>
            </div>
        </aside>
    </div>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../partials/layout.php';
?>
