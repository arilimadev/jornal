<?php
/**
 * A Cidade Fala v2.0 - Selecionar Cidade (com Mapa)
 */

use ACidadeFala\Config\Config;

$pageTitle = "Selecione sua Cidade";

ob_start();
?>

<style>
.city-selector {
    min-height: calc(100vh - 200px);
    padding: var(--space-8) var(--space-4);
    background: linear-gradient(135deg, var(--color-primary-50) 0%, var(--color-gray-100) 100%);
}

.city-selector-container {
    max-width: 1000px;
    margin: 0 auto;
}

.city-selector-header {
    text-align: center;
    margin-bottom: var(--space-8);
}

.city-selector-header h1 {
    font-size: var(--text-3xl);
    margin-bottom: var(--space-2);
}

.city-selector-header p {
    color: var(--color-gray-600);
    font-size: var(--text-lg);
}

.location-detect {
    background: var(--color-white);
    border-radius: var(--radius-xl);
    padding: var(--space-6);
    margin-bottom: var(--space-6);
    text-align: center;
    box-shadow: var(--shadow-sm);
}

.location-detect-btn {
    display: inline-flex;
    align-items: center;
    gap: var(--space-2);
    padding: var(--space-3) var(--space-6);
    background: var(--color-primary);
    color: white;
    border: none;
    border-radius: var(--radius-full);
    font-size: var(--text-base);
    cursor: pointer;
    transition: all var(--transition-fast);
}

.location-detect-btn:hover {
    background: var(--color-primary-dark);
    transform: translateY(-2px);
}

.location-detect-btn:disabled {
    background: var(--color-gray-400);
    cursor: not-allowed;
    transform: none;
}

.location-status {
    margin-top: var(--space-3);
    font-size: var(--text-sm);
    color: var(--color-gray-600);
}

.location-status.success { color: var(--color-success); }
.location-status.error { color: var(--color-error); }

.map-section {
    display: grid;
    grid-template-columns: 1fr;
    gap: var(--space-6);
}

@media (min-width: 768px) {
    .map-section {
        grid-template-columns: 1fr 350px;
    }
}

.brazil-map-container {
    background: var(--color-white);
    border-radius: var(--radius-xl);
    padding: var(--space-6);
    box-shadow: var(--shadow-sm);
}

.brazil-map-title {
    font-size: var(--text-lg);
    font-weight: var(--font-semibold);
    margin-bottom: var(--space-4);
    text-align: center;
}

.brazil-map {
    width: 100%;
    max-width: 450px;
    margin: 0 auto;
    display: block;
}

.brazil-map path {
    fill: var(--color-gray-200);
    stroke: var(--color-white);
    stroke-width: 2;
    cursor: pointer;
    transition: all var(--transition-fast);
}

.brazil-map path:hover {
    fill: var(--color-primary-300);
}

.brazil-map path.selected {
    fill: var(--color-primary);
}

.city-select-panel {
    background: var(--color-white);
    border-radius: var(--radius-xl);
    padding: var(--space-6);
    box-shadow: var(--shadow-sm);
}

.selected-state {
    background: var(--color-primary);
    color: white;
    padding: var(--space-3) var(--space-4);
    border-radius: var(--radius-lg);
    margin-bottom: var(--space-4);
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.selected-state-name { font-weight: var(--font-semibold); }

.selected-state-clear {
    background: rgba(255,255,255,0.2);
    border: none;
    color: white;
    width: 28px;
    height: 28px;
    border-radius: var(--radius-full);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}

.city-search {
    position: relative;
    margin-bottom: var(--space-4);
}

.city-search input {
    width: 100%;
    padding: var(--space-3) var(--space-4);
    padding-left: var(--space-10);
    border: 2px solid var(--color-gray-200);
    border-radius: var(--radius-lg);
    font-size: var(--text-base);
}

.city-search input:focus {
    outline: none;
    border-color: var(--color-primary);
}

.city-search-icon {
    position: absolute;
    left: var(--space-3);
    top: 50%;
    transform: translateY(-50%);
    color: var(--color-gray-400);
}

.city-list {
    max-height: 280px;
    overflow-y: auto;
    border: 1px solid var(--color-gray-200);
    border-radius: var(--radius-lg);
}

.city-item {
    padding: var(--space-3) var(--space-4);
    cursor: pointer;
    border-bottom: 1px solid var(--color-gray-100);
    transition: background var(--transition-fast);
}

.city-item:last-child { border-bottom: none; }
.city-item:hover { background: var(--color-primary-50); }
.city-item.selected { background: var(--color-primary); color: white; }

.city-empty, .city-loading {
    padding: var(--space-6);
    text-align: center;
    color: var(--color-gray-500);
}

.confirm-btn {
    margin-top: var(--space-4);
    width: 100%;
}

.popular-cities {
    margin-top: var(--space-6);
    padding-top: var(--space-6);
    border-top: 1px solid var(--color-gray-200);
}

.popular-cities-title {
    font-size: var(--text-sm);
    color: var(--color-gray-500);
    margin-bottom: var(--space-3);
    text-align: center;
}

.popular-cities-list {
    display: flex;
    flex-wrap: wrap;
    gap: var(--space-2);
    justify-content: center;
}

.popular-city-btn {
    padding: var(--space-2) var(--space-4);
    background: var(--color-gray-100);
    border: none;
    border-radius: var(--radius-full);
    font-size: var(--text-sm);
    cursor: pointer;
    transition: all var(--transition-fast);
}

.popular-city-btn:hover {
    background: var(--color-primary);
    color: white;
}

.no-state-selected {
    text-align: center;
    padding: var(--space-8);
    color: var(--color-gray-500);
}

.no-state-selected i {
    font-size: 48px;
    margin-bottom: var(--space-4);
    display: block;
    opacity: 0.5;
}

.state-tooltip {
    position: absolute;
    background: var(--color-gray-900);
    color: white;
    padding: var(--space-2) var(--space-3);
    border-radius: var(--radius-md);
    font-size: var(--text-sm);
    pointer-events: none;
    z-index: 100;
    white-space: nowrap;
    display: none;
}
</style>

<div class="city-selector">
    <div class="city-selector-container">
        
        <div class="city-selector-header">
            <h1>📍 Selecione sua Cidade</h1>
            <p>Escolha sua localização para ver notícias da sua região</p>
        </div>
        
        <!-- Detecção Automática -->
        <div class="location-detect">
            <button type="button" class="location-detect-btn" id="detectLocationBtn" onclick="detectLocation()">
                <i class="lucide-navigation"></i>
                Detectar minha localização automaticamente
            </button>
            <div class="location-status" id="locationStatus"></div>
        </div>
        
        <div class="map-section">
            
            <!-- Mapa do Brasil -->
            <div class="brazil-map-container">
                <div class="brazil-map-title">Clique no seu estado</div>
                <div style="position:relative;">
                    <svg class="brazil-map" viewBox="0 0 350 340" id="brazilMap">
                        <!-- Região Norte -->
                        <path id="AM" data-uf="AM" data-name="Amazonas" d="M45,55 L125,50 L130,70 L140,100 L125,125 L95,130 L70,120 L50,95 L40,75 Z"/>
                        <path id="PA" data-uf="PA" data-name="Pará" d="M140,60 L210,55 L225,75 L230,105 L215,130 L180,140 L155,135 L140,110 L130,85 Z"/>
                        <path id="AC" data-uf="AC" data-name="Acre" d="M20,100 L50,95 L60,115 L50,130 L30,135 L15,120 Z"/>
                        <path id="RO" data-uf="RO" data-name="Rondônia" d="M60,120 L95,115 L105,140 L95,165 L70,170 L55,150 Z"/>
                        <path id="RR" data-uf="RR" data-name="Roraima" d="M90,15 L120,10 L130,35 L120,55 L95,60 L85,40 Z"/>
                        <path id="AP" data-uf="AP" data-name="Amapá" d="M200,15 L225,10 L235,35 L225,55 L205,60 L195,40 Z"/>
                        <path id="TO" data-uf="TO" data-name="Tocantins" d="M200,130 L225,125 L235,160 L225,200 L205,205 L190,175 L195,150 Z"/>
                        
                        <!-- Região Nordeste -->
                        <path id="MA" data-uf="MA" data-name="Maranhão" d="M230,95 L270,90 L280,115 L275,145 L245,150 L225,130 Z"/>
                        <path id="PI" data-uf="PI" data-name="Piauí" d="M250,145 L280,140 L290,175 L280,205 L255,210 L245,180 Z"/>
                        <path id="CE" data-uf="CE" data-name="Ceará" d="M280,110 L310,105 L320,130 L310,155 L285,160 L275,140 Z"/>
                        <path id="RN" data-uf="RN" data-name="Rio Grande do Norte" d="M310,120 L340,115 L345,140 L330,150 L310,145 Z"/>
                        <path id="PB" data-uf="PB" data-name="Paraíba" d="M305,150 L345,145 L348,165 L335,175 L305,170 Z"/>
                        <path id="PE" data-uf="PE" data-name="Pernambuco" d="M280,170 L345,165 L350,190 L330,200 L280,195 Z"/>
                        <path id="AL" data-uf="AL" data-name="Alagoas" d="M315,200 L345,195 L350,215 L335,225 L315,220 Z"/>
                        <path id="SE" data-uf="SE" data-name="Sergipe" d="M300,220 L325,215 L330,235 L315,245 L300,240 Z"/>
                        <path id="BA" data-uf="BA" data-name="Bahia" d="M250,200 L300,195 L310,245 L295,290 L250,295 L235,255 L240,225 Z"/>
                        
                        <!-- Região Centro-Oeste -->
                        <path id="MT" data-uf="MT" data-name="Mato Grosso" d="M100,140 L190,135 L200,200 L180,250 L120,255 L100,210 L95,175 Z"/>
                        <path id="GO" data-uf="GO" data-name="Goiás" d="M195,205 L245,200 L255,250 L235,285 L200,280 L190,245 Z"/>
                        <path id="DF" data-uf="DF" data-name="Distrito Federal" d="M225,240 L242,235 L247,252 L235,262 L222,255 Z"/>
                        <path id="MS" data-uf="MS" data-name="Mato Grosso do Sul" d="M125,255 L185,250 L195,295 L170,330 L135,325 L120,290 Z"/>
                        
                        <!-- Região Sudeste -->
                        <path id="MG" data-uf="MG" data-name="Minas Gerais" d="M230,255 L300,250 L315,295 L285,335 L240,330 L225,295 Z"/>
                        <path id="ES" data-uf="ES" data-name="Espírito Santo" d="M305,270 L330,265 L340,295 L325,315 L305,305 Z"/>
                        <path id="RJ" data-uf="RJ" data-name="Rio de Janeiro" d="M285,310 L325,305 L338,328 L315,345 L280,338 Z"/>
                        <path id="SP" data-uf="SP" data-name="São Paulo" d="M195,295 L280,290 L290,330 L255,360 L205,355 L190,325 Z"/>
                    </svg>
                    <div class="state-tooltip" id="stateTooltip"></div>
                </div>
            </div>
            
            <!-- Painel de Seleção -->
            <div class="city-select-panel">
                <div id="statePanel" style="display:none;">
                    <div class="selected-state">
                        <span class="selected-state-name" id="selectedStateName">-</span>
                        <button class="selected-state-clear" onclick="clearState()" title="Limpar">✕</button>
                    </div>
                    
                    <div class="city-search">
                        <span class="city-search-icon">🔍</span>
                        <input type="text" id="citySearch" placeholder="Buscar cidade..." oninput="filterCities()">
                    </div>
                    
                    <div class="city-list" id="cityList">
                        <div class="city-loading">⏳ Carregando cidades...</div>
                    </div>
                    
                    <button class="btn btn-primary btn-lg confirm-btn" id="confirmBtn" onclick="confirmCity()" disabled>
                        ✓ Confirmar Cidade
                    </button>
                </div>
                
                <div id="noStatePanel">
                    <div class="no-state-selected">
                        <span style="font-size:48px;">🗺️</span>
                        <p>Clique em um estado no mapa<br>ou use a detecção automática</p>
                    </div>
                    
                    <div class="popular-cities">
                        <div class="popular-cities-title">Cidades populares</div>
                        <div class="popular-cities-list">
                            <button class="popular-city-btn" onclick="quickSelectCity('SC', 'Florianópolis')">Florianópolis</button>
                            <button class="popular-city-btn" onclick="quickSelectCity('SP', 'São Paulo')">São Paulo</button>
                            <button class="popular-city-btn" onclick="quickSelectCity('RJ', 'Rio de Janeiro')">Rio de Janeiro</button>
                            <button class="popular-city-btn" onclick="quickSelectCity('DF', 'Brasília')">Brasília</button>
                            <button class="popular-city-btn" onclick="quickSelectCity('SC', 'Joinville')">Joinville</button>
                            <button class="popular-city-btn" onclick="quickSelectCity('MG', 'Belo Horizonte')">Belo Horizonte</button>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
        
    </div>
</div>

<script>
let selectedStateUF = null;
let selectedCityId = null;
let allCities = [];

const stateNames = {
    'AC': 'Acre', 'AL': 'Alagoas', 'AP': 'Amapá', 'AM': 'Amazonas',
    'BA': 'Bahia', 'CE': 'Ceará', 'DF': 'Distrito Federal', 'ES': 'Espírito Santo',
    'GO': 'Goiás', 'MA': 'Maranhão', 'MT': 'Mato Grosso', 'MS': 'Mato Grosso do Sul',
    'MG': 'Minas Gerais', 'PA': 'Pará', 'PB': 'Paraíba', 'PR': 'Paraná',
    'PE': 'Pernambuco', 'PI': 'Piauí', 'RJ': 'Rio de Janeiro', 'RN': 'Rio Grande do Norte',
    'RS': 'Rio Grande do Sul', 'RO': 'Rondônia', 'RR': 'Roraima', 'SC': 'Santa Catarina',
    'SP': 'São Paulo', 'SE': 'Sergipe', 'TO': 'Tocantins'
};

// Tooltip do mapa
const tooltip = document.getElementById('stateTooltip');
document.querySelectorAll('#brazilMap path').forEach(path => {
    path.addEventListener('mouseenter', function(e) {
        tooltip.textContent = this.dataset.name;
        tooltip.style.display = 'block';
    });
    path.addEventListener('mousemove', function(e) {
        const rect = document.querySelector('.brazil-map-container').getBoundingClientRect();
        tooltip.style.left = (e.clientX - rect.left + 10) + 'px';
        tooltip.style.top = (e.clientY - rect.top - 30) + 'px';
    });
    path.addEventListener('mouseleave', function() {
        tooltip.style.display = 'none';
    });
    path.addEventListener('click', function() {
        selectState(this.dataset.uf);
    });
});

function selectState(uf) {
    document.querySelectorAll('#brazilMap path').forEach(p => p.classList.remove('selected'));
    const path = document.querySelector(`#brazilMap path[data-uf="${uf}"]`);
    if (path) path.classList.add('selected');
    
    selectedStateUF = uf;
    selectedCityId = null;
    
    document.getElementById('selectedStateName').textContent = stateNames[uf] + ' (' + uf + ')';
    document.getElementById('statePanel').style.display = 'block';
    document.getElementById('noStatePanel').style.display = 'none';
    document.getElementById('confirmBtn').disabled = true;
    document.getElementById('citySearch').value = '';
    
    loadCities(uf);
}

async function loadCities(uf) {
    const cityList = document.getElementById('cityList');
    cityList.innerHTML = '<div class="city-loading">⏳ Carregando cidades...</div>';
    
    try {
        const response = await fetch(window.ACF.apiUrl + '/cidades?uf=' + uf);
        const result = await response.json();
        
        if (result.success && result.cidades && result.cidades.length > 0) {
            allCities = result.cidades;
            renderCities(allCities);
        } else {
            cityList.innerHTML = '<div class="city-empty">Nenhuma cidade cadastrada</div>';
        }
    } catch (error) {
        cityList.innerHTML = '<div class="city-empty">Erro ao carregar</div>';
    }
}

function renderCities(cities) {
    const cityList = document.getElementById('cityList');
    if (cities.length === 0) {
        cityList.innerHTML = '<div class="city-empty">Nenhuma cidade encontrada</div>';
        return;
    }
    cityList.innerHTML = cities.map(city => 
        `<div class="city-item" onclick="selectCity(${city.id}, '${city.nome.replace(/'/g, "\\'")}')" data-id="${city.id}">
            📍 ${city.nome}
        </div>`
    ).join('');
}

function filterCities() {
    const search = document.getElementById('citySearch').value.toLowerCase();
    const filtered = allCities.filter(city => city.nome.toLowerCase().includes(search));
    renderCities(filtered);
}

function selectCity(id, nome) {
    document.querySelectorAll('.city-item').forEach(item => item.classList.remove('selected'));
    document.querySelector(`.city-item[data-id="${id}"]`)?.classList.add('selected');
    selectedCityId = id;
    document.getElementById('confirmBtn').disabled = false;
}

function clearState() {
    document.querySelectorAll('#brazilMap path').forEach(p => p.classList.remove('selected'));
    selectedStateUF = null;
    selectedCityId = null;
    document.getElementById('statePanel').style.display = 'none';
    document.getElementById('noStatePanel').style.display = 'block';
}

async function confirmCity() {
    if (!selectedCityId) return;
    
    const btn = document.getElementById('confirmBtn');
    btn.disabled = true;
    btn.innerHTML = '⏳ Salvando...';
    
    try {
        const response = await fetch(window.ACF.baseUrl + '/definir-cidade', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'cidade_id=' + selectedCityId
        });
        
        const result = await response.json();
        
        if (result.success) {
            window.location.href = result.redirect || window.ACF.baseUrl + '/';
        } else {
            alert(result.error || 'Erro ao definir cidade');
            btn.disabled = false;
            btn.innerHTML = '✓ Confirmar Cidade';
        }
    } catch (error) {
        alert('Erro de conexão');
        btn.disabled = false;
        btn.innerHTML = '✓ Confirmar Cidade';
    }
}

function quickSelectCity(uf, cityName) {
    selectState(uf);
    setTimeout(() => {
        document.getElementById('citySearch').value = cityName;
        filterCities();
        setTimeout(() => {
            const firstCity = document.querySelector('.city-item');
            if (firstCity) firstCity.click();
        }, 300);
    }, 800);
}

async function detectLocation() {
    const btn = document.getElementById('detectLocationBtn');
    const status = document.getElementById('locationStatus');
    
    btn.disabled = true;
    btn.innerHTML = '⏳ Detectando...';
    status.className = 'location-status';
    status.textContent = 'Obtendo sua localização...';
    
    if (!navigator.geolocation) {
        status.className = 'location-status error';
        status.textContent = 'Navegador não suporta geolocalização';
        resetDetectBtn();
        return;
    }
    
    navigator.geolocation.getCurrentPosition(
        async (position) => {
            const { latitude, longitude } = position.coords;
            status.textContent = 'Buscando cidade...';
            
            try {
                const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&addressdetails=1`);
                const data = await response.json();
                
                if (data.address) {
                    const city = data.address.city || data.address.town || data.address.municipality || data.address.village;
                    const state = data.address.state;
                    
                    const stateToUF = {
                        'Acre': 'AC', 'Alagoas': 'AL', 'Amapá': 'AP', 'Amazonas': 'AM',
                        'Bahia': 'BA', 'Ceará': 'CE', 'Distrito Federal': 'DF', 'Espírito Santo': 'ES',
                        'Goiás': 'GO', 'Maranhão': 'MA', 'Mato Grosso': 'MT', 'Mato Grosso do Sul': 'MS',
                        'Minas Gerais': 'MG', 'Pará': 'PA', 'Paraíba': 'PB', 'Paraná': 'PR',
                        'Pernambuco': 'PE', 'Piauí': 'PI', 'Rio de Janeiro': 'RJ', 'Rio Grande do Norte': 'RN',
                        'Rio Grande do Sul': 'RS', 'Rondônia': 'RO', 'Roraima': 'RR', 'Santa Catarina': 'SC',
                        'São Paulo': 'SP', 'Sergipe': 'SE', 'Tocantins': 'TO'
                    };
                    
                    const uf = stateToUF[state];
                    
                    if (uf && city) {
                        status.className = 'location-status success';
                        status.textContent = `✓ Localização: ${city}, ${uf}`;
                        quickSelectCity(uf, city);
                    } else {
                        status.className = 'location-status error';
                        status.textContent = 'Cidade não identificada. Selecione manualmente.';
                    }
                }
            } catch (error) {
                status.className = 'location-status error';
                status.textContent = 'Erro ao buscar. Selecione manualmente.';
            }
            resetDetectBtn();
        },
        (error) => {
            status.className = 'location-status error';
            status.textContent = error.code === 1 
                ? 'Permissão negada. Selecione manualmente.'
                : 'Localização indisponível. Selecione manualmente.';
            resetDetectBtn();
        },
        { enableHighAccuracy: true, timeout: 10000 }
    );
}

function resetDetectBtn() {
    const btn = document.getElementById('detectLocationBtn');
    btn.disabled = false;
    btn.innerHTML = '📍 Detectar minha localização automaticamente';
}
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/../partials/layout.php';
?>