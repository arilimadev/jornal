<?php
/**
 * A Cidade Fala v2.0 - Página do Estado
 */

use ACidadeFala\Config\Config;

$estado = $estado ?? [];
$cidades = $cidades ?? [];
$posts = $posts ?? [];

$pageTitle = ($estado['nome'] ?? 'Estado') . ' - Notícias';
$pageDescription = "Notícias de todas as cidades do estado " . ($estado['nome'] ?? '');

ob_start();
?>

<style>
.state-hero {
    background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-dark) 100%);
    color: white;
    padding: var(--space-12) 0;
    margin-bottom: var(--space-8);
}

.state-hero-content {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 var(--space-4);
}

.state-breadcrumb {
    font-size: var(--text-sm);
    opacity: 0.8;
    margin-bottom: var(--space-4);
}

.state-breadcrumb a {
    color: white;
    text-decoration: none;
}

.state-breadcrumb a:hover {
    text-decoration: underline;
}

.state-title {
    font-size: var(--text-4xl);
    font-weight: var(--font-extrabold);
    margin-bottom: var(--space-2);
}

.state-subtitle {
    font-size: var(--text-lg);
    opacity: 0.9;
}

.state-stats {
    display: flex;
    gap: var(--space-10);
    margin-top: var(--space-8);
}

.state-stat {
    text-align: center;
}

.state-stat-value {
    font-size: var(--text-3xl);
    font-weight: var(--font-bold);
}

.state-stat-label {
    font-size: var(--text-sm);
    opacity: 0.8;
}

.state-page {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 var(--space-4) var(--space-12);
}

.section-title {
    font-size: var(--text-2xl);
    font-weight: var(--font-bold);
    margin-bottom: var(--space-6);
    display: flex;
    align-items: center;
    gap: var(--space-2);
}

/* Cidades Grid */
.cities-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: var(--space-4);
    margin-bottom: var(--space-10);
}

.city-card {
    background: white;
    border-radius: var(--radius-xl);
    padding: var(--space-5);
    box-shadow: var(--shadow-sm);
    text-decoration: none;
    color: var(--color-gray-800);
    transition: all var(--transition-normal);
    text-align: center;
}

.city-card:hover {
    transform: translateY(-4px);
    box-shadow: var(--shadow-lg);
    border-color: var(--color-primary);
}

.city-card-name {
    font-weight: var(--font-semibold);
    font-size: var(--text-lg);
    margin-bottom: var(--space-2);
}

.city-card-stats {
    font-size: var(--text-sm);
    color: var(--color-gray-500);
}

/* Posts */
.posts-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    gap: var(--space-6);
}

.post-card {
    background: var(--color-white);
    border-radius: var(--radius-xl);
    overflow: hidden;
    box-shadow: var(--shadow-sm);
    transition: all var(--transition-normal);
}

.post-card:hover {
    transform: translateY(-4px);
    box-shadow: var(--shadow-lg);
}

.post-card-image {
    width: 100%;
    height: 180px;
    object-fit: cover;
    background: var(--color-gray-100);
}

.post-card-body {
    padding: var(--space-5);
}

.post-card-location {
    font-size: var(--text-xs);
    color: var(--color-gray-500);
    margin-bottom: var(--space-2);
}

.post-card-category {
    display: inline-block;
    padding: var(--space-1) var(--space-2);
    background: var(--color-primary-50);
    color: var(--color-primary);
    font-size: var(--text-xs);
    font-weight: var(--font-semibold);
    border-radius: var(--radius-full);
    margin-bottom: var(--space-2);
}

.post-card-title {
    font-size: var(--text-lg);
    font-weight: var(--font-bold);
    margin-bottom: var(--space-2);
    line-height: 1.3;
}

.post-card-title a {
    color: var(--color-gray-900);
    text-decoration: none;
}

.post-card-title a:hover {
    color: var(--color-primary);
}

.post-card-meta {
    display: flex;
    gap: var(--space-4);
    font-size: var(--text-sm);
    color: var(--color-gray-500);
}

.load-more {
    text-align: center;
    margin-top: var(--space-8);
}

.btn-load-more {
    padding: var(--space-3) var(--space-8);
    background: white;
    border: 2px solid var(--color-primary);
    color: var(--color-primary);
    border-radius: var(--radius-lg);
    font-size: var(--text-base);
    font-weight: var(--font-semibold);
    cursor: pointer;
    transition: all var(--transition-fast);
}

.btn-load-more:hover {
    background: var(--color-primary);
    color: white;
}
</style>

<!-- Hero -->
<div class="state-hero">
    <div class="state-hero-content">
        <div class="state-breadcrumb">
            <a href="<?= url('/') ?>">Início</a> › <?= e($estado['nome'] ?? '') ?>
        </div>
        
        <h1 class="state-title">🗺️ <?= e($estado['nome'] ?? 'Estado') ?></h1>
        <p class="state-subtitle">Notícias de todas as cidades do estado</p>
        
        <div class="state-stats">
            <div class="state-stat">
                <div class="state-stat-value"><?= count($cidades) ?></div>
                <div class="state-stat-label">Cidades</div>
            </div>
            <div class="state-stat">
                <div class="state-stat-value"><?= number_format($stats['total_posts'] ?? 0) ?></div>
                <div class="state-stat-label">Publicações</div>
            </div>
            <div class="state-stat">
                <div class="state-stat-value"><?= number_format($stats['total_autores'] ?? 0) ?></div>
                <div class="state-stat-label">Autores</div>
            </div>
        </div>
    </div>
</div>

<div class="state-page">
    <!-- Cidades -->
    <h2 class="section-title">🏙️ Cidades</h2>
    
    <div class="cities-grid">
        <?php foreach ($cidades as $cidade): ?>
            <a href="<?= url($estado['uf'] . '/' . $cidade['slug']) ?>" class="city-card">
                <div class="city-card-name"><?= e($cidade['nome']) ?></div>
                <div class="city-card-stats">
                    <?= $cidade['total_posts'] ?? 0 ?> posts
                </div>
            </a>
        <?php endforeach; ?>
    </div>
    
    <!-- Últimas notícias -->
    <h2 class="section-title">📰 Últimas Notícias</h2>
    
    <?php if (!empty($posts)): ?>
        <div class="posts-grid">
            <?php foreach ($posts as $post): ?>
                <article class="post-card">
                    <?php if ($post['imagem_capa']): ?>
                        <img src="<?= upload($post['imagem_capa']) ?>" class="post-card-image" alt="<?= e($post['titulo']) ?>">
                    <?php else: ?>
                        <div class="post-card-image" style="display:flex;align-items:center;justify-content:center;font-size:48px;color:#d1d5db;">📰</div>
                    <?php endif; ?>
                    
                    <div class="post-card-body">
                        <div class="post-card-location">
                            📍 <?= e($post['cidade_nome'] ?? '') ?>
                        </div>
                        
                        <?php if (!empty($post['categoria_nome'])): ?>
                            <span class="post-card-category"><?= e($post['categoria_nome']) ?></span>
                        <?php endif; ?>
                        
                        <h3 class="post-card-title">
                            <a href="<?= url($estado['uf'] . '/' . $post['cidade_slug'] . '/' . $post['slug']) ?>">
                                <?= e($post['titulo']) ?>
                            </a>
                        </h3>
                        
                        <div class="post-card-meta">
                            <span>👤 <?= $post['anonimo'] ? 'Anônimo' : e($post['autor_nome'] ?? '') ?></span>
                            <span>📅 <?= timeAgo($post['publicado_em'] ?? $post['created_at']) ?></span>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
        
        <div class="load-more">
            <button class="btn-load-more" onclick="carregarMais()">
                Ver mais notícias
            </button>
        </div>
    <?php else: ?>
        <div style="text-align:center;padding:60px;color:#64748b;">
            <div style="font-size:64px;opacity:0.3;margin-bottom:16px;">📭</div>
            <h3>Nenhuma publicação ainda</h3>
            <p>Seja o primeiro a publicar neste estado!</p>
        </div>
    <?php endif; ?>
</div>

<script>
let pagina = 1;

async function carregarMais() {
    pagina++;
    try {
        const res = await fetch(`<?= url('api/posts') ?>?estado_id=<?= $estado['id'] ?>&page=${pagina}`);
        const data = await res.json();
        
        if (data.success && data.posts.length > 0) {
            const grid = document.querySelector('.posts-grid');
            data.posts.forEach(post => {
                grid.innerHTML += `
                    <article class="post-card">
                        ${post.imagem_capa ? 
                            `<img src="${post.imagem_capa}" class="post-card-image" alt="">` :
                            `<div class="post-card-image" style="display:flex;align-items:center;justify-content:center;font-size:48px;color:#d1d5db;">📰</div>`
                        }
                        <div class="post-card-body">
                            <div class="post-card-location">📍 ${post.cidade_nome}</div>
                            <h3 class="post-card-title">
                                <a href="<?= url($estado['uf']) ?>/${post.cidade_slug}/${post.slug}">
                                    ${post.titulo}
                                </a>
                            </h3>
                            <div class="post-card-meta">
                                <span>👤 ${post.anonimo ? 'Anônimo' : post.autor_nome}</span>
                            </div>
                        </div>
                    </article>
                `;
            });
            
            if (!data.hasMore) {
                document.querySelector('.btn-load-more').style.display = 'none';
            }
        } else {
            document.querySelector('.btn-load-more').style.display = 'none';
        }
    } catch (e) {
        console.error('Erro ao carregar mais posts');
    }
}
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/../partials/layout.php';
?>
