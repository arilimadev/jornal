<?php
/**
 * A Cidade Fala v2.0 - Página de Anúncio
 */

use ACidadeFala\Config\Config;

$pageTitle = "Anuncie Conosco";
$pageDescription = "Anuncie no A Cidade Fala e alcance milhares de pessoas na sua cidade. Planos a partir de R$ 60/mês.";

$bannerPrecos = $bannerPrecos ?? [];
$destaquePrecos = $destaquePrecos ?? [];
$posicoes = $posicoes ?? [];

ob_start();
?>

<style>
.advertise-hero {
    background: linear-gradient(135deg, var(--color-primary) 0%, #7c3aed 100%);
    color: white;
    padding: var(--space-16) var(--space-4);
    text-align: center;
}

.advertise-hero h1 {
    font-size: var(--text-4xl);
    font-weight: var(--font-extrabold);
    margin-bottom: var(--space-4);
}

.advertise-hero p {
    font-size: var(--text-xl);
    opacity: 0.9;
    max-width: 600px;
    margin: 0 auto;
}

.advertise-stats {
    display: flex;
    justify-content: center;
    gap: var(--space-12);
    margin-top: var(--space-10);
}

.advertise-stat {
    text-align: center;
}

.advertise-stat-value {
    font-size: var(--text-4xl);
    font-weight: var(--font-extrabold);
}

.advertise-stat-label {
    font-size: var(--text-sm);
    opacity: 0.8;
}

.advertise-content {
    max-width: 1200px;
    margin: 0 auto;
    padding: var(--space-12) var(--space-4);
}

.section-title {
    text-align: center;
    margin-bottom: var(--space-10);
}

.section-title h2 {
    font-size: var(--text-3xl);
    font-weight: var(--font-bold);
    margin-bottom: var(--space-2);
}

.section-title p {
    color: var(--color-gray-600);
    font-size: var(--text-lg);
}

/* Posições de Banner */
.positions-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: var(--space-6);
    margin-bottom: var(--space-12);
}

.position-card {
    background: var(--color-white);
    border-radius: var(--radius-xl);
    padding: var(--space-6);
    box-shadow: var(--shadow-md);
    border: 2px solid transparent;
    transition: all var(--transition-normal);
}

.position-card:hover {
    border-color: var(--color-primary);
    transform: translateY(-4px);
}

.position-icon {
    width: 60px;
    height: 60px;
    background: var(--color-primary-50);
    border-radius: var(--radius-lg);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 28px;
    margin-bottom: var(--space-4);
}

.position-name {
    font-size: var(--text-xl);
    font-weight: var(--font-bold);
    margin-bottom: var(--space-2);
}

.position-desc {
    color: var(--color-gray-600);
    font-size: var(--text-sm);
    margin-bottom: var(--space-4);
}

.position-size {
    background: var(--color-gray-100);
    padding: var(--space-2) var(--space-3);
    border-radius: var(--radius-md);
    font-size: var(--text-sm);
    display: inline-block;
    margin-bottom: var(--space-4);
}

.position-price {
    font-size: var(--text-2xl);
    font-weight: var(--font-extrabold);
    color: var(--color-primary);
}

.position-price small {
    font-size: var(--text-sm);
    font-weight: normal;
    color: var(--color-gray-500);
}

/* Tabela de Preços */
.pricing-table {
    background: var(--color-white);
    border-radius: var(--radius-xl);
    overflow: hidden;
    box-shadow: var(--shadow-lg);
    margin-bottom: var(--space-12);
}

.pricing-table table {
    width: 100%;
    border-collapse: collapse;
}

.pricing-table th,
.pricing-table td {
    padding: var(--space-4);
    text-align: left;
    border-bottom: 1px solid var(--color-gray-100);
}

.pricing-table th {
    background: var(--color-gray-50);
    font-weight: var(--font-semibold);
    font-size: var(--text-sm);
    color: var(--color-gray-600);
}

.pricing-table tr:hover {
    background: var(--color-gray-50);
}

.price-value {
    font-size: var(--text-lg);
    font-weight: var(--font-bold);
    color: var(--color-success);
}

/* Destaques */
.highlight-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: var(--space-6);
    margin-bottom: var(--space-12);
}

.highlight-card {
    background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
    border-radius: var(--radius-xl);
    padding: var(--space-6);
    text-align: center;
}

.highlight-card-icon {
    font-size: 48px;
    margin-bottom: var(--space-4);
}

.highlight-card-title {
    font-size: var(--text-xl);
    font-weight: var(--font-bold);
    margin-bottom: var(--space-2);
}

.highlight-card-desc {
    color: var(--color-gray-700);
    font-size: var(--text-sm);
    margin-bottom: var(--space-4);
}

.highlight-card-price {
    font-size: var(--text-3xl);
    font-weight: var(--font-extrabold);
    color: var(--color-gray-900);
}

.highlight-card-price small {
    font-size: var(--text-base);
    font-weight: normal;
}

/* CTA */
.cta-section {
    background: var(--color-gray-900);
    color: white;
    padding: var(--space-12);
    border-radius: var(--radius-2xl);
    text-align: center;
    margin-bottom: var(--space-12);
}

.cta-section h2 {
    font-size: var(--text-3xl);
    font-weight: var(--font-bold);
    margin-bottom: var(--space-4);
}

.cta-section p {
    font-size: var(--text-lg);
    opacity: 0.8;
    margin-bottom: var(--space-6);
}

.cta-buttons {
    display: flex;
    gap: var(--space-4);
    justify-content: center;
    flex-wrap: wrap;
}

.btn-cta {
    padding: var(--space-4) var(--space-8);
    font-size: var(--text-lg);
    font-weight: var(--font-semibold);
    border-radius: var(--radius-lg);
    text-decoration: none;
    transition: all var(--transition-fast);
}

.btn-cta-primary {
    background: var(--color-primary);
    color: white;
}

.btn-cta-primary:hover {
    background: var(--color-primary-dark);
    transform: translateY(-2px);
}

.btn-cta-outline {
    background: transparent;
    color: white;
    border: 2px solid white;
}

.btn-cta-outline:hover {
    background: white;
    color: var(--color-gray-900);
}

/* Benefits */
.benefits-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: var(--space-6);
    margin-bottom: var(--space-12);
}

.benefit-item {
    display: flex;
    gap: var(--space-4);
}

.benefit-icon {
    width: 48px;
    height: 48px;
    background: var(--color-primary-50);
    border-radius: var(--radius-lg);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    flex-shrink: 0;
}

.benefit-content h4 {
    font-weight: var(--font-semibold);
    margin-bottom: var(--space-1);
}

.benefit-content p {
    color: var(--color-gray-600);
    font-size: var(--text-sm);
}

/* FAQ */
.faq-list {
    max-width: 800px;
    margin: 0 auto;
}

.faq-item {
    background: var(--color-white);
    border-radius: var(--radius-lg);
    margin-bottom: var(--space-4);
    box-shadow: var(--shadow-sm);
}

.faq-question {
    padding: var(--space-5);
    font-weight: var(--font-semibold);
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.faq-answer {
    padding: 0 var(--space-5) var(--space-5);
    color: var(--color-gray-600);
    display: none;
}

.faq-item.open .faq-answer {
    display: block;
}
</style>

<!-- Hero -->
<div class="advertise-hero">
    <h1>📢 Anuncie no <?= e(Config::SITE_NAME) ?></h1>
    <p>Alcance milhares de leitores na sua cidade com nossos planos de publicidade segmentada por região.</p>
    
    <div class="advertise-stats">
        <div class="advertise-stat">
            <div class="advertise-stat-value">50K+</div>
            <div class="advertise-stat-label">Visitantes/mês</div>
        </div>
        <div class="advertise-stat">
            <div class="advertise-stat-value">20+</div>
            <div class="advertise-stat-label">Cidades</div>
        </div>
        <div class="advertise-stat">
            <div class="advertise-stat-value">100%</div>
            <div class="advertise-stat-label">Segmentado</div>
        </div>
    </div>
</div>

<div class="advertise-content">
    
    <!-- Benefícios -->
    <div class="section-title">
        <h2>Por que anunciar conosco?</h2>
    </div>
    
    <div class="benefits-grid">
        <div class="benefit-item">
            <div class="benefit-icon">🎯</div>
            <div class="benefit-content">
                <h4>Segmentação por Cidade</h4>
                <p>Seu anúncio aparece apenas para leitores da sua região</p>
            </div>
        </div>
        <div class="benefit-item">
            <div class="benefit-icon">📊</div>
            <div class="benefit-content">
                <h4>Relatórios Detalhados</h4>
                <p>Acompanhe impressões, cliques e conversões em tempo real</p>
            </div>
        </div>
        <div class="benefit-item">
            <div class="benefit-icon">💰</div>
            <div class="benefit-content">
                <h4>Preços Acessíveis</h4>
                <p>Planos a partir de R$ 60 por mês para negócios locais</p>
            </div>
        </div>
        <div class="benefit-item">
            <div class="benefit-icon">🚀</div>
            <div class="benefit-content">
                <h4>Ativação Rápida</h4>
                <p>Seu anúncio no ar em até 24 horas após aprovação</p>
            </div>
        </div>
    </div>
    
    <!-- Posições de Banner -->
    <div class="section-title">
        <h2>🖼️ Posições de Banner</h2>
        <p>Escolha onde seu anúncio será exibido</p>
    </div>
    
    <div class="positions-grid">
        <?php foreach ($posicoes as $pos): ?>
        <div class="position-card">
            <div class="position-icon">
                <?php
                $icon = match($pos['local'] ?? '') {
                    'home' => '🏠',
                    'cidade' => '🏙️',
                    'noticia' => '📰',
                    'footer' => '📍',
                    default => '🖼️'
                };
                echo $icon;
                ?>
            </div>
            <h3 class="position-name"><?= e($pos['nome']) ?></h3>
            <p class="position-desc"><?= e($pos['descricao'] ?? 'Banner em posição estratégica') ?></p>
            <?php if ($pos['largura'] && $pos['altura']): ?>
                <span class="position-size"><?= $pos['largura'] ?> x <?= $pos['altura'] ?> px</span>
            <?php endif; ?>
            <div class="position-price">
                A partir de R$ <?= number_format($pos['preco_minimo'] ?? 60, 0, ',', '.') ?>
                <small>/mês</small>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    
    <!-- Tabela de Preços de Banner -->
    <div class="section-title">
        <h2>💰 Tabela de Preços - Banners</h2>
    </div>
    
    <div class="pricing-table">
        <table>
            <thead>
                <tr>
                    <th>Posição</th>
                    <th>Abrangência</th>
                    <th>10 dias</th>
                    <th>30 dias</th>
                    <th>90 dias</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Agrupar preços por posição e região
                $precosAgrupados = [];
                foreach ($bannerPrecos as $p) {
                    $key = $p['posicao_id'] . '-' . $p['tipo_regiao'];
                    if (!isset($precosAgrupados[$key])) {
                        $precosAgrupados[$key] = [
                            'posicao' => $p['posicao_nome'] ?? 'Banner',
                            'regiao' => $p['tipo_regiao'],
                            'precos' => []
                        ];
                    }
                    $precosAgrupados[$key]['precos'][$p['dias']] = $p['preco'];
                }
                
                foreach ($precosAgrupados as $grupo):
                ?>
                <tr>
                    <td><strong><?= e($grupo['posicao']) ?></strong></td>
                    <td>
                        <?= $grupo['regiao'] === 'cidade' ? '🏙️ Por cidade' : ($grupo['regiao'] === 'estado' ? '🗺️ Por estado' : '📍 Múltiplas cidades') ?>
                    </td>
                    <td>
                        <?php if (isset($grupo['precos'][10])): ?>
                            <span class="price-value">R$ <?= number_format($grupo['precos'][10], 0, ',', '.') ?></span>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (isset($grupo['precos'][30])): ?>
                            <span class="price-value">R$ <?= number_format($grupo['precos'][30], 0, ',', '.') ?></span>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (isset($grupo['precos'][90])): ?>
                            <span class="price-value">R$ <?= number_format($grupo['precos'][90], 0, ',', '.') ?></span>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Destaques -->
    <div class="section-title">
        <h2>⭐ Destaque sua Publicação</h2>
        <p>Dê mais visibilidade às suas notícias</p>
    </div>
    
    <div class="highlight-cards">
        <?php foreach ($destaquePrecos as $preco): ?>
        <div class="highlight-card">
            <div class="highlight-card-icon">
                <?= $preco['tipo'] === 'home' ? '🏠' : ($preco['tipo'] === 'cidade' ? '🏙️' : '🏷️') ?>
            </div>
            <h3 class="highlight-card-title">
                Destaque <?= ucfirst($preco['tipo']) ?>
            </h3>
            <p class="highlight-card-desc">
                <?= e($preco['descricao'] ?? 'Sua publicação em destaque por ' . $preco['dias'] . ' dias') ?>
            </p>
            <div class="highlight-card-price">
                R$ <?= number_format($preco['preco'], 0, ',', '.') ?>
                <small>/ <?= $preco['dias'] ?> dias</small>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    
    <!-- CTA -->
    <div class="cta-section">
        <h2>Pronto para começar?</h2>
        <p>Crie sua conta ou faça login para contratar um plano de anúncio.</p>
        <div class="cta-buttons">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="<?= url('autor/anunciar') ?>" class="btn-cta btn-cta-primary">
                    Criar Anúncio
                </a>
            <?php else: ?>
                <a href="<?= url('registro') ?>" class="btn-cta btn-cta-primary">
                    Criar Conta Grátis
                </a>
                <a href="<?= url('login') ?>" class="btn-cta btn-cta-outline">
                    Já tenho conta
                </a>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- FAQ -->
    <div class="section-title">
        <h2>❓ Perguntas Frequentes</h2>
    </div>
    
    <div class="faq-list">
        <div class="faq-item">
            <div class="faq-question" onclick="toggleFaq(this)">
                Como funciona a segmentação por cidade?
                <span>+</span>
            </div>
            <div class="faq-answer">
                Seu anúncio será exibido apenas para leitores que estão visualizando conteúdo da cidade selecionada. Isso garante que você alcance exatamente o público que deseja.
            </div>
        </div>
        <div class="faq-item">
            <div class="faq-question" onclick="toggleFaq(this)">
                Quanto tempo leva para meu anúncio ser aprovado?
                <span>+</span>
            </div>
            <div class="faq-answer">
                Após o pagamento, seu anúncio passa por uma revisão que leva até 24 horas. Se tudo estiver correto, será ativado automaticamente.
            </div>
        </div>
        <div class="faq-item">
            <div class="faq-question" onclick="toggleFaq(this)">
                Posso cancelar meu anúncio?
                <span>+</span>
            </div>
            <div class="faq-answer">
                Sim, você pode pausar ou cancelar seu anúncio a qualquer momento. Não fazemos reembolso de valores já pagos, mas você pode usar o saldo em campanhas futuras.
            </div>
        </div>
        <div class="faq-item">
            <div class="faq-question" onclick="toggleFaq(this)">
                Quais formatos de imagem são aceitos?
                <span>+</span>
            </div>
            <div class="faq-answer">
                Aceitamos imagens nos formatos JPG, PNG e WebP. Recomendamos que a imagem tenha o tamanho exato da posição escolhida para melhor qualidade.
            </div>
        </div>
    </div>
    
</div>

<script>
function toggleFaq(element) {
    const item = element.parentElement;
    item.classList.toggle('open');
    element.querySelector('span').textContent = item.classList.contains('open') ? '−' : '+';
}
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/../partials/layout.php';
?>
