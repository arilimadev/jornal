<?php
use ACidadeFala\Config\Config;
$pageTitle = "Política de Privacidade";
ob_start();
?>

<div class="container" style="padding:var(--space-12) 0;">
    <div style="max-width:800px;margin:0 auto;">
        <h1 style="font-size:var(--text-4xl);margin-bottom:var(--space-6);">Política de Privacidade</h1>
        <p style="color:var(--color-gray-500);margin-bottom:var(--space-8);">Última atualização: <?= date('d/m/Y') ?></p>
        
        <div style="font-size:var(--text-base);line-height:var(--leading-relaxed);color:var(--color-gray-700);">
            
            <h2 style="font-size:var(--text-xl);margin:var(--space-8) 0 var(--space-4);">1. Informações que Coletamos</h2>
            <p style="margin-bottom:var(--space-4);">Coletamos as seguintes informações:</p>
            <ul style="margin-left:var(--space-6);margin-bottom:var(--space-4);">
                <li style="margin-bottom:var(--space-2);">Nome e email ao se cadastrar</li>
                <li style="margin-bottom:var(--space-2);">Conteúdo que você publica (notícias, opiniões, comentários)</li>
                <li style="margin-bottom:var(--space-2);">Dados de navegação (cookies, IP, dispositivo)</li>
            </ul>
            
            <h2 style="font-size:var(--text-xl);margin:var(--space-8) 0 var(--space-4);">2. Como Usamos suas Informações</h2>
            <ul style="margin-left:var(--space-6);margin-bottom:var(--space-4);">
                <li style="margin-bottom:var(--space-2);">Para fornecer e melhorar nossos serviços</li>
                <li style="margin-bottom:var(--space-2);">Para enviar notificações e atualizações</li>
                <li style="margin-bottom:var(--space-2);">Para personalizar sua experiência</li>
                <li style="margin-bottom:var(--space-2);">Para análises estatísticas</li>
            </ul>
            
            <h2 style="font-size:var(--text-xl);margin:var(--space-8) 0 var(--space-4);">3. Compartilhamento de Dados</h2>
            <p style="margin-bottom:var(--space-4);">
                Não vendemos seus dados pessoais. Podemos compartilhar informações apenas:
            </p>
            <ul style="margin-left:var(--space-6);margin-bottom:var(--space-4);">
                <li style="margin-bottom:var(--space-2);">Com seu consentimento</li>
                <li style="margin-bottom:var(--space-2);">Para cumprir obrigações legais</li>
                <li style="margin-bottom:var(--space-2);">Com prestadores de serviço essenciais</li>
            </ul>
            
            <h2 style="font-size:var(--text-xl);margin:var(--space-8) 0 var(--space-4);">4. Seus Direitos</h2>
            <p style="margin-bottom:var(--space-4);">Você tem direito a:</p>
            <ul style="margin-left:var(--space-6);margin-bottom:var(--space-4);">
                <li style="margin-bottom:var(--space-2);">Acessar seus dados pessoais</li>
                <li style="margin-bottom:var(--space-2);">Corrigir dados incorretos</li>
                <li style="margin-bottom:var(--space-2);">Solicitar exclusão de seus dados</li>
                <li style="margin-bottom:var(--space-2);">Revogar consentimento</li>
            </ul>
            
            <h2 style="font-size:var(--text-xl);margin:var(--space-8) 0 var(--space-4);">5. Cookies</h2>
            <p style="margin-bottom:var(--space-4);">
                Utilizamos cookies para melhorar sua experiência, lembrar suas preferências e analisar o uso da plataforma.
            </p>
            
            <h2 style="font-size:var(--text-xl);margin:var(--space-8) 0 var(--space-4);">6. Segurança</h2>
            <p style="margin-bottom:var(--space-4);">
                Implementamos medidas de segurança para proteger suas informações contra acesso não autorizado.
            </p>
            
            <h2 style="font-size:var(--text-xl);margin:var(--space-8) 0 var(--space-4);">7. Contato</h2>
            <p>
                Para questões sobre privacidade, contate-nos através da <a href="<?= url('contato') ?>">página de contato</a>.
            </p>
            
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../partials/layout.php';
?>
