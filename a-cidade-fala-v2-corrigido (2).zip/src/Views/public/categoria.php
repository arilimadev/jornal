<?php
/**
 * A Cidade Fala v2.0 - Página de Categoria
 */

use ACidadeFala\Config\Config;

$categoria = $categoria ?? [];
$posts = $posts ?? [];
$cidades = $cidades ?? [];

$pageTitle = ($categoria['nome'] ?? 'Categoria') . ' - Notícias';
$pageDescription = "Notícias de " . ($categoria['nome'] ?? 'categoria') . " em sua cidade.";

ob_start();
?>

<style>
.category-hero {
    background: <?= $categoria['cor'] ?? 'var(--color-primary)' ?>;
    color: white;
    padding: var(--space-12) 0;
    margin-bottom: var(--space-8);
}

.category-hero-content {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 var(--space-4);
    text-align: center;
}

.category-icon {
    font-size: 64px;
    margin-bottom: var(--space-4);
}

.category-title {
    font-size: var(--text-4xl);
    font-weight: var(--font-extrabold);
    margin-bottom: var(--space-2);
}

.category-desc {
    font-size: var(--text-lg);
    opacity: 0.9;
    max-width: 600px;
    margin: 0 auto;
}

.category-stats {
    display: flex;
    justify-content: center;
    gap: var(--space-10);
    margin-top: var(--space-8);
}

.category-stat {
    text-align: center;
}

.category-stat-value {
    font-size: var(--text-3xl);
    font-weight: var(--font-bold);
}

.category-stat-label {
    font-size: var(--text-sm);
    opacity: 0.8;
}

.category-page {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 var(--space-4) var(--space-12);
}

.category-filters {
    display: flex;
    gap: var(--space-4);
    margin-bottom: var(--space-6);
    flex-wrap: wrap;
    align-items: center;
}

.filter-select {
    padding: var(--space-2) var(--space-4);
    border: 1px solid var(--color-gray-200);
    border-radius: var(--radius-lg);
    font-size: var(--text-sm);
    background: white;
}

.posts-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    gap: var(--space-6);
}

.post-card {
    background: var(--color-white);
    border-radius: var(--radius-xl);
    overflow: hidden;
    box-shadow: var(--shadow-sm);
    transition: all var(--transition-normal);
}

.post-card:hover {
    transform: translateY(-4px);
    box-shadow: var(--shadow-lg);
}

.post-card-image {
    width: 100%;
    height: 200px;
    object-fit: cover;
    background: var(--color-gray-100);
}

.post-card-body {
    padding: var(--space-5);
}

.post-card-location {
    font-size: var(--text-xs);
    color: var(--color-gray-500);
    margin-bottom: var(--space-2);
}

.post-card-title {
    font-size: var(--text-lg);
    font-weight: var(--font-bold);
    margin-bottom: var(--space-2);
    line-height: 1.3;
}

.post-card-title a {
    color: var(--color-gray-900);
    text-decoration: none;
}

.post-card-title a:hover {
    color: <?= $categoria['cor'] ?? 'var(--color-primary)' ?>;
}

.post-card-excerpt {
    font-size: var(--text-sm);
    color: var(--color-gray-600);
    margin-bottom: var(--space-4);
    line-height: 1.5;
}

.post-card-meta {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: var(--text-xs);
    color: var(--color-gray-500);
}

.empty-state {
    text-align: center;
    padding: var(--space-16);
    color: var(--color-gray-500);
}

.empty-state-icon {
    font-size: 64px;
    opacity: 0.3;
    margin-bottom: var(--space-4);
}

.pagination {
    display: flex;
    justify-content: center;
    gap: var(--space-2);
    margin-top: var(--space-8);
}

.pagination a, .pagination span {
    padding: var(--space-2) var(--space-4);
    border: 1px solid var(--color-gray-200);
    border-radius: var(--radius-md);
    text-decoration: none;
    color: var(--color-gray-600);
    font-size: var(--text-sm);
}

.pagination a:hover {
    background: var(--color-gray-100);
}

.pagination .active {
    background: <?= $categoria['cor'] ?? 'var(--color-primary)' ?>;
    color: white;
    border-color: <?= $categoria['cor'] ?? 'var(--color-primary)' ?>;
}
</style>

<!-- Hero -->
<div class="category-hero">
    <div class="category-hero-content">
        <div class="category-icon"><?= $categoria['icone'] ?? '📰' ?></div>
        <h1 class="category-title"><?= e($categoria['nome'] ?? 'Categoria') ?></h1>
        <p class="category-desc"><?= e($categoria['descricao'] ?? 'Todas as notícias desta categoria') ?></p>
        
        <div class="category-stats">
            <div class="category-stat">
                <div class="category-stat-value"><?= number_format($stats['total_posts'] ?? 0) ?></div>
                <div class="category-stat-label">Publicações</div>
            </div>
            <div class="category-stat">
                <div class="category-stat-value"><?= number_format($stats['total_cidades'] ?? 0) ?></div>
                <div class="category-stat-label">Cidades</div>
            </div>
            <div class="category-stat">
                <div class="category-stat-value"><?= number_format($stats['total_views'] ?? 0) ?></div>
                <div class="category-stat-label">Visualizações</div>
            </div>
        </div>
    </div>
</div>

<div class="category-page">
    <!-- Filtros -->
    <div class="category-filters">
        <select class="filter-select" onchange="filtrarPorCidade(this.value)">
            <option value="">Todas as cidades</option>
            <?php foreach ($cidades as $cidade): ?>
                <option value="<?= $cidade['id'] ?>" <?= ($_GET['cidade_id'] ?? '') == $cidade['id'] ? 'selected' : '' ?>>
                    <?= e($cidade['nome']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        
        <select class="filter-select" onchange="ordenarPor(this.value)">
            <option value="recentes" <?= ($_GET['ordem'] ?? '') === 'recentes' ? 'selected' : '' ?>>Mais recentes</option>
            <option value="populares" <?= ($_GET['ordem'] ?? '') === 'populares' ? 'selected' : '' ?>>Mais lidos</option>
        </select>
    </div>
    
    <!-- Posts -->
    <?php if (!empty($posts)): ?>
        <div class="posts-grid">
            <?php foreach ($posts as $post): ?>
                <article class="post-card">
                    <?php if ($post['imagem_capa']): ?>
                        <img src="<?= upload($post['imagem_capa']) ?>" class="post-card-image" alt="<?= e($post['titulo']) ?>">
                    <?php else: ?>
                        <div class="post-card-image" style="display:flex;align-items:center;justify-content:center;font-size:48px;color:#d1d5db;">
                            <?= $categoria['icone'] ?? '📰' ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="post-card-body">
                        <div class="post-card-location">
                            📍 <?= e($post['cidade_nome'] ?? '') ?>, <?= e($post['estado_uf'] ?? '') ?>
                        </div>
                        
                        <h3 class="post-card-title">
                            <a href="<?= postUrl($post) ?>">
                                <?= e($post['titulo']) ?>
                            </a>
                        </h3>
                        
                        <?php if (!empty($post['subtitulo'])): ?>
                            <p class="post-card-excerpt"><?= e(substr($post['subtitulo'], 0, 100)) ?></p>
                        <?php endif; ?>
                        
                        <div class="post-card-meta">
                            <span>👤 <?= $post['anonimo'] ? 'Anônimo' : e($post['autor_nome'] ?? '') ?></span>
                            <span>📅 <?= timeAgo($post['publicado_em'] ?? $post['created_at']) ?></span>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
        
        <!-- Paginação -->
        <?php if (($totalPages ?? 1) > 1): ?>
        <div class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?page=<?= $i ?>&cidade_id=<?= e($_GET['cidade_id'] ?? '') ?>&ordem=<?= e($_GET['ordem'] ?? '') ?>" 
                   class="<?= ($page ?? 1) == $i ? 'active' : '' ?>">
                    <?= $i ?>
                </a>
            <?php endfor; ?>
        </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="empty-state">
            <div class="empty-state-icon"><?= $categoria['icone'] ?? '📰' ?></div>
            <h3>Nenhuma publicação ainda</h3>
            <p>Seja o primeiro a publicar nesta categoria!</p>
            <a href="<?= url('autor/publicar') ?>" class="btn btn-primary" style="margin-top:16px;">
                ✍️ Criar Publicação
            </a>
        </div>
    <?php endif; ?>
</div>

<script>
function filtrarPorCidade(cidadeId) {
    const url = new URL(window.location.href);
    if (cidadeId) {
        url.searchParams.set('cidade_id', cidadeId);
    } else {
        url.searchParams.delete('cidade_id');
    }
    window.location.href = url.toString();
}

function ordenarPor(ordem) {
    const url = new URL(window.location.href);
    url.searchParams.set('ordem', ordem);
    window.location.href = url.toString();
}
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/../partials/layout.php';
?>
