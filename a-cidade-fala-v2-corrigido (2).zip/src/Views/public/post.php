<?php
/**
 * A Cidade Fala v2.0 - Visualização de Post
 */

use ACidadeFala\Config\Config;

$pageTitle = $post['titulo'] ?? 'Post';
$pageDescription = mb_substr(strip_tags($post['conteudo'] ?? ''), 0, 160);

ob_start();
?>

<style>
.post-page {
    padding: var(--space-6) 0;
}

.post-header {
    margin-bottom: var(--space-6);
}

.post-breadcrumb {
    display: flex;
    align-items: center;
    gap: var(--space-2);
    font-size: var(--text-sm);
    color: var(--color-gray-500);
    margin-bottom: var(--space-4);
}

.post-breadcrumb a {
    color: var(--color-gray-500);
}

.post-breadcrumb a:hover {
    color: var(--color-primary);
}

.post-badges {
    display: flex;
    gap: var(--space-2);
    margin-bottom: var(--space-4);
}

.post-title {
    font-size: var(--text-3xl);
    font-weight: var(--font-extrabold);
    line-height: var(--leading-tight);
    margin-bottom: var(--space-4);
}

@media (min-width: 768px) {
    .post-title {
        font-size: var(--text-4xl);
    }
}

.post-subtitle {
    font-size: var(--text-xl);
    color: var(--color-gray-600);
    margin-bottom: var(--space-6);
}

.post-meta {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: var(--space-4);
    padding: var(--space-4);
    background: var(--color-gray-50);
    border-radius: var(--radius-lg);
}

.post-author {
    display: flex;
    align-items: center;
    gap: var(--space-3);
}

.post-author-avatar {
    width: 48px;
    height: 48px;
    border-radius: var(--radius-full);
    background: var(--color-primary-100);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: var(--font-bold);
    color: var(--color-primary);
}

.post-author-info {
    display: flex;
    flex-direction: column;
}

.post-author-name {
    font-weight: var(--font-semibold);
}

.post-author-role {
    font-size: var(--text-sm);
    color: var(--color-gray-500);
}

.post-meta-item {
    display: flex;
    align-items: center;
    gap: var(--space-2);
    font-size: var(--text-sm);
    color: var(--color-gray-600);
}

.post-featured-image {
    width: 100%;
    border-radius: var(--radius-xl);
    margin-bottom: var(--space-6);
    overflow: hidden;
}

.post-featured-image img {
    width: 100%;
    height: auto;
}

.post-content {
    font-size: var(--text-lg);
    line-height: var(--leading-relaxed);
    color: var(--color-gray-800);
}

.post-content p {
    margin-bottom: var(--space-4);
}

.post-content h2 {
    margin-top: var(--space-8);
    margin-bottom: var(--space-4);
}

.post-content img {
    max-width: 100%;
    border-radius: var(--radius-lg);
    margin: var(--space-6) 0;
}

.post-share {
    display: flex;
    align-items: center;
    gap: var(--space-4);
    padding: var(--space-6);
    background: var(--color-gray-50);
    border-radius: var(--radius-xl);
    margin: var(--space-8) 0;
}

.post-share-label {
    font-weight: var(--font-semibold);
}

.post-share-buttons {
    display: flex;
    gap: var(--space-2);
}

.share-btn {
    width: 40px;
    height: 40px;
    border-radius: var(--radius-full);
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--color-white);
    transition: transform var(--transition-fast);
}

.share-btn:hover {
    transform: scale(1.1);
}

.share-btn.facebook { background: #1877f2; }
.share-btn.twitter { background: #000000; }
.share-btn.whatsapp { background: #25d366; }
.share-btn.telegram { background: #0088cc; }
.share-btn.linkedin { background: #0077b5; }
.share-btn.copy { background: #64748b; border: none; cursor: pointer; }

/* Author Box */
.author-box {
    display: flex;
    gap: var(--space-5);
    padding: var(--space-6);
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    border-radius: var(--radius-xl);
    margin-top: var(--space-10);
    border: 1px solid var(--color-gray-200);
}

.author-box-avatar {
    width: 80px;
    height: 80px;
    border-radius: var(--radius-full);
    background: var(--color-primary);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 32px;
    font-weight: bold;
    flex-shrink: 0;
    overflow: hidden;
}

.author-box-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.author-box-avatar.anonymous {
    background: var(--color-gray-400);
    font-size: 40px;
}

.author-box-info {
    flex: 1;
}

.author-box-label {
    font-size: var(--text-sm);
    color: var(--color-gray-500);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: var(--space-1);
}

.author-box-name {
    font-size: var(--text-xl);
    font-weight: var(--font-bold);
    margin-bottom: var(--space-2);
    display: flex;
    align-items: center;
    gap: var(--space-2);
}

.author-box-name a {
    color: var(--color-gray-900);
    text-decoration: none;
}

.author-box-name a:hover {
    color: var(--color-primary);
}

.verified-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: #3b82f6;
    color: white;
    font-size: 12px;
    font-weight: bold;
}

.author-box-bio {
    color: var(--color-gray-600);
    line-height: 1.6;
    margin-bottom: var(--space-3);
}

.author-box-link {
    font-weight: var(--font-medium);
    color: var(--color-primary);
    text-decoration: none;
}

.author-box-link:hover {
    text-decoration: underline;
}

.author-box-anonymous {
    background: linear-gradient(135deg, #fef3c7 0%, #fef9c3 100%);
    border-color: #fcd34d;
}

.comments-section {
    margin-top: var(--space-12);
}

.comments-title {
    font-size: var(--text-2xl);
    margin-bottom: var(--space-6);
    display: flex;
    align-items: center;
    gap: var(--space-2);
}

.comment-form {
    background: var(--color-gray-50);
    padding: var(--space-6);
    border-radius: var(--radius-xl);
    margin-bottom: var(--space-8);
}

.comments-list {
    display: flex;
    flex-direction: column;
    gap: var(--space-4);
}

.comment {
    background: var(--color-white);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-xl);
    padding: var(--space-5);
}

.comment-header {
    display: flex;
    align-items: center;
    gap: var(--space-3);
    margin-bottom: var(--space-3);
}

.comment-avatar {
    width: 40px;
    height: 40px;
    border-radius: var(--radius-full);
    background: var(--color-gray-200);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: var(--font-semibold);
    color: var(--color-gray-600);
}

.comment-author {
    font-weight: var(--font-semibold);
}

.comment-date {
    font-size: var(--text-sm);
    color: var(--color-gray-500);
}

.comment-content {
    color: var(--color-gray-700);
    line-height: var(--leading-relaxed);
}

.related-section {
    margin-top: var(--space-12);
    padding-top: var(--space-8);
    border-top: 1px solid var(--color-border);
}

.post-share{background:#f8fafc;padding:20px;border-radius:12px;margin:32px 0}
.post-share-label{font-weight:600;display:flex;align-items:center;gap:8px;margin-bottom:12px}
.post-share-buttons{display:flex;flex-wrap:wrap;gap:10px}
.share-btn{display:inline-flex;align-items:center;gap:6px;padding:10px 16px;border-radius:8px;font-size:14px;font-weight:500;text-decoration:none;transition:all .2s;border:none;cursor:pointer}
.share-btn.facebook{background:#1877f2;color:#fff}
.share-btn.twitter{background:#1da1f2;color:#fff}
.share-btn.whatsapp{background:#25d366;color:#fff}
.share-btn.telegram{background:#0088cc;color:#fff}
.share-btn.copy{background:#64748b;color:#fff}
.share-btn:hover{transform:translateY(-2px);box-shadow:0 4px 12px rgba(0,0,0,.2)}
</style>

<div class="post-page">
    <div class="container">
        <div class="content-layout">
            
            <!-- Conteúdo Principal -->
            <article class="content-main">
                
                <!-- Header do Post -->
                <header class="post-header">
                    <nav class="post-breadcrumb">
                        <a href="<?= url('/') ?>">🏠</a>
                        <span>›</span>
                        <a href="<?= url($post['tipo'] . 's') ?>"><?= ucfirst($post['tipo']) ?>s</a>
                        <span>›</span>
                        <span><?= e(mb_substr($post['titulo'], 0, 50)) ?>...</span>
                    </nav>
                    
                    <div class="post-badges">
                        <span class="badge badge-<?= $post['tipo'] ?>"><?= ucfirst($post['tipo']) ?></span>
                        <?php if ($post['categoria_id']): ?>
                            <?php $cat = Config::getCategory($post['categoria_id']); ?>
                            <?php if ($cat): ?>
                            <span class="badge badge-categoria"><?= $cat['icon'] ?> <?= e($cat['nome']) ?></span>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    
                    <h1 class="post-title"><?= e($post['titulo']) ?></h1>
                    
                    <?php if (!empty($post['subtitulo'])): ?>
                    <p class="post-subtitle"><?= e($post['subtitulo']) ?></p>
                    <?php endif; ?>
                    
                    <div class="post-meta">
                        <?php if (!$post['anonimo'] && isset($post['autor'])): ?>
                        <div class="post-author">
                            <div class="post-author-avatar">
                                <?= strtoupper(substr($post['autor']['nome'] ?? 'A', 0, 1)) ?>
                            </div>
                            <div class="post-author-info">
                                <span class="post-author-name"><?= e($post['autor']['nome'] ?? 'Autor') ?></span>
                                <span class="post-author-role">Colaborador</span>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="post-author">
                            <div class="post-author-avatar">
                                👤
                            </div>
                            <div class="post-author-info">
                                <span class="post-author-name">Cidadão Anônimo</span>
                                <span class="post-author-role">Colaborador</span>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <div class="post-meta-item">
                            📅
                            <?= formatDate($post['publicado_em'] ?? $post['created_at'], 'd/m/Y H:i') ?>
                        </div>
                        
                        <div class="post-meta-item">
                            👁️
                            <?= number_format($post['visualizacoes'] ?? 0) ?> visualizações
                        </div>
                    </div>
                </header>
                
                <!-- Imagem Destaque -->
                <?php if (!empty($post['imagem_capa'])): ?>
                <figure class="post-featured-image">
                    <img src="<?= upload($post['imagem_capa']) ?>" alt="<?= e($post['titulo']) ?>">
                </figure>
                <?php endif; ?>
                
                <!-- Conteúdo -->
                <div class="post-content">
                    <?= purifyHtml($post['conteudo'] ?? '') ?>
                </div>
                
                <!-- Compartilhar -->
                <div class="post-share">
                    <span class="post-share-label">📤 Compartilhe esta notícia:</span>
                    <div class="post-share-buttons">
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?= urlencode(Config::getBaseUrl() . $_SERVER['REQUEST_URI']) ?>" 
                           target="_blank" class="share-btn facebook" title="Compartilhar no Facebook">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
                        </a>
                        <a href="https://twitter.com/intent/tweet?text=<?= urlencode($post['titulo']) ?>&url=<?= urlencode(Config::getBaseUrl() . $_SERVER['REQUEST_URI']) ?>" 
                           target="_blank" class="share-btn twitter" title="Compartilhar no X/Twitter">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                        </a>
                        <a href="https://wa.me/?text=<?= urlencode($post['titulo'] . ' ' . Config::getBaseUrl() . $_SERVER['REQUEST_URI']) ?>" 
                           target="_blank" class="share-btn whatsapp" title="Compartilhar no WhatsApp">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                        </a>
                        <a href="https://t.me/share/url?url=<?= urlencode(Config::getBaseUrl() . $_SERVER['REQUEST_URI']) ?>&text=<?= urlencode($post['titulo']) ?>" 
                           target="_blank" class="share-btn telegram" title="Compartilhar no Telegram">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/></svg>
                        </a>
                        <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?= urlencode(Config::getBaseUrl() . $_SERVER['REQUEST_URI']) ?>" 
                           target="_blank" class="share-btn linkedin" title="Compartilhar no LinkedIn">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                        </a>
                        <button onclick="copyLink()" class="share-btn copy" title="Copiar Link">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
                        </button>
                    </div>
                </div>
                
                <script>
                function copyLink() {
                    navigator.clipboard.writeText(window.location.href);
                    alert('Link copiado!');
                }
                </script>
                
                <!-- Box do Autor -->
                <?php if (!($post['anonimo'] ?? false) && !empty($autor)): ?>
                <div class="author-box">
                    <div class="author-box-avatar">
                        <?php if (!empty($autor['avatar'])): ?>
                            <img src="<?= upload($autor['avatar']) ?>" alt="<?= e($autor['nome']) ?>">
                        <?php else: ?>
                            <?= strtoupper(substr($autor['nome'] ?? 'A', 0, 1)) ?>
                        <?php endif; ?>
                    </div>
                    <div class="author-box-info">
                        <div class="author-box-label">Escrito por</div>
                        <h3 class="author-box-name">
                            <a href="<?= url('perfil/' . $autor['id']) ?>"><?= e($autor['nome']) ?></a>
                            <?php if ($autor['verificado'] ?? false): ?>
                                <span class="verified-badge" title="Autor Verificado">✓</span>
                            <?php endif; ?>
                        </h3>
                        <?php if (!empty($autor['bio'])): ?>
                            <p class="author-box-bio"><?= e(mb_substr($autor['bio'], 0, 200)) ?><?= mb_strlen($autor['bio'] ?? '') > 200 ? '...' : '' ?></p>
                        <?php endif; ?>
                        <a href="<?= url('perfil/' . $autor['id']) ?>" class="author-box-link">Ver todos os artigos →</a>
                    </div>
                </div>
                <?php elseif ($post['anonimo'] ?? false): ?>
                <div class="author-box author-box-anonymous">
                    <div class="author-box-avatar anonymous">👤</div>
                    <div class="author-box-info">
                        <div class="author-box-label">Publicação</div>
                        <h3 class="author-box-name">Anônima</h3>
                        <p class="author-box-bio">Esta publicação foi enviada de forma anônima. A identidade do autor é protegida conforme nossa política de privacidade.</p>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Comentários -->
                <section class="comments-section">
                    <h2 class="comments-title">
                        💬
                        Comentários (<?= count($comentarios ?? []) ?>)
                    </h2>
                    
                    <?php if (isset($currentUser)): ?>
                    <form class="comment-form" id="commentForm">
                        <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                        <div class="form-group" style="margin-bottom:var(--space-4);">
                            <textarea name="conteudo" class="form-textarea" placeholder="Escreva seu comentário..." rows="4" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            📤 Enviar Comentário
                        </button>
                    </form>
                    <?php else: ?>
                    <div class="comment-form" style="text-align:center;">
                        <p style="margin-bottom:var(--space-4);color:var(--color-gray-600);">
                            Faça login para comentar nesta notícia.
                        </p>
                        <a href="<?= url('login') ?>" class="btn btn-primary">
                            🔐 Entrar para Comentar
                        </a>
                    </div>
                    <?php endif; ?>
                    
                    <div class="comments-list" id="commentsList">
                        <?php if (empty($comentarios)): ?>
                        <p style="text-align:center;color:var(--color-gray-500);padding:var(--space-8);">
                            Seja o primeiro a comentar!
                        </p>
                        <?php else: ?>
                            <?php foreach ($comentarios as $comentario): ?>
                            <div class="comment">
                                <div class="comment-header">
                                    <div class="comment-avatar">
                                        <?= strtoupper(substr($comentario['usuario_nome'] ?? 'U', 0, 1)) ?>
                                    </div>
                                    <div>
                                        <div class="comment-author"><?= e($comentario['usuario_nome'] ?? 'Usuário') ?></div>
                                        <div class="comment-date"><?= timeAgo($comentario['created_at']) ?></div>
                                    </div>
                                </div>
                                <div class="comment-content">
                                    <?= nl2br(e($comentario['conteudo'])) ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </section>
                
                <!-- Relacionados -->
                <?php if (!empty($relacionados)): ?>
                <section class="related-section">
                    <div class="section-header">
                        <h2 class="section-title">
                            📰
                            Notícias Relacionadas
                        </h2>
                    </div>
                    
                    <div class="news-grid">
                        <?php foreach (array_slice($relacionados, 0, 3) as $rel): ?>
                            <?php if ($rel['id'] != $post['id']): ?>
                            <article class="news-card">
                                <div class="news-card-image-wrapper">
                                    <?php if (!empty($rel['imagem_capa'])): ?>
                                    <img src="<?= upload($rel['imagem_capa']) ?>" alt="<?= e($rel['titulo']) ?>" class="news-card-image">
                                    <?php else: ?>
                                    <div class="news-card-image" style="background:var(--color-gray-200);"></div>
                                    <?php endif; ?>
                                </div>
                                <div class="news-card-content">
                                    <h3 class="news-card-title">
                                        <a href="<?= postUrl($rel) ?>">
                                            <?= e($rel['titulo']) ?>
                                        </a>
                                    </h3>
                                    <div class="news-card-footer">
                                        <span class="news-card-meta"><?= timeAgo($rel['publicado_em'] ?? $rel['created_at']) ?></span>
                                    </div>
                                </div>
                            </article>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </section>
                <?php endif; ?>
                
            </article>
            
            <!-- Sidebar -->
            <aside class="sidebar">
                <!-- Banner Sidebar -->
                <div class="ad-container">
                    <div class="ad-label">Publicidade</div>
                    <div class="ad-block ad-block-sidebar">
                        <span class="ad-placeholder">Anuncie aqui<br>300x250</span>
                    </div>
                </div>
                
                <!-- Mais Lidas -->
                <div class="sidebar-widget">
                    <h3 class="sidebar-widget-title">
                        🔥 Mais Lidas
                    </h3>
                    <?php if (!empty($relacionados)): ?>
                    <div class="news-list news-list-numbered">
                        <?php foreach (array_slice($relacionados, 0, 5) as $rel): ?>
                        <div class="news-list-item">
                            <div class="news-list-content">
                                <h4 class="news-list-title">
                                    <a href="<?= postUrl($rel) ?>">
                                        <?= e($rel['titulo']) ?>
                                    </a>
                                </h4>
                                <span class="news-list-meta"><?= timeAgo($rel['publicado_em'] ?? $rel['created_at']) ?></span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Banner -->
                <div class="ad-container">
                    <div class="ad-label">Publicidade</div>
                    <div class="ad-block ad-block-sidebar">
                        <span class="ad-placeholder">Anuncie aqui<br>300x250</span>
                    </div>
                </div>
            </aside>
            
        </div>
    </div>
</div>

<script>
document.getElementById('commentForm')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const btn = this.querySelector('button[type="submit"]');
    
    btn.disabled = true;
    btn.innerHTML = '⏳ Enviando...';
    
    try {
        const response = await fetch(window.ACF.apiUrl + '/comentarios', {
            method: 'POST',
            body: new URLSearchParams(formData),
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        
        const result = await response.json();
        
        if (result.success) {
            showToast('Comentário enviado! Aguardando aprovação.', 'success');
            this.reset();
        } else {
            showToast(result.error || 'Erro ao enviar comentário', 'error');
        }
    } catch (error) {
        showToast('Erro de conexão', 'error');
    }
    
    btn.disabled = false;
    btn.innerHTML = '📤 Enviar Comentário';
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/../partials/layout.php';
?>
