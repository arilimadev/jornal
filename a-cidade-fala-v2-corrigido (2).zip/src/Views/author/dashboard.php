<?php
$pageTitle = "Dashboard";
$currentPage = "dashboard";
$stats = $stats ?? ['total_posts' => 0, 'posts_aprovados' => 0, 'posts_pendentes' => 0, 'total_views' => 0];
$posts = $posts ?? [];
ob_start();
?>
<div class="page-header">
    <h1 class="page-title">Olá, <?= e(explode(' ', $_SESSION['user_nome'] ?? 'Usuário')[0]) ?>! 👋</h1>
    <p class="page-subtitle">Bem-vindo ao seu painel de autor. Aqui você pode gerenciar suas publicações.</p>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon" style="background:#dbeafe;color:#2563eb"><i data-lucide="file-text"></i></div>
        <div class="stat-value"><?= $stats['total_posts'] ?></div>
        <div class="stat-label">Total de Publicações</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#dcfce7;color:#16a34a"><i data-lucide="check-circle"></i></div>
        <div class="stat-value"><?= $stats['posts_aprovados'] ?></div>
        <div class="stat-label">Aprovadas</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#fef3c7;color:#d97706"><i data-lucide="clock"></i></div>
        <div class="stat-value"><?= $stats['posts_pendentes'] ?></div>
        <div class="stat-label">Aguardando Aprovação</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#f3e8ff;color:#9333ea"><i data-lucide="eye"></i></div>
        <div class="stat-value"><?= number_format($stats['total_views']) ?></div>
        <div class="stat-label">Visualizações</div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Publicações Recentes</h2>
        <a href="<?= url('autor/publicar') ?>" class="btn btn-primary"><i data-lucide="plus"></i> Nova Publicação</a>
    </div>
    
    <?php if (empty($posts)): ?>
    <div class="empty-state">
        <i data-lucide="file-x"></i>
        <p>Você ainda não tem publicações.</p>
        <a href="<?= url('autor/publicar') ?>" class="btn btn-primary" style="margin-top:16px">Criar Primeira Publicação</a>
    </div>
    <?php else: ?>
    <table class="table">
        <thead><tr><th>Título</th><th>Tipo</th><th>Status</th><th>Data</th><th>Ações</th></tr></thead>
        <tbody>
            <?php foreach (array_slice($posts, 0, 10) as $post): ?>
            <tr>
                <td><strong><?= e(mb_substr($post['titulo'], 0, 50)) ?><?= mb_strlen($post['titulo']) > 50 ? '...' : '' ?></strong></td>
                <td><?= ucfirst($post['tipo'] ?? 'Notícia') ?></td>
                <td><span class="status status-<?= $post['status'] ?>"><?= ucfirst($post['status']) ?></span></td>
                <td><?= formatDate($post['created_at'] ?? '') ?></td>
                <td>
                    <?php if ($post['status'] === 'aprovado'): ?>
                    <a href="#" target="_blank" title="Ver" style="margin-right:8px"><i data-lucide="external-link" style="width:18px;height:18px"></i></a>
                    <?php endif; ?>
                    <a href="<?= url('autor/editar/' . $post['id']) ?>" title="Editar"><i data-lucide="edit" style="width:18px;height:18px"></i></a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
