<?php
/**
 * A Cidade Fala v2.0 - Painel do Anunciante
 */

use ACidadeFala\Config\Config;

$pageTitle = "Meus Anúncios";
$currentPage = "anunciar";
$usuario = $usuario ?? [];
$banners = $banners ?? [];
$destaques = $destaques ?? [];

ob_start();
?>

<style>
.anunciante-page {
    max-width: 1200px;
    margin: 0 auto;
    padding: var(--space-8) var(--space-4);
}

.anunciante-header {
    background: linear-gradient(135deg, var(--color-primary) 0%, #7c3aed 100%);
    color: white;
    padding: var(--space-8);
    border-radius: var(--radius-2xl);
    margin-bottom: var(--space-8);
}

.anunciante-header h1 {
    font-size: var(--text-2xl);
    margin-bottom: var(--space-2);
}

.anunciante-header p {
    opacity: 0.9;
}

.quick-actions {
    display: flex;
    gap: var(--space-4);
    margin-top: var(--space-6);
    flex-wrap: wrap;
}

.stats-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: var(--space-4);
    margin-bottom: var(--space-8);
}

.stat-card {
    background: white;
    border-radius: var(--radius-xl);
    padding: var(--space-5);
    box-shadow: var(--shadow-sm);
    text-align: center;
}

.stat-value {
    font-size: var(--text-3xl);
    font-weight: var(--font-bold);
    color: var(--color-primary);
}

.stat-label {
    color: var(--color-gray-500);
    font-size: var(--text-sm);
}

.section-title {
    font-size: var(--text-xl);
    font-weight: var(--font-bold);
    margin-bottom: var(--space-4);
    display: flex;
    align-items: center;
    gap: var(--space-2);
}

.anuncios-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: var(--space-6);
    margin-bottom: var(--space-8);
}

.anuncio-card {
    background: white;
    border-radius: var(--radius-xl);
    overflow: hidden;
    box-shadow: var(--shadow-sm);
}

.anuncio-image {
    width: 100%;
    height: 150px;
    object-fit: cover;
    background: var(--color-gray-100);
}

.anuncio-body {
    padding: var(--space-5);
}

.anuncio-title {
    font-weight: var(--font-semibold);
    margin-bottom: var(--space-2);
}

.anuncio-meta {
    font-size: var(--text-sm);
    color: var(--color-gray-500);
    margin-bottom: var(--space-3);
}

.anuncio-stats {
    display: flex;
    gap: var(--space-4);
    font-size: var(--text-sm);
    padding: var(--space-3);
    background: var(--color-gray-50);
    border-radius: var(--radius-md);
    margin-bottom: var(--space-3);
}

.anuncio-status {
    display: inline-block;
    padding: var(--space-1) var(--space-3);
    border-radius: var(--radius-full);
    font-size: var(--text-xs);
    font-weight: var(--font-semibold);
}

.status-ativo { background: #dcfce7; color: #166534; }
.status-pendente { background: #fef3c7; color: #92400e; }
.status-expirado { background: #f1f5f9; color: #64748b; }
.status-rejeitado { background: #fee2e2; color: #991b1b; }

.anuncio-actions {
    display: flex;
    gap: var(--space-2);
    margin-top: var(--space-3);
}

.empty-state {
    text-align: center;
    padding: var(--space-12);
    background: white;
    border-radius: var(--radius-xl);
    color: var(--color-gray-500);
}

.empty-state-icon {
    font-size: 64px;
    opacity: 0.3;
    margin-bottom: var(--space-4);
}

.btn {
    padding: var(--space-2) var(--space-4);
    border-radius: var(--radius-lg);
    font-size: var(--text-sm);
    font-weight: var(--font-medium);
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: var(--space-2);
    cursor: pointer;
    border: none;
    transition: all var(--transition-fast);
}

.btn-primary { background: var(--color-primary); color: white; }
.btn-primary:hover { background: var(--color-primary-dark); }
.btn-outline { background: white; border: 1px solid var(--color-gray-300); color: var(--color-gray-700); }
.btn-outline:hover { background: var(--color-gray-50); }
.btn-sm { padding: var(--space-1) var(--space-3); font-size: var(--text-xs); }

/* Modal */
.modal {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.6);
    z-index: 1000;
    align-items: center;
    justify-content: center;
    padding: var(--space-4);
}
.modal.show { display: flex; }
.modal-content {
    background: white;
    border-radius: var(--radius-xl);
    max-width: 600px;
    width: 100%;
    max-height: 90vh;
    overflow-y: auto;
}
.modal-header {
    padding: var(--space-5);
    border-bottom: 1px solid var(--color-gray-200);
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.modal-body { padding: var(--space-5); }
.modal-footer {
    padding: var(--space-4) var(--space-5);
    border-top: 1px solid var(--color-gray-200);
    display: flex;
    gap: var(--space-3);
    justify-content: flex-end;
}

.form-group { margin-bottom: var(--space-4); }
.form-label { display: block; font-weight: var(--font-medium); margin-bottom: var(--space-2); }
.form-input, .form-select {
    width: 100%;
    padding: var(--space-3);
    border: 1px solid var(--color-gray-300);
    border-radius: var(--radius-lg);
    font-size: var(--text-base);
}
.form-input:focus, .form-select:focus {
    outline: none;
    border-color: var(--color-primary);
}

.grid-2 {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: var(--space-4);
}

.price-display {
    background: var(--color-primary-50);
    padding: var(--space-4);
    border-radius: var(--radius-lg);
    text-align: center;
    margin-top: var(--space-4);
}
.price-value {
    font-size: var(--text-3xl);
    font-weight: var(--font-bold);
    color: var(--color-primary);
}

.image-upload {
    border: 2px dashed var(--color-gray-300);
    border-radius: var(--radius-lg);
    padding: var(--space-8);
    text-align: center;
    cursor: pointer;
}
.image-upload:hover { border-color: var(--color-primary); }
</style>

<div class="anunciante-page">
    
    <!-- Header -->
    <div class="anunciante-header">
        <h1>📢 Olá, <?= e($usuario['nome'] ?? 'Anunciante') ?>!</h1>
        <p>Gerencie seus banners e destaques</p>
        
        <div class="quick-actions">
            <button class="btn" onclick="abrirModalBanner()" style="background:white;color:#1e40af;font-weight:600;">
                🖼️ Novo Banner
            </button>
            <button class="btn" onclick="abrirModalDestaque()" style="background:rgba(255,255,255,0.2);color:white;border:2px solid white;">
                ⭐ Destacar Post
            </button>
            <a href="<?= url('anunciar') ?>" class="btn" style="background:rgba(255,255,255,0.2);color:white;border:2px solid white;">
                💰 Ver Preços
            </a>
        </div>
    </div>
    
    <!-- Stats -->
    <div class="stats-row">
        <div class="stat-card">
            <div class="stat-value"><?= $stats['banners_ativos'] ?? 0 ?></div>
            <div class="stat-label">Banners Ativos</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?= number_format($stats['impressoes_total'] ?? 0) ?></div>
            <div class="stat-label">Impressões Totais</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?= number_format($stats['cliques_total'] ?? 0) ?></div>
            <div class="stat-label">Cliques Totais</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?= $stats['impressoes_total'] > 0 ? number_format(($stats['cliques_total'] / $stats['impressoes_total']) * 100, 2) : 0 ?>%</div>
            <div class="stat-label">Taxa de Cliques (CTR)</div>
        </div>
    </div>
    
    <!-- Meus Banners -->
    <h2 class="section-title">🖼️ Meus Banners</h2>
    
    <?php if (!empty($banners)): ?>
    <div class="anuncios-grid">
        <?php foreach ($banners as $banner): ?>
        <div class="anuncio-card">
            <img src="<?= upload($banner['imagem_url']) ?>" class="anuncio-image" alt="<?= e($banner['titulo']) ?>">
            <div class="anuncio-body">
                <h3 class="anuncio-title"><?= e($banner['titulo'] ?? 'Banner') ?></h3>
                <div class="anuncio-meta">
                    📍 <?= e($banner['posicao_nome'] ?? 'N/A') ?> • 
                    <?= formatDate($banner['data_inicio']) ?> - <?= formatDate($banner['data_fim']) ?>
                </div>
                <div class="anuncio-stats">
                    <span>👁️ <?= number_format($banner['impressoes']) ?> impressões</span>
                    <span>🖱️ <?= number_format($banner['cliques']) ?> cliques</span>
                </div>
                <span class="anuncio-status status-<?= $banner['status'] ?>">
                    <?= ucfirst($banner['status']) ?>
                </span>
                <div class="anuncio-actions">
                    <?php if ($banner['status'] === 'ativo'): ?>
                        <button class="btn btn-sm btn-outline" onclick="pausarBanner(<?= $banner['id'] ?>)">⏸️ Pausar</button>
                    <?php endif; ?>
                    <a href="<?= $banner['link_url'] ?>" target="_blank" class="btn btn-sm btn-outline">🔗 Ver Link</a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="empty-state">
        <div class="empty-state-icon">🖼️</div>
        <h3>Nenhum banner ainda</h3>
        <p>Crie seu primeiro banner e alcance milhares de pessoas!</p>
        <button class="btn btn-primary" onclick="abrirModalBanner()" style="margin-top:16px;">
            Criar Banner
        </button>
    </div>
    <?php endif; ?>
    
    <!-- Meus Destaques -->
    <h2 class="section-title" style="margin-top:var(--space-8);">⭐ Meus Destaques</h2>
    
    <?php if (!empty($destaques)): ?>
    <div class="anuncios-grid">
        <?php foreach ($destaques as $destaque): ?>
        <div class="anuncio-card">
            <div class="anuncio-body">
                <h3 class="anuncio-title"><?= e($destaque['post_titulo'] ?? 'Post') ?></h3>
                <div class="anuncio-meta">
                    <?= $destaque['tipo'] === 'home' ? '🏠 Home' : ($destaque['tipo'] === 'cidade' ? '🏙️ Cidade' : '🏷️ Categoria') ?> • 
                    <?= formatDate($destaque['data_inicio']) ?> - <?= formatDate($destaque['data_fim']) ?>
                </div>
                <span class="anuncio-status status-<?= $destaque['status'] ?>">
                    <?= ucfirst($destaque['status']) ?>
                </span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="empty-state">
        <div class="empty-state-icon">⭐</div>
        <h3>Nenhum destaque ainda</h3>
        <p>Destaque suas publicações para mais visibilidade!</p>
    </div>
    <?php endif; ?>
    
</div>

<!-- Modal Novo Banner -->
<div class="modal" id="modalBanner">
    <div class="modal-content">
        <div class="modal-header">
            <h3>🖼️ Criar Novo Banner</h3>
            <button onclick="fecharModal('modalBanner')" style="background:none;border:none;font-size:24px;cursor:pointer;">×</button>
        </div>
        <form id="bannerForm" enctype="multipart/form-data">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Título do Banner</label>
                    <input type="text" name="titulo" class="form-input" placeholder="Ex: Promoção de Janeiro">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Posição *</label>
                    <select name="posicao_id" id="bannerPosicao" class="form-select" required onchange="calcularPreco()">
                        <option value="">Selecione...</option>
                        <?php foreach ($posicoes ?? [] as $pos): ?>
                            <option value="<?= $pos['id'] ?>" data-largura="<?= $pos['largura'] ?>" data-altura="<?= $pos['altura'] ?>">
                                <?= e($pos['nome']) ?> (<?= $pos['largura'] ?>x<?= $pos['altura'] ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="grid-2">
                    <div class="form-group">
                        <label class="form-label">Estado *</label>
                        <select name="estado_id" id="bannerEstado" class="form-select" required onchange="carregarCidadesBanner(this.value);calcularPreco();">
                            <option value="">Selecione...</option>
                            <?php foreach ($estados ?? [] as $estado): ?>
                                <option value="<?= $estado['id'] ?>"><?= e($estado['nome']) ?> (<?= e($estado['uf']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Cidade</label>
                        <select name="cidade_id" id="bannerCidade" class="form-select">
                            <option value="">Selecione o estado primeiro</option>
                        </select>
                        <small style="color:#64748b;">Deixe vazio para todo o estado</small>
                    </div>
                </div>
                
                <div class="grid-2">
                    <div class="form-group">
                        <label class="form-label">Data Início *</label>
                        <input type="date" name="data_inicio" id="bannerInicio" class="form-input" required onchange="calcularPreco()" min="<?= date('Y-m-d') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Data Fim *</label>
                        <input type="date" name="data_fim" id="bannerFim" class="form-input" required onchange="calcularPreco()">
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Link de Destino *</label>
                    <input type="url" name="link_url" class="form-input" placeholder="https://..." required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Imagem do Banner *</label>
                    <div class="image-upload" onclick="document.getElementById('bannerImagem').click()">
                        <input type="file" name="imagem" id="bannerImagem" accept="image/*" required style="display:none">
                        <div id="bannerImagePreview">
                            <span style="font-size:32px;display:block;margin-bottom:8px;">📤</span>
                            Clique para fazer upload
                        </div>
                    </div>
                </div>
                
                <div class="price-display">
                    <small>Valor estimado</small>
                    <div class="price-value" id="precoEstimado">R$ 0,00</div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="fecharModal('modalBanner')">Cancelar</button>
                <button type="submit" class="btn btn-primary">Solicitar Banner</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Destacar Post -->
<div class="modal" id="modalDestaque">
    <div class="modal-content">
        <div class="modal-header">
            <h3>⭐ Destacar Publicação</h3>
            <button onclick="fecharModal('modalDestaque')" style="background:none;border:none;font-size:24px;cursor:pointer;">×</button>
        </div>
        <form id="destaqueForm">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Selecione a Publicação *</label>
                    <select name="post_id" class="form-select" required>
                        <option value="">Selecione...</option>
                        <?php foreach ($meusPosts ?? [] as $post): ?>
                            <option value="<?= $post['id'] ?>"><?= e($post['titulo']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Tipo de Destaque *</label>
                    <select name="tipo" class="form-select" required>
                        <option value="cidade">🏙️ Destaque na Cidade</option>
                        <option value="home">🏠 Destaque na Home</option>
                        <option value="categoria">🏷️ Destaque na Categoria</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Período *</label>
                    <select name="dias" class="form-select" required>
                        <option value="1">1 dia - R$ 15,00</option>
                        <option value="3">3 dias - R$ 35,00</option>
                        <option value="7">7 dias - R$ 70,00</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="fecharModal('modalDestaque')">Cancelar</button>
                <button type="submit" class="btn btn-primary">Solicitar Destaque</button>
            </div>
        </form>
    </div>
</div>

<script>
function abrirModalBanner() {
    document.getElementById('modalBanner').classList.add('show');
}

function abrirModalDestaque() {
    document.getElementById('modalDestaque').classList.add('show');
}

function fecharModal(id) {
    document.getElementById(id).classList.remove('show');
}

document.querySelectorAll('.modal').forEach(m => {
    m.addEventListener('click', e => {
        if (e.target === m) fecharModal(m.id);
    });
});

function calcularPreco() {
    const posicao = document.getElementById('bannerPosicao').value;
    const estado = document.getElementById('bannerEstado').value;
    const cidade = document.getElementById('bannerCidade').value;
    const inicio = document.getElementById('bannerInicio').value;
    const fim = document.getElementById('bannerFim').value;
    
    if (!inicio || !fim) {
        document.getElementById('precoEstimado').textContent = 'R$ 0,00';
        return;
    }
    
    const dias = Math.ceil((new Date(fim) - new Date(inicio)) / (1000 * 60 * 60 * 24)) + 1;
    
    // Preços base simplificados
    let precoDia = cidade ? 5 : 40; // Por cidade ou por estado
    const total = dias * precoDia;
    
    document.getElementById('precoEstimado').textContent = 'R$ ' + total.toFixed(2).replace('.', ',');
}

async function carregarCidadesBanner(estadoId) {
    const select = document.getElementById('bannerCidade');
    if (!estadoId) {
        select.innerHTML = '<option value="">Selecione o estado primeiro</option>';
        return;
    }
    
    select.innerHTML = '<option value="">Carregando...</option>';
    
    try {
        const res = await fetch(`<?= url('api/cidades') ?>?estado_id=${estadoId}`);
        const data = await res.json();
        
        select.innerHTML = '<option value="">Todo o estado</option>';
        if (data.success && data.cidades) {
            data.cidades.forEach(c => {
                select.innerHTML += `<option value="${c.id}">${c.nome}</option>`;
            });
        }
    } catch (e) {
        select.innerHTML = '<option value="">Erro ao carregar</option>';
    }
}

// Preview imagem
document.getElementById('bannerImagem').addEventListener('change', function() {
    if (this.files[0]) {
        const reader = new FileReader();
        reader.onload = e => {
            document.getElementById('bannerImagePreview').innerHTML = `<img src="${e.target.result}" style="max-width:100%;max-height:150px;border-radius:8px;">`;
        };
        reader.readAsDataURL(this.files[0]);
    }
});

document.getElementById('bannerForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    try {
        const res = await fetch('<?= url('api/autor/banner') ?>', {
            method: 'POST',
            body: formData
        });
        const data = await res.json();
        
        if (data.success) {
            alert('Banner enviado para aprovação!');
            location.reload();
        } else {
            alert(data.error || 'Erro ao criar banner');
        }
    } catch (e) {
        alert('Erro de conexão');
    }
});

document.getElementById('destaqueForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    try {
        const res = await fetch('<?= url('api/anunciante/destaque') ?>', {
            method: 'POST',
            body: formData
        });
        const data = await res.json();
        
        if (data.success) {
            alert('Destaque solicitado!');
            location.reload();
        } else {
            alert(data.error || 'Erro ao solicitar destaque');
        }
    } catch (e) {
        alert('Erro de conexão');
    }
});

async function pausarBanner(id) {
    if (!confirm('Pausar este banner?')) return;
    
    try {
        const res = await fetch(`<?= url('api/anunciante/banner') ?>/${id}/pausar`, { method: 'POST' });
        const data = await res.json();
        if (data.success) location.reload();
        else alert(data.error || 'Erro');
    } catch (e) {
        alert('Erro de conexão');
    }
}
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
