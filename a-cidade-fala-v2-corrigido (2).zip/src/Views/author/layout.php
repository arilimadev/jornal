<?php
use ACidadeFala\Config\Config;
$pageTitle = $pageTitle ?? 'Painel do Autor';
$currentPage = $currentPage ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> | <?= e(Config::SITE_NAME) ?></title>
    <link rel="icon" href="<?= asset('images/favicon.svg') ?>">
    <link rel="stylesheet" href="<?= asset('css/variables.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/components.css') ?>">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
    *{box-sizing:border-box}body{margin:0;font-family:var(--font-body);background:#f1f5f9}
    .author-layout{display:grid;grid-template-columns:260px 1fr;min-height:100vh}
    .author-sidebar{background:linear-gradient(180deg,#1e293b 0%,#0f172a 100%);color:#fff;padding:0}
    .sidebar-header{padding:24px;border-bottom:1px solid #334155;display:flex;align-items:center;gap:12px}
    .sidebar-logo{font-size:18px;font-weight:700}
    .sidebar-user{padding:24px;border-bottom:1px solid #334155;text-align:center}
    .user-avatar{width:80px;height:80px;background:linear-gradient(135deg,#3b82f6,#8b5cf6);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:32px;font-weight:700;margin:0 auto 12px;color:#fff}
    .user-name{font-size:16px;font-weight:600}
    .user-email{font-size:13px;color:#94a3b8;margin-top:4px}
    .sidebar-nav{padding:16px 0}
    .nav-section{padding:0 16px;margin-bottom:8px}
    .nav-section-title{font-size:11px;text-transform:uppercase;color:#64748b;font-weight:600;padding:8px 12px}
    .nav-item{display:flex;align-items:center;gap:12px;padding:12px 16px;margin:0 8px;color:#cbd5e1;text-decoration:none;border-radius:8px;transition:all .2s;font-size:14px}
    .nav-item:hover{background:#334155;color:#fff}
    .nav-item.active{background:linear-gradient(135deg,#3b82f6,#2563eb);color:#fff;font-weight:500}
    .nav-item i{width:20px;height:20px}
    .sidebar-footer{padding:16px;border-top:1px solid #334155;margin-top:auto}
    .author-main{padding:32px}
    .page-header{margin-bottom:32px}
    .page-title{font-size:28px;font-weight:700;color:#1e293b;margin-bottom:8px}
    .page-subtitle{color:#64748b}
    .stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px;margin-bottom:32px}
    .stat-card{background:#fff;border-radius:12px;padding:24px;box-shadow:0 1px 3px rgba(0,0,0,.1)}
    .stat-icon{width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:24px;margin-bottom:12px}
    .stat-value{font-size:32px;font-weight:700;color:#1e293b}
    .stat-label{font-size:14px;color:#64748b}
    .card{background:#fff;border-radius:12px;padding:24px;box-shadow:0 1px 3px rgba(0,0,0,.1)}
    .card-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px}
    .card-title{font-size:18px;font-weight:600}
    .table{width:100%;border-collapse:collapse}
    .table th,.table td{padding:12px;text-align:left;border-bottom:1px solid #e2e8f0}
    .table th{font-weight:600;color:#64748b;font-size:13px;text-transform:uppercase}
    .status{padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600}
    .status-aprovado{background:#dcfce7;color:#166534}
    .status-pendente{background:#fef3c7;color:#92400e}
    .status-rejeitado{background:#fee2e2;color:#991b1b}
    .status-rascunho{background:#f1f5f9;color:#475569}
    .empty-state{text-align:center;padding:48px;color:#64748b}
    .empty-state i{font-size:48px;margin-bottom:16px;display:block;opacity:.5}
    @media(max-width:768px){.author-layout{grid-template-columns:1fr}.author-sidebar{position:fixed;left:-280px;top:0;height:100%;z-index:100;width:260px;transition:left .3s}.author-sidebar.open{left:0}.mobile-toggle{display:block!important}}
    .mobile-toggle{display:none;position:fixed;top:16px;left:16px;z-index:99;background:#1e293b;color:#fff;border:none;padding:12px;border-radius:8px;cursor:pointer}
    </style>
</head>
<body>
<button class="mobile-toggle" onclick="document.querySelector('.author-sidebar').classList.toggle('open')">☰</button>
<div class="author-layout">
    <aside class="author-sidebar">
        <div class="sidebar-header">
            <span>📰</span>
            <span class="sidebar-logo"><?= e(Config::SITE_NAME) ?></span>
        </div>
        <div class="sidebar-user">
            <div class="user-avatar"><?= strtoupper(substr($_SESSION['user_nome'] ?? 'U', 0, 1)) ?></div>
            <div class="user-name"><?= e($_SESSION['user_nome'] ?? 'Usuário') ?></div>
            <div class="user-email"><?= e($_SESSION['user_email'] ?? '') ?></div>
        </div>
        <nav class="sidebar-nav">
            <div class="nav-section">
                <div class="nav-section-title">Principal</div>
                <a href="<?= url('autor') ?>" class="nav-item <?= $currentPage === 'dashboard' ? 'active' : '' ?>"><i data-lucide="layout-dashboard"></i> Dashboard</a>
                <a href="<?= url('autor/publicar') ?>" class="nav-item <?= $currentPage === 'publicar' ? 'active' : '' ?>"><i data-lucide="edit-3"></i> Nova Publicação</a>
                <a href="<?= url('autor/posts') ?>" class="nav-item <?= $currentPage === 'posts' ? 'active' : '' ?>"><i data-lucide="file-text"></i> Minhas Publicações</a>
            </div>
            <div class="nav-section">
                <div class="nav-section-title">Monetização</div>
                <a href="<?= url('autor/anunciar') ?>" class="nav-item <?= $currentPage === 'anunciar' ? 'active' : '' ?>"><i data-lucide="megaphone"></i> Anunciar</a>
            </div>
            <div class="nav-section">
                <div class="nav-section-title">Conta</div>
                <a href="<?= url('autor/verificacao') ?>" class="nav-item <?= $currentPage === 'verificacao' ? 'active' : '' ?>"><i data-lucide="shield-check"></i> Verificação</a>
                <a href="<?= url('autor/perfil') ?>" class="nav-item <?= $currentPage === 'perfil' ? 'active' : '' ?>"><i data-lucide="user"></i> Meu Perfil</a>
            </div>
        </nav>
        <div class="sidebar-footer">
            <a href="<?= url('/') ?>" class="nav-item"><i data-lucide="home"></i> Ir para o Site</a>
            <a href="<?= url('logout') ?>" class="nav-item"><i data-lucide="log-out"></i> Sair</a>
        </div>
    </aside>
    <main class="author-main"><?= $content ?? '' ?></main>
</div>
<script>window.ACF={baseUrl:'<?= url('') ?>',apiUrl:'<?= url('api') ?>'};lucide.createIcons();</script>
<script src="<?= asset('js/main.js') ?>"></script>
</body>
</html>
