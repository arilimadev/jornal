<?php
$pageTitle = "Meu Perfil";
$currentPage = "perfil";
$usuario = $usuario ?? [];
ob_start();
?>
<div class="page-header">
    <h1 class="page-title">Meu Perfil</h1>
    <p class="page-subtitle">Gerencie suas informações pessoais</p>
</div>

<div class="card" style="max-width:600px">
    <div style="text-align:center;margin-bottom:32px">
        <div class="user-avatar" style="width:100px;height:100px;font-size:40px;margin:0 auto 16px;background:linear-gradient(135deg,#3b82f6,#8b5cf6);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff"><?= strtoupper(substr($usuario['nome'] ?? 'U', 0, 1)) ?></div>
        <h2 style="margin:0"><?= e($usuario['nome'] ?? '') ?></h2>
        <p style="color:#64748b"><?= e($usuario['email'] ?? '') ?></p>
    </div>
    
    <form id="profileForm" enctype="multipart/form-data">
        <div class="form-group" style="margin-bottom:20px">
            <label class="form-label" style="display:block;font-weight:600;margin-bottom:8px">Foto de Perfil</label>
            <input type="file" name="avatar" accept="image/*" style="width:100%;padding:12px;border:1px solid #d1d5db;border-radius:8px">
            <small style="color:#64748b">Formatos aceitos: JPG, PNG, GIF (máx. 2MB)</small>
        </div>
        <div class="form-group" style="margin-bottom:20px">
            <label class="form-label" style="display:block;font-weight:600;margin-bottom:8px">Nome Completo</label>
            <input type="text" name="nome" class="form-input" value="<?= e($usuario['nome'] ?? '') ?>" style="width:100%;padding:12px;border:1px solid #d1d5db;border-radius:8px">
        </div>
        <div class="form-group" style="margin-bottom:20px">
            <label class="form-label" style="display:block;font-weight:600;margin-bottom:8px">Email</label>
            <input type="email" class="form-input" value="<?= e($usuario['email'] ?? '') ?>" disabled style="width:100%;padding:12px;border:1px solid #d1d5db;border-radius:8px;background:#f1f5f9">
            <small style="color:#64748b">O email não pode ser alterado</small>
        </div>
        <div class="form-group" style="margin-bottom:20px">
            <label class="form-label" style="display:block;font-weight:600;margin-bottom:8px">Telefone</label>
            <input type="tel" name="telefone" class="form-input" value="<?= e($usuario['telefone'] ?? '') ?>" placeholder="(00) 00000-0000" style="width:100%;padding:12px;border:1px solid #d1d5db;border-radius:8px">
        </div>
        <div class="form-group" style="margin-bottom:20px">
            <label class="form-label" style="display:block;font-weight:600;margin-bottom:8px">Sobre Você</label>
            <textarea name="bio" class="form-input" placeholder="Conte um pouco sobre você..." style="width:100%;padding:12px;border:1px solid #d1d5db;border-radius:8px;min-height:100px"><?= e($usuario['bio'] ?? '') ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary btn-lg" style="width:100%">Salvar Alterações</button>
    </form>
</div>

<script>
document.getElementById('profileForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    try {
        const res = await fetch('<?= url('api/autor/perfil') ?>', {
            method: 'POST',
            body: formData
        });
        const data = await res.json();
        
        if (data.success) {
            alert('✅ Perfil atualizado!');
            location.reload();
        } else {
            alert(data.error || 'Erro ao salvar');
        }
    } catch (e) {
        alert('Erro de conexão');
    }
});
</script>
<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
