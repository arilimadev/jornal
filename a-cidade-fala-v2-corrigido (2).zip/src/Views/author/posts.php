<?php
$pageTitle = "Minhas Publicações";
$currentPage = "posts";
$posts = $posts ?? [];
ob_start();
?>
<style>
.post-actions { display: flex; gap: 8px; align-items: center; }
.post-actions a, .post-actions button { 
    background: none; border: none; cursor: pointer; padding: 6px; 
    border-radius: 6px; transition: all 0.2s; color: var(--color-gray-500);
}
.post-actions a:hover, .post-actions button:hover { background: var(--color-gray-100); color: var(--color-primary); }
.post-actions .btn-delete:hover { background: #fef2f2; color: #dc2626; }
.post-actions .btn-highlight { color: #f59e0b; }
.post-actions .btn-highlight.active { color: #f59e0b; background: #fef3c7; }

.confirm-modal {
    position: fixed; inset: 0; background: rgba(0,0,0,0.5); 
    display: none; align-items: center; justify-content: center; z-index: 1000;
}
.confirm-modal.show { display: flex; }
.confirm-modal-content {
    background: white; border-radius: 16px; padding: 32px; max-width: 400px; text-align: center;
}
.confirm-modal h3 { margin-bottom: 16px; }
.confirm-modal p { color: var(--color-gray-600); margin-bottom: 24px; }
.confirm-modal-actions { display: flex; gap: 12px; justify-content: center; }
</style>

<div class="page-header">
    <h1 class="page-title">Minhas Publicações</h1>
    <p class="page-subtitle">Gerencie todas as suas publicações</p>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title"><?= count($posts) ?> publicações</h2>
        <a href="<?= url('autor/publicar') ?>" class="btn btn-primary">➕ Nova Publicação</a>
    </div>
    
    <?php if (empty($posts)): ?>
    <div class="empty-state">
        <div style="font-size:48px;margin-bottom:16px;">📄</div>
        <h3>Nenhuma publicação ainda</h3>
        <p>Comece a publicar suas notícias, opiniões ou denúncias!</p>
        <a href="<?= url('autor/publicar') ?>" class="btn btn-primary btn-lg" style="margin-top:16px">Criar Primeira Publicação</a>
    </div>
    <?php else: ?>
    <table class="table">
        <thead>
            <tr>
                <th>Título</th>
                <th>Tipo</th>
                <th>Status</th>
                <th>Views</th>
                <th>Data</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($posts as $post): ?>
            <tr id="post-row-<?= $post['id'] ?>">
                <td>
                    <strong><?= e(mb_substr($post['titulo'], 0, 50)) ?><?= mb_strlen($post['titulo']) > 50 ? '...' : '' ?></strong>
                    <?php if ($post['destaque'] ?? false): ?>
                        <span style="color:#f59e0b;margin-left:4px;">⭐</span>
                    <?php endif; ?>
                </td>
                <td><?= ucfirst($post['tipo'] ?? 'Notícia') ?></td>
                <td><span class="status status-<?= $post['status'] ?>"><?= ucfirst($post['status']) ?></span></td>
                <td><?= number_format($post['visualizacoes'] ?? 0) ?></td>
                <td><?= formatDate($post['created_at'] ?? '') ?></td>
                <td>
                    <div class="post-actions">
                        <?php if ($post['status'] === 'aprovado'): ?>
                        <a href="<?= postUrl($post) ?>" target="_blank" title="Ver publicação">👁️</a>
                        <button onclick="toggleDestaque(<?= $post['id'] ?>, this)" 
                                class="btn-highlight <?= ($post['destaque'] ?? false) ? 'active' : '' ?>" 
                                title="<?= ($post['destaque'] ?? false) ? 'Remover destaque' : 'Destacar publicação' ?>">
                            ⭐
                        </button>
                        <?php endif; ?>
                        <a href="<?= url('autor/editar/' . $post['id']) ?>" title="Editar">✏️</a>
                        <button onclick="confirmDelete(<?= $post['id'] ?>, '<?= e(addslashes($post['titulo'])) ?>')" 
                                class="btn-delete" title="Excluir">🗑️</button>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<!-- Modal de Confirmação -->
<div id="deleteModal" class="confirm-modal">
    <div class="confirm-modal-content">
        <h3>🗑️ Excluir Publicação</h3>
        <p>Tem certeza que deseja excluir "<strong id="deletePostTitle"></strong>"? Esta ação não pode ser desfeita.</p>
        <div class="confirm-modal-actions">
            <button onclick="closeDeleteModal()" class="btn btn-ghost">Cancelar</button>
            <button onclick="deletePost()" class="btn btn-danger">Excluir</button>
        </div>
    </div>
</div>

<script>
let postIdToDelete = null;

function confirmDelete(id, title) {
    postIdToDelete = id;
    document.getElementById('deletePostTitle').textContent = title;
    document.getElementById('deleteModal').classList.add('show');
}

function closeDeleteModal() {
    document.getElementById('deleteModal').classList.remove('show');
    postIdToDelete = null;
}

async function deletePost() {
    if (!postIdToDelete) return;
    
    try {
        const response = await fetch(window.ACF.apiUrl + '/autor/post/' + postIdToDelete, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' }
        });
        
        const result = await response.json();
        
        if (result.success) {
            document.getElementById('post-row-' + postIdToDelete).remove();
            closeDeleteModal();
            const countEl = document.querySelector('.card-title');
            const count = document.querySelectorAll('tbody tr').length;
            countEl.textContent = count + ' publicações';
        } else {
            alert(result.error || 'Erro ao excluir publicação');
        }
    } catch (error) {
        console.error(error);
        alert('Erro de conexão');
    }
}

async function toggleDestaque(id, btn) {
    try {
        const response = await fetch(window.ACF.apiUrl + '/autor/post/' + id + '/destaque', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });
        
        const result = await response.json();
        
        if (result.success) {
            btn.classList.toggle('active');
            const row = document.getElementById('post-row-' + id);
            const titleCell = row.querySelector('td:first-child');
            const starSpan = titleCell.querySelector('span[style*="color:#f59e0b"]');
            
            if (result.destaque) {
                if (!starSpan) {
                    titleCell.querySelector('strong').insertAdjacentHTML('afterend', '<span style="color:#f59e0b;margin-left:4px;">⭐</span>');
                }
                btn.title = 'Remover destaque';
            } else {
                if (starSpan) starSpan.remove();
                btn.title = 'Destacar publicação';
            }
        } else {
            alert(result.error || 'Erro ao alterar destaque');
        }
    } catch (error) {
        console.error(error);
        alert('Erro de conexão');
    }
}

document.getElementById('deleteModal').addEventListener('click', function(e) {
    if (e.target === this) closeDeleteModal();
});
</script>
<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
