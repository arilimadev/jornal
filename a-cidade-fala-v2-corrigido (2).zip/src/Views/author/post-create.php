<?php
/**
 * A Cidade Fala v2.0 - Criar Publicação
 * Com editor rico (Quill), preview em tempo real e aceite de termos
 */

use ACidadeFala\Config\Config;

$pageTitle = "Nova Publicação";

ob_start();
?>

<style>
.post-editor-page {
    min-height: 100vh;
    background: #f1f5f9;
}

.editor-header {
    background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-dark) 100%);
    color: white;
    padding: 20px;
    position: sticky;
    top: 0;
    z-index: 100;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.editor-header-left {
    display: flex;
    align-items: center;
    gap: 16px;
}

.editor-header h1 { font-size: 20px; font-weight: 600; }

.editor-header-actions { display: flex; gap: 12px; }

.btn-back {
    background: rgba(255,255,255,0.2);
    color: white;
    padding: 10px 16px;
    border-radius: 8px;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 8px;
}

.btn-back:hover { background: rgba(255,255,255,0.3); }

.editor-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 24px;
    display: grid;
    grid-template-columns: 1fr 400px;
    gap: 24px;
}

@media (max-width: 1024px) {
    .editor-container { grid-template-columns: 1fr; }
    .preview-panel { display: none; }
}

.editor-main {
    background: white;
    border-radius: 12px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.editor-section {
    padding: 24px;
    border-bottom: 1px solid #e2e8f0;
}

.editor-section:last-child { border-bottom: none; }

.section-title {
    font-size: 16px;
    font-weight: 600;
    color: #1e293b;
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    gap: 8px;
}

/* Type Selector */
.type-selector {
    display: flex;
    gap: 12px;
}

.type-option {
    flex: 1;
    padding: 16px;
    border: 2px solid #e2e8f0;
    border-radius: 10px;
    cursor: pointer;
    text-align: center;
    transition: all 0.2s;
}

.type-option:hover { border-color: var(--color-primary-300); }
.type-option.selected { border-color: var(--color-primary); background: var(--color-primary-50); }
.type-option input { display: none; }
.type-option-icon { font-size: 28px; margin-bottom: 8px; }
.type-option-name { font-weight: 600; }
.type-option-desc { font-size: 12px; color: #64748b; margin-top: 4px; }

/* Form */
.form-group { margin-bottom: 20px; }
.form-label { display: block; font-weight: 500; color: #374151; margin-bottom: 8px; }
.form-label .required { color: #dc2626; }

.form-input, .form-select, .form-textarea {
    width: 100%;
    padding: 12px 16px;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    font-size: 15px;
    transition: all 0.2s;
}

.form-input:focus, .form-select:focus {
    outline: none;
    border-color: var(--color-primary);
    box-shadow: 0 0 0 3px rgba(30, 64, 175, 0.1);
}

.form-input-large {
    font-size: 24px;
    font-weight: 600;
    border: none;
    border-bottom: 2px solid #e2e8f0;
    border-radius: 0;
    padding: 12px 0;
}

.form-input-large:focus {
    border-color: var(--color-primary);
    box-shadow: none;
}

.char-counter {
    text-align: right;
    font-size: 12px;
    color: #64748b;
    margin-top: 4px;
}

.char-counter.warning { color: #d97706; }
.char-counter.error { color: #dc2626; }

/* Location Grid */
.location-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 12px;
}

@media (max-width: 768px) {
    .location-grid { grid-template-columns: 1fr; }
}

/* Quill Editor */
#editor-container {
    height: 400px;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    overflow: hidden;
}

.ql-toolbar.ql-snow {
    border: none;
    border-bottom: 1px solid #e2e8f0;
    background: #f8fafc;
}

.ql-container.ql-snow {
    border: none;
    font-size: 16px;
}

.ql-editor {
    min-height: 350px;
}

/* Image Upload */
.image-upload {
    border: 2px dashed #d1d5db;
    border-radius: 12px;
    padding: 32px;
    text-align: center;
    cursor: pointer;
    transition: all 0.2s;
}

.image-upload:hover { border-color: var(--color-primary); background: var(--color-primary-50); }
.image-upload.has-image { border-style: solid; }

.image-upload-icon { font-size: 48px; opacity: 0.5; margin-bottom: 12px; }
.image-upload-text { color: #64748b; }
.image-upload-text strong { color: var(--color-primary); }

.image-preview {
    max-width: 100%;
    max-height: 200px;
    border-radius: 8px;
    margin-bottom: 12px;
}

/* Category Grid */
.category-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 10px;
}

@media (max-width: 768px) {
    .category-grid { grid-template-columns: repeat(2, 1fr); }
}

.category-option {
    padding: 12px;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    cursor: pointer;
    text-align: center;
    transition: all 0.2s;
    font-size: 14px;
}

.category-option:hover { border-color: var(--color-primary-300); }
.category-option.selected { border-color: var(--color-primary); background: var(--color-primary-50); }
.category-option input { display: none; }
.category-option-icon { font-size: 20px; display: block; margin-bottom: 4px; }

/* Anonymous Option */
.anonymous-option {
    background: #fef3c7;
    border: 1px solid #fde68a;
    border-radius: 10px;
    padding: 20px;
}

.anonymous-option-header {
    display: flex;
    align-items: flex-start;
    gap: 12px;
}

.anonymous-checkbox {
    margin-top: 4px;
    width: 20px;
    height: 20px;
}

.anonymous-warning {
    margin-top: 12px;
    padding: 12px;
    background: white;
    border-radius: 8px;
    font-size: 13px;
    color: #92400e;
    display: none;
}

.anonymous-option input:checked ~ .anonymous-warning { display: block; }

/* Preview Panel */
.preview-panel {
    position: sticky;
    top: 100px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    max-height: calc(100vh - 120px);
    overflow-y: auto;
}

.preview-header {
    padding: 16px 20px;
    border-bottom: 1px solid #e2e8f0;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 8px;
}

.preview-content { padding: 20px; }

.preview-badge {
    display: inline-block;
    padding: 4px 10px;
    background: var(--color-primary);
    color: white;
    font-size: 11px;
    font-weight: 600;
    border-radius: 4px;
    text-transform: uppercase;
    margin-bottom: 12px;
}

.preview-title {
    font-size: 20px;
    font-weight: 700;
    line-height: 1.3;
    margin-bottom: 8px;
    color: #1e293b;
}

.preview-subtitle {
    font-size: 15px;
    color: #64748b;
    margin-bottom: 16px;
}

.preview-meta {
    display: flex;
    gap: 16px;
    font-size: 13px;
    color: #64748b;
    margin-bottom: 16px;
    padding-bottom: 16px;
    border-bottom: 1px solid #e2e8f0;
}

.preview-image {
    width: 100%;
    height: 180px;
    background: #f1f5f9;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #94a3b8;
    font-size: 14px;
    margin-bottom: 16px;
    overflow: hidden;
}

.preview-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.preview-body {
    font-size: 14px;
    line-height: 1.7;
    color: #374151;
}

/* Terms Modal */
.terms-modal {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.8);
    z-index: 1000;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.terms-modal.show { display: flex; }

.terms-modal-content {
    background: white;
    border-radius: 16px;
    max-width: 700px;
    width: 100%;
    max-height: 90vh;
    display: flex;
    flex-direction: column;
}

.terms-modal-header {
    padding: 24px;
    border-bottom: 1px solid #e2e8f0;
    text-align: center;
}

.terms-modal-header h2 {
    font-size: 24px;
    color: #1e293b;
}

.terms-modal-body {
    padding: 24px;
    overflow-y: auto;
    flex: 1;
    font-size: 15px;
    line-height: 1.7;
    color: #374151;
}

.terms-modal-footer {
    padding: 24px;
    border-top: 1px solid #e2e8f0;
    background: #f8fafc;
}

.terms-accept-check {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    margin-bottom: 20px;
}

.terms-accept-check input {
    margin-top: 4px;
    width: 20px;
    height: 20px;
}

.btn-accept {
    width: 100%;
    padding: 16px;
    background: var(--color-primary);
    color: white;
    border: none;
    border-radius: 10px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
}

.btn-accept:disabled {
    background: #94a3b8;
    cursor: not-allowed;
}

/* Buttons */
.btn {
    padding: 12px 24px;
    border-radius: 8px;
    font-size: 15px;
    font-weight: 500;
    cursor: pointer;
    border: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.2s;
}

.btn-primary { background: var(--color-primary); color: white; }
.btn-primary:hover { background: var(--color-primary-dark); }
.btn-success { background: #16a34a; color: white; }
.btn-success:hover { background: #15803d; }
.btn-outline { background: white; border: 1px solid #d1d5db; color: #374151; }
.btn-outline:hover { background: #f1f5f9; }
.btn-lg { padding: 16px 32px; font-size: 16px; }
</style>

<!-- Quill CSS -->
<link href="https://cdn.quilljs.com/1.3.7/quill.snow.css" rel="stylesheet">

<div class="post-editor-page">
    
    <!-- Header -->
    <div class="editor-header">
        <div class="editor-header-left">
            <a href="<?= url('autor') ?>" class="btn-back">← Voltar</a>
            <h1>Nova Publicação</h1>
        </div>
        <div class="editor-header-actions">
            <button type="button" class="btn btn-outline" onclick="salvarRascunho()">
                💾 Salvar Rascunho
            </button>
            <button type="button" class="btn btn-success btn-lg" onclick="submeterPost()">
                📤 Enviar para Moderação
            </button>
        </div>
    </div>
    
    <form id="postForm" enctype="multipart/form-data">
        <div class="editor-container">
            
            <!-- Main Editor -->
            <div class="editor-main">
                
                <!-- Tipo -->
                <div class="editor-section">
                    <h3 class="section-title">📌 Tipo de Publicação</h3>
                    <div class="type-selector">
                        <label class="type-option selected">
                            <input type="radio" name="tipo" value="noticia" checked>
                            <div class="type-option-icon">📰</div>
                            <div class="type-option-name">Notícia</div>
                            <div class="type-option-desc">Fato relevante para a cidade</div>
                        </label>
                        <label class="type-option">
                            <input type="radio" name="tipo" value="opiniao">
                            <div class="type-option-icon">💭</div>
                            <div class="type-option-name">Opinião</div>
                            <div class="type-option-desc">Seu ponto de vista</div>
                        </label>
                        <label class="type-option">
                            <input type="radio" name="tipo" value="denuncia">
                            <div class="type-option-icon">🚨</div>
                            <div class="type-option-name">Denúncia</div>
                            <div class="type-option-desc">Problema na comunidade</div>
                        </label>
                    </div>
                </div>
                
                <!-- Título e Subtítulo -->
                <div class="editor-section">
                    <div class="form-group">
                        <input type="text" name="titulo" class="form-input form-input-large" 
                               placeholder="Digite o título da publicação..." 
                               maxlength="200" required oninput="updatePreview()">
                        <div class="char-counter"><span id="tituloCount">0</span>/200</div>
                    </div>
                    <div class="form-group">
                        <input type="text" name="subtitulo" class="form-input" 
                               placeholder="Subtítulo ou resumo (opcional)" 
                               maxlength="300" oninput="updatePreview()">
                        <div class="char-counter"><span id="subtituloCount">0</span>/300</div>
                    </div>
                </div>
                
                <!-- Localização -->
                <div class="editor-section">
                    <h3 class="section-title">📍 Localização</h3>
                    <div class="location-grid">
                        <div class="form-group">
                            <label class="form-label">Estado <span class="required">*</span></label>
                            <select name="estado_id" class="form-select" required onchange="carregarCidades(this.value)">
                                <option value="">Selecione...</option>
                                <?php foreach ($estados ?? [] as $estado): ?>
                                    <option value="<?= $estado['id'] ?>" <?= ($cidadeAtual['estado_id'] ?? 0) == $estado['id'] ? 'selected' : '' ?>>
                                        <?= e($estado['nome']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Cidade <span class="required">*</span></label>
                            <select name="cidade_id" class="form-select" required onchange="carregarBairros(this.value)">
                                <option value="">Selecione o estado primeiro</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Bairro (opcional)</label>
                            <select name="bairro_id" class="form-select">
                                <option value="">Toda a cidade</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <!-- Categoria -->
                <div class="editor-section">
                    <h3 class="section-title">🏷️ Categoria</h3>
                    <div class="category-grid">
                        <?php 
                        $categorias = $categorias ?? Config::getCategories();
                        foreach ($categorias as $id => $cat): 
                        ?>
                        <label class="category-option">
                            <input type="radio" name="categoria_id" value="<?= $id ?>">
                            <span class="category-option-icon"><?= $cat['icone'] ?? '📌' ?></span>
                            <?= e($cat['nome']) ?>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- Imagem -->
                <div class="editor-section">
                    <h3 class="section-title">🖼️ Imagem de Capa</h3>
                    <div class="image-upload" onclick="document.getElementById('imagemInput').click()">
                        <input type="file" id="imagemInput" name="imagem" accept="image/*" style="display:none" onchange="previewImage(this)">
                        <div id="imagePreviewContainer">
                            <div class="image-upload-icon">📷</div>
                            <div class="image-upload-text">
                                <strong>Clique para adicionar</strong> ou arraste uma imagem
                                <br><small>JPG, PNG ou WebP • Máximo 10MB</small>
                            </div>
                        </div>
                    </div>
                    <div class="form-group" style="margin-top:12px;">
                        <input type="text" name="imagem_credito" class="form-input" placeholder="Crédito da imagem (ex: Foto: João Silva)">
                    </div>
                </div>
                
                <!-- Conteúdo -->
                <div class="editor-section">
                    <h3 class="section-title">📝 Conteúdo</h3>
                    <div id="editor-container"></div>
                    <input type="hidden" name="conteudo" id="conteudoHidden">
                </div>
                
                <!-- Opção Anônima -->
                <div class="editor-section">
                    <div class="anonymous-option">
                        <label class="anonymous-option-header">
                            <input type="checkbox" name="anonimo" value="1" class="anonymous-checkbox" onchange="toggleAnonymous(this)">
                            <div>
                                <strong>🔒 Publicar anonimamente</strong>
                                <div style="font-size:13px;color:#92400e;margin-top:4px;">
                                    Seu nome não aparecerá publicamente na publicação
                                </div>
                            </div>
                        </label>
                        <div class="anonymous-warning" id="anonymousWarning">
                            <strong>⚠️ Importante:</strong> Para publicar anonimamente, você precisa verificar sua identidade. 
                            Seus dados serão armazenados de forma segura e só serão divulgados mediante ordem judicial.
                            Isso é necessário para combater fake news e garantir a responsabilidade do conteúdo publicado.
                        </div>
                    </div>
                </div>
                
            </div>
            
            <!-- Preview Panel -->
            <div class="preview-panel">
                <div class="preview-header">👁️ Preview</div>
                <div class="preview-content">
                    <span class="preview-badge" id="previewTipo">Notícia</span>
                    <h2 class="preview-title" id="previewTitulo">Título da publicação...</h2>
                    <p class="preview-subtitle" id="previewSubtitulo"></p>
                    <div class="preview-meta">
                        <span>📅 <?= date('d/m/Y') ?></span>
                        <span>👤 <?= e($_SESSION['user_nome'] ?? 'Você') ?></span>
                    </div>
                    <div class="preview-image" id="previewImage">
                        <span>Imagem de capa</span>
                    </div>
                    <div class="preview-body" id="previewBody">
                        Comece a escrever para ver o preview...
                    </div>
                </div>
            </div>
            
        </div>
    </form>
    
    <!-- Modal de Termos -->
    <div class="terms-modal" id="termsModal">
        <div class="terms-modal-content">
            <div class="terms-modal-header">
                <h2>📜 Termos do Autor</h2>
            </div>
            <div class="terms-modal-body" id="termsContent">
                <h3>1. Responsabilidade pelo Conteúdo</h3>
                <p>Ao publicar conteúdo no portal A Cidade Fala, você declara ser o autor ou ter autorização para publicar o conteúdo apresentado.</p>
                
                <h3>2. Veracidade das Informações</h3>
                <p>Você se compromete a publicar apenas informações verdadeiras e verificáveis. A publicação de fake news ou informações falsas pode resultar em banimento e responsabilização legal.</p>
                
                <h3>3. Publicação Anônima</h3>
                <p>Ao optar pela publicação anônima, você entende que:</p>
                <ul>
                    <li>Sua identidade não será divulgada publicamente</li>
                    <li>Seus dados pessoais serão armazenados de forma segura</li>
                    <li>Em caso de ordem judicial, seus dados poderão ser fornecidos às autoridades</li>
                </ul>
                
                <h3>4. Direitos Autorais</h3>
                <p>Você mantém os direitos autorais do seu conteúdo, mas concede ao portal uma licença não exclusiva para publicação.</p>
                
                <h3>5. Moderação</h3>
                <p>Todo conteúdo passa por moderação antes da publicação. O portal se reserva o direito de rejeitar conteúdo que viole estes termos.</p>
            </div>
            <div class="terms-modal-footer">
                <label class="terms-accept-check">
                    <input type="checkbox" id="termsAccept" onchange="toggleAcceptBtn()">
                    <span>Li e aceito os termos acima. Declaro que todas as informações são verdadeiras e assumo total responsabilidade pelo conteúdo publicado.</span>
                </label>
                <button class="btn-accept" id="btnAcceptTerms" disabled onclick="aceitarTermos()">
                    ✓ Aceitar e Publicar
                </button>
            </div>
        </div>
    </div>
    
</div>

<!-- Quill JS -->
<script src="https://cdn.quilljs.com/1.3.7/quill.min.js"></script>

<script>
// Inicializar Quill
const quill = new Quill('#editor-container', {
    theme: 'snow',
    placeholder: 'Escreva sua publicação aqui...',
    modules: {
        toolbar: [
            [{ 'header': [1, 2, 3, false] }],
            ['bold', 'italic', 'underline', 'strike'],
            [{ 'color': [] }, { 'background': [] }],
            [{ 'list': 'ordered'}, { 'list': 'bullet' }],
            ['blockquote', 'link', 'image'],
            ['clean']
        ]
    }
});

// Update preview quando editar
quill.on('text-change', function() {
    updatePreview();
});

// Type selector
document.querySelectorAll('.type-option').forEach(opt => {
    opt.addEventListener('click', function() {
        document.querySelectorAll('.type-option').forEach(o => o.classList.remove('selected'));
        this.classList.add('selected');
        updatePreview();
    });
});

// Category selector
document.querySelectorAll('.category-option').forEach(opt => {
    opt.addEventListener('click', function() {
        document.querySelectorAll('.category-option').forEach(o => o.classList.remove('selected'));
        this.classList.add('selected');
    });
});

// Update preview
function updatePreview() {
    const titulo = document.querySelector('input[name="titulo"]').value || 'Título da publicação...';
    const subtitulo = document.querySelector('input[name="subtitulo"]').value;
    const tipo = document.querySelector('input[name="tipo"]:checked')?.value || 'noticia';
    const conteudo = quill.root.innerHTML;
    
    document.getElementById('previewTitulo').textContent = titulo;
    document.getElementById('previewSubtitulo').textContent = subtitulo;
    document.getElementById('previewTipo').textContent = tipo.charAt(0).toUpperCase() + tipo.slice(1);
    document.getElementById('previewBody').innerHTML = conteudo;
    
    // Contadores
    document.getElementById('tituloCount').textContent = titulo.length;
    document.getElementById('subtituloCount').textContent = subtitulo.length;
}

// Preview imagem
function previewImage(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('imagePreviewContainer').innerHTML = 
                `<img src="${e.target.result}" class="image-preview">
                 <div class="image-upload-text">Clique para trocar a imagem</div>`;
            document.getElementById('previewImage').innerHTML = 
                `<img src="${e.target.result}" style="width:100%;height:100%;object-fit:cover;">`;
            document.querySelector('.image-upload').classList.add('has-image');
        };
        reader.readAsDataURL(input.files[0]);
    }
}

// Carregar cidades
async function carregarCidades(estadoId) {
    if (!estadoId) return;
    const select = document.querySelector('select[name="cidade_id"]');
    select.innerHTML = '<option value="">Carregando...</option>';
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/cidades?estado_id=${estadoId}`);
        const data = await res.json();
        
        select.innerHTML = '<option value="">Selecione a cidade</option>';
        if (data.success && data.cidades) {
            data.cidades.forEach(c => {
                select.innerHTML += `<option value="${c.id}">${c.nome}</option>`;
            });
        }
    } catch (e) {
        select.innerHTML = '<option value="">Erro ao carregar</option>';
    }
}

// Carregar bairros
async function carregarBairros(cidadeId) {
    if (!cidadeId) return;
    const select = document.querySelector('select[name="bairro_id"]');
    select.innerHTML = '<option value="">Carregando...</option>';
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/bairros?cidade_id=${cidadeId}`);
        const data = await res.json();
        
        select.innerHTML = '<option value="">Toda a cidade</option>';
        if (data.success && data.bairros) {
            data.bairros.forEach(b => {
                select.innerHTML += `<option value="${b.id}">${b.nome}</option>`;
            });
        }
    } catch (e) {
        select.innerHTML = '<option value="">Toda a cidade</option>';
    }
}

// Toggle anonymous warning
function toggleAnonymous(checkbox) {
    document.getElementById('anonymousWarning').style.display = checkbox.checked ? 'block' : 'none';
}

// Salvar rascunho
async function salvarRascunho() {
    document.getElementById('conteudoHidden').value = quill.root.innerHTML;
    const formData = new FormData(document.getElementById('postForm'));
    formData.append('status', 'rascunho');
    
    try {
        const res = await fetch(window.ACF.apiUrl + '/posts', {
            method: 'POST',
            body: formData
        });
        const data = await res.json();
        
        if (data.success) {
            alert('Rascunho salvo!');
        } else {
            alert(data.error || 'Erro ao salvar');
        }
    } catch (e) {
        alert('Erro de conexão');
    }
}

// Submeter post
function submeterPost() {
    // Validar campos obrigatórios
    const titulo = document.querySelector('input[name="titulo"]').value.trim();
    const cidade = document.querySelector('select[name="cidade_id"]').value;
    const conteudo = quill.getText().trim();
    
    if (!titulo) {
        alert('Digite um título para a publicação');
        return;
    }
    
    if (!cidade) {
        alert('Selecione a cidade');
        return;
    }
    
    if (conteudo.length < 50) {
        alert('O conteúdo precisa ter pelo menos 50 caracteres');
        return;
    }
    
    // Mostrar modal de termos
    document.getElementById('termsModal').classList.add('show');
}

// Toggle accept button
function toggleAcceptBtn() {
    document.getElementById('btnAcceptTerms').disabled = !document.getElementById('termsAccept').checked;
}

// Aceitar termos e enviar
async function aceitarTermos() {
    document.getElementById('conteudoHidden').value = quill.root.innerHTML;
    const formData = new FormData(document.getElementById('postForm'));
    formData.append('status', 'pendente');
    formData.append('termos_aceitos', '1');
    
    const btn = document.getElementById('btnAcceptTerms');
    btn.disabled = true;
    btn.textContent = 'Enviando...';
    
    try {
        const res = await fetch(window.ACF.apiUrl + '/posts', {
            method: 'POST',
            body: formData
        });
        const data = await res.json();
        
        if (data.success) {
            alert('Publicação enviada para moderação!');
            window.location.href = window.ACF.baseUrl + '/autor';
        } else {
            alert(data.error || 'Erro ao enviar');
            btn.disabled = false;
            btn.textContent = '✓ Aceitar e Publicar';
        }
    } catch (e) {
        alert('Erro de conexão');
        btn.disabled = false;
        btn.textContent = '✓ Aceitar e Publicar';
    }
}

// Fechar modal clicando fora
document.getElementById('termsModal').addEventListener('click', function(e) {
    if (e.target === this) {
        this.classList.remove('show');
    }
});

// Init
document.addEventListener('DOMContentLoaded', function() {
    // Se tiver estado selecionado, carregar cidades
    const estadoSelect = document.querySelector('select[name="estado_id"]');
    if (estadoSelect.value) {
        carregarCidades(estadoSelect.value);
    }
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
