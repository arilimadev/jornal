<?php
/**
 * A Cidade Fala v2.0 - Verificação de Identidade
 * Para publicações anônimas
 */

use ACidadeFala\Config\Config;

$pageTitle = "Verificação de Identidade";
$currentPage = "verificacao";
$usuario = $usuario ?? [];
$verificado = $usuario['identidade_verificada'] ?? false;

ob_start();
?>

<style>
.verification-page {
    max-width: 700px;
    margin: var(--space-8) auto;
    padding: 0 var(--space-4);
}

.verification-card {
    background: white;
    border-radius: var(--radius-2xl);
    box-shadow: var(--shadow-lg);
    overflow: hidden;
}

.verification-header {
    background: linear-gradient(135deg, var(--color-primary) 0%, #7c3aed 100%);
    color: white;
    padding: var(--space-8);
    text-align: center;
}

.verification-header-icon {
    font-size: 64px;
    margin-bottom: var(--space-4);
}

.verification-header h1 {
    font-size: var(--text-2xl);
    margin-bottom: var(--space-2);
}

.verification-body {
    padding: var(--space-8);
}

.verification-status {
    text-align: center;
    padding: var(--space-8);
}

.status-badge {
    display: inline-flex;
    align-items: center;
    gap: var(--space-2);
    padding: var(--space-3) var(--space-6);
    border-radius: var(--radius-full);
    font-size: var(--text-lg);
    font-weight: var(--font-semibold);
    margin-bottom: var(--space-4);
}

.status-verified {
    background: #dcfce7;
    color: #166534;
}

.status-pending {
    background: #fef3c7;
    color: #92400e;
}

.status-unverified {
    background: #f1f5f9;
    color: #64748b;
}

/* Warning Box */
.warning-box {
    background: #fef3c7;
    border: 1px solid #fde68a;
    border-radius: var(--radius-xl);
    padding: var(--space-6);
    margin-bottom: var(--space-6);
}

.warning-box-title {
    font-weight: var(--font-bold);
    color: #92400e;
    margin-bottom: var(--space-3);
    display: flex;
    align-items: center;
    gap: var(--space-2);
}

.warning-box ul {
    color: #92400e;
    margin-left: var(--space-6);
    line-height: 1.8;
}

/* Upload Areas */
.upload-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: var(--space-6);
    margin-bottom: var(--space-6);
}

@media (max-width: 640px) {
    .upload-grid { grid-template-columns: 1fr; }
}

.upload-box {
    border: 2px dashed var(--color-gray-300);
    border-radius: var(--radius-xl);
    padding: var(--space-8);
    text-align: center;
    cursor: pointer;
    transition: all var(--transition-fast);
    position: relative;
}

.upload-box:hover {
    border-color: var(--color-primary);
    background: var(--color-primary-50);
}

.upload-box.has-file {
    border-style: solid;
    border-color: var(--color-success);
    background: #f0fdf4;
}

.upload-box input {
    position: absolute;
    inset: 0;
    opacity: 0;
    cursor: pointer;
}

.upload-icon {
    font-size: 48px;
    margin-bottom: var(--space-3);
    opacity: 0.5;
}

.upload-title {
    font-weight: var(--font-semibold);
    margin-bottom: var(--space-1);
}

.upload-desc {
    font-size: var(--text-sm);
    color: var(--color-gray-500);
}

.upload-preview {
    max-width: 100%;
    max-height: 150px;
    border-radius: var(--radius-lg);
    margin-bottom: var(--space-2);
}

.upload-filename {
    font-size: var(--text-sm);
    color: var(--color-success);
    font-weight: var(--font-medium);
}

/* Instructions */
.instructions {
    background: var(--color-gray-50);
    border-radius: var(--radius-xl);
    padding: var(--space-6);
    margin-bottom: var(--space-6);
}

.instructions h3 {
    font-size: var(--text-lg);
    margin-bottom: var(--space-4);
}

.instructions-list {
    display: flex;
    flex-direction: column;
    gap: var(--space-3);
}

.instruction-item {
    display: flex;
    gap: var(--space-3);
}

.instruction-number {
    width: 28px;
    height: 28px;
    background: var(--color-primary);
    color: white;
    border-radius: var(--radius-full);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: var(--font-bold);
    font-size: var(--text-sm);
    flex-shrink: 0;
}

.instruction-text {
    padding-top: 2px;
    color: var(--color-gray-700);
}

/* Terms */
.terms-checkbox {
    display: flex;
    align-items: flex-start;
    gap: var(--space-3);
    margin-bottom: var(--space-6);
}

.terms-checkbox input {
    margin-top: 4px;
    width: 20px;
    height: 20px;
}

.terms-checkbox label {
    font-size: var(--text-sm);
    color: var(--color-gray-600);
    line-height: 1.6;
}

/* Button */
.btn-verify {
    width: 100%;
    padding: var(--space-4);
    background: var(--color-primary);
    color: white;
    border: none;
    border-radius: var(--radius-xl);
    font-size: var(--text-lg);
    font-weight: var(--font-semibold);
    cursor: pointer;
    transition: all var(--transition-fast);
}

.btn-verify:hover {
    background: var(--color-primary-dark);
}

.btn-verify:disabled {
    background: var(--color-gray-400);
    cursor: not-allowed;
}
</style>

<div class="verification-page">
    <div class="verification-card">
        <div class="verification-header">
            <div class="verification-header-icon">🔒</div>
            <h1>Verificação de Identidade</h1>
            <p>Necessária para publicações anônimas</p>
        </div>
        
        <div class="verification-body">
            <?php if ($verificado): ?>
            <!-- Já verificado -->
            <div class="verification-status">
                <span class="status-badge status-verified">
                    ✓ Identidade Verificada
                </span>
                <p>Sua identidade foi verificada em <?= formatDate($usuario['identidade_verificada_em']) ?>.</p>
                <p style="margin-top:var(--space-4);color:var(--color-gray-500);">
                    Você pode publicar anonimamente. Seus dados estão seguros e protegidos.
                </p>
                <a href="<?= url('autor/publicar') ?>" class="btn-verify" style="display:inline-block;max-width:300px;margin-top:var(--space-6);">
                    ✍️ Criar Publicação
                </a>
            </div>
            
            <?php elseif (!empty($usuario['documento_url'])): ?>
            <!-- Aguardando verificação -->
            <div class="verification-status">
                <span class="status-badge status-pending">
                    ⏳ Verificação em Análise
                </span>
                <p>Seus documentos foram enviados e estão sendo analisados.</p>
                <p style="margin-top:var(--space-4);color:var(--color-gray-500);">
                    Esse processo pode levar até 48 horas. Você será notificado por email.
                </p>
            </div>
            
            <?php else: ?>
            <!-- Formulário de verificação -->
            <div class="warning-box">
                <div class="warning-box-title">⚠️ Aviso Importante</div>
                <ul>
                    <li>Sua identidade NÃO será divulgada publicamente</li>
                    <li>Seus dados serão armazenados de forma segura e criptografada</li>
                    <li>Objetivo: combater fake news e garantir responsabilidade</li>
                </ul>
            </div>
            
            <div class="instructions">
                <h3>📋 Como funciona:</h3>
                <div class="instructions-list">
                    <div class="instruction-item">
                        <span class="instruction-number">1</span>
                        <span class="instruction-text">Envie uma foto do seu documento oficial com foto (RG, CNH ou Passaporte)</span>
                    </div>
                    <div class="instruction-item">
                        <span class="instruction-number">2</span>
                        <span class="instruction-text">Tire uma selfie segurando o documento ao lado do rosto</span>
                    </div>
                    <div class="instruction-item">
                        <span class="instruction-number">3</span>
                        <span class="instruction-text">Aguarde a verificação (até 48 horas)</span>
                    </div>
                    <div class="instruction-item">
                        <span class="instruction-number">4</span>
                        <span class="instruction-text">Após aprovado, você poderá publicar anonimamente</span>
                    </div>
                </div>
            </div>
            
            <form id="verificationForm" enctype="multipart/form-data">
                <div class="upload-grid">
                    <!-- Documento -->
                    <div class="upload-box" id="documentoBox">
                        <input type="file" name="documento" id="documentoInput" accept="image/*" required>
                        <div id="documentoPreview">
                            <div class="upload-icon">📄</div>
                            <div class="upload-title">Documento</div>
                            <div class="upload-desc">RG, CNH ou Passaporte</div>
                        </div>
                    </div>
                    
                    <!-- Selfie -->
                    <div class="upload-box" id="selfieBox">
                        <input type="file" name="selfie" id="selfieInput" accept="image/*" required>
                        <div id="selfiePreview">
                            <div class="upload-icon">🤳</div>
                            <div class="upload-title">Selfie</div>
                            <div class="upload-desc">Você segurando o documento</div>
                        </div>
                    </div>
                </div>
                
                <div class="terms-checkbox">
                    <input type="checkbox" id="acceptTerms" required>
                    <label for="acceptTerms">
                        Declaro que li e entendi que meus dados serão armazenados de forma segura e poderão ser fornecidos 
                        às autoridades competentes mediante ordem judicial. Entendo que isso é necessário para combater 
                        fake news e garantir a responsabilidade pelo conteúdo publicado anonimamente.
                    </label>
                </div>
                
                <button type="submit" class="btn-verify" id="btnVerify" disabled>
                    🔒 Enviar para Verificação
                </button>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
// Preview de uploads
function setupUpload(inputId, boxId, previewId) {
    const input = document.getElementById(inputId);
    const box = document.getElementById(boxId);
    const preview = document.getElementById(previewId);
    
    input?.addEventListener('change', function() {
        if (this.files[0]) {
            const reader = new FileReader();
            reader.onload = e => {
                preview.innerHTML = `
                    <img src="${e.target.result}" class="upload-preview">
                    <div class="upload-filename">✓ ${this.files[0].name}</div>
                `;
                box.classList.add('has-file');
                checkForm();
            };
            reader.readAsDataURL(this.files[0]);
        }
    });
}

setupUpload('documentoInput', 'documentoBox', 'documentoPreview');
setupUpload('selfieInput', 'selfieBox', 'selfiePreview');

// Verificar formulário
function checkForm() {
    const doc = document.getElementById('documentoInput').files.length > 0;
    const selfie = document.getElementById('selfieInput').files.length > 0;
    const terms = document.getElementById('acceptTerms').checked;
    
    document.getElementById('btnVerify').disabled = !(doc && selfie && terms);
}

document.getElementById('acceptTerms')?.addEventListener('change', checkForm);

// Submit
document.getElementById('verificationForm')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const btn = document.getElementById('btnVerify');
    btn.disabled = true;
    btn.textContent = 'Enviando...';
    
    const formData = new FormData(this);
    
    try {
        const res = await fetch('<?= url('api/autor/verificacao') ?>', {
            method: 'POST',
            body: formData
        });
        const data = await res.json();
        
        if (data.success) {
            alert('Documentos enviados com sucesso! Você será notificado após a verificação.');
            location.reload();
        } else {
            alert(data.error || 'Erro ao enviar documentos');
            btn.disabled = false;
            btn.textContent = '🔒 Enviar para Verificação';
        }
    } catch (e) {
        alert('Erro de conexão');
        btn.disabled = false;
        btn.textContent = '🔒 Enviar para Verificação';
    }
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
