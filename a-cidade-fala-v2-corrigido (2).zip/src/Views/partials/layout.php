<?php
use ACidadeFala\Config\Config;
$pageTitle = $pageTitle ?? Config::SITE_NAME;
$pageDescription = $pageDescription ?? Config::SITE_DESCRIPTION;
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> | <?= e(Config::SITE_NAME) ?></title>
    <meta name="description" content="<?= e($pageDescription) ?>">
    <link rel="icon" href="<?= asset('images/favicon.svg') ?>">
    <link rel="stylesheet" href="<?= asset('css/variables.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/components.css') ?>">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
    .top-bar{background:#1e293b;color:#fff;padding:8px 0;font-size:13px}
    .top-bar .container{display:flex;justify-content:space-between;align-items:center}
    .top-bar a{color:#fff;text-decoration:none;margin-left:16px}
    .main-header{background:#fff;box-shadow:0 2px 8px rgba(0,0,0,.1);padding:16px 0}
    .header-content{display:flex;justify-content:space-between;align-items:center;gap:24px}
    .logo{display:flex;align-items:center;gap:12px;text-decoration:none}
    .logo-icon{width:50px;height:50px;background:#1a365d;border-radius:12px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:24px;position:relative}
    .logo-icon::after{content:'✓';position:absolute;bottom:-2px;right:-2px;background:#dc2626;width:18px;height:18px;border-radius:50%;font-size:10px;display:flex;align-items:center;justify-content:center}
    .logo-name{font-size:20px;font-weight:800;color:#1a365d}
    .logo-tagline{font-size:11px;color:#64748b}
    .header-search{flex:1;max-width:400px}
    .header-search input{width:100%;padding:10px 16px;border:1px solid #e2e8f0;border-radius:50px;font-size:14px}
    .header-actions{display:flex;align-items:center;gap:12px}
    .btn-publish{background:linear-gradient(135deg,#059669,#10b981);color:#fff;padding:10px 20px;border-radius:8px;text-decoration:none;font-weight:600;display:flex;align-items:center;gap:8px;transition:all .2s;border:none;cursor:pointer}
    .btn-publish:hover{transform:translateY(-2px);box-shadow:0 4px 12px rgba(16,185,129,.4)}
    .main-nav{background:#1a365d}
    .main-nav .container{display:flex;justify-content:space-between;overflow-x:auto}
    .nav-menu{display:flex;list-style:none;margin:0;padding:0}
    .nav-menu a{display:block;padding:12px 16px;color:#fff;text-decoration:none;font-weight:500;white-space:nowrap}
    .nav-menu a:hover{background:rgba(255,255,255,.1)}
    .nav-categories{display:flex}
    .nav-categories a{display:flex;align-items:center;gap:4px;padding:12px;color:rgba(255,255,255,.9);text-decoration:none;font-size:13px;white-space:nowrap}
    .nav-categories a:hover{background:rgba(255,255,255,.1);color:#fff}
    .main-footer{background:#0f172a;color:#94a3b8;padding:48px 0 24px;margin-top:48px}
    .footer-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:32px;margin-bottom:32px}
    .footer-section h4{color:#fff;margin-bottom:16px;font-size:18px}
    .footer-section a{color:#94a3b8;text-decoration:none;display:block;margin-bottom:8px}
    .footer-section a:hover{color:#fff}
    .footer-bottom{border-top:1px solid #334155;padding-top:24px;text-align:center;font-size:14px}
    .footer-love{color:#ef4444}
    .ad-clickable{cursor:pointer;transition:all .2s}
    .ad-clickable:hover{transform:scale(1.02);box-shadow:0 4px 12px rgba(0,0,0,.15)}
    @media(max-width:768px){.header-search{display:none}.nav-categories{display:none}.btn-publish span{display:none}}
    </style>
</head>
<body>
<div class="top-bar"><div class="container"><span><?= dataExtenso() ?></span><div><a href="<?= url('sobre') ?>">Sobre</a><a href="<?= url('contato') ?>">Contato</a></div></div></div>

<header class="main-header"><div class="container"><div class="header-content">
    <a href="<?= url('/') ?>" class="logo"><div class="logo-icon">📰</div><div><div class="logo-name"><?= e(Config::SITE_NAME) ?></div><div class="logo-tagline"><?= e(Config::SITE_TAGLINE) ?></div></div></a>
    <form class="header-search" action="<?= url('busca') ?>" method="GET"><input type="text" name="q" placeholder="Buscar notícias..." value="<?= e($_GET['q'] ?? '') ?>"></form>
    <div class="header-actions">
        <a href="<?= url('autor/publicar') ?>" class="btn-publish" onclick="return checkLogin()"><i data-lucide="edit-3" style="width:18px;height:18px"></i><span>Publicar notícia</span></a>
        <?php if (isset($_SESSION['user_id'])): ?>
        <a href="<?= url($_SESSION['user_tipo'] === 'admin' ? 'admin' : 'autor') ?>" class="btn btn-outline"><i data-lucide="user"></i> Conta</a>
        <?php else: ?>
        <a href="<?= url('login') ?>" class="btn btn-primary">Entrar</a>
        <?php endif; ?>
    </div>
</div></div></header>

<nav class="main-nav"><div class="container">
    <ul class="nav-menu">
        <li><a href="<?= url('/') ?>">Início</a></li>
        <li><a href="<?= url('noticias') ?>">Notícias</a></li>
        <li><a href="<?= url('opinioes') ?>">Opinião</a></li>
        <li><a href="<?= url('denuncias') ?>">Denúncias</a></li>
        <li><a href="<?= url('anunciar') ?>">Anunciar</a></li>
    </ul>
    <div class="nav-categories">
        <?php foreach (array_slice(Config::CATEGORIES, 0, 5) as $cat): ?>
        <a href="<?= url('categoria/' . $cat['slug']) ?>"><?= $cat['icon'] ?> <?= $cat['nome'] ?></a>
        <?php endforeach; ?>
    </div>
</div></nav>

<main><?= $content ?? '' ?></main>

<footer class="main-footer"><div class="container">
    <div class="footer-grid">
        <div class="footer-section"><h4><?= e(Config::SITE_NAME) ?></h4><p><?= e(Config::SITE_TAGLINE) ?></p><p style="margin-top:12px;font-size:13px">Jornalismo colaborativo feito por e para os cidadãos.</p></div>
        <div class="footer-section"><h4>Navegação</h4><a href="<?= url('noticias') ?>">Notícias</a><a href="<?= url('opinioes') ?>">Opiniões</a><a href="<?= url('denuncias') ?>">Denúncias</a><a href="<?= url('anunciar') ?>">Anunciar</a></div>
        <div class="footer-section"><h4>Institucional</h4><a href="<?= url('sobre') ?>">Sobre Nós</a><a href="<?= url('contato') ?>">Contato</a><a href="<?= url('termos') ?>">Termos de Uso</a><a href="<?= url('privacidade') ?>">Privacidade</a></div>
        <div class="footer-section"><h4>Participe</h4><a href="<?= url('registro') ?>">Criar Conta</a><a href="<?= url('autor/publicar') ?>" onclick="return checkLogin()">Publicar Notícia</a><a href="<?= url('anunciar') ?>">Seja Anunciante</a></div>
    </div>
    <div class="footer-bottom"><p>© <?= date('Y') ?> <?= e(Config::SITE_NAME) ?>. Todos os direitos reservados.</p><p style="margin-top:8px">Desenvolvido com <span class="footer-love">❤</span> para o povo</p></div>
</div></footer>

<script>
window.ACF={baseUrl:'<?= url('') ?>',apiUrl:'<?= url('api') ?>'};
function checkLogin(){<?php if(!isset($_SESSION['user_id'])):?>alert('📝 Para publicar notícias você precisa estar logado.\n\nCrie uma conta gratuita ou faça login para continuar.\n\nQualquer cidadão pode publicar!');window.location.href='<?= url('login?redirect=' . urlencode('/autor/publicar')) ?>';return false;<?php endif;?>return true;}
function goToAnunciar(){<?php if(!isset($_SESSION['user_id'])):?>if(confirm('Para anunciar você precisa ter uma conta.\n\nDeseja criar uma conta agora?')){window.location.href='<?= url('registro') ?>';}<?php else:?>window.location.href='<?= url('autor/anunciar') ?>';<?php endif;?>}
lucide.createIcons();
</script>
<script src="<?= asset('js/main.js') ?>"></script>
</body>
</html>
