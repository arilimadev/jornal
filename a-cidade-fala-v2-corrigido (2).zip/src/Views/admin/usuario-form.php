<?php
/**
 * A Cidade Fala v2.0 - Formulário de Usuário
 */

use ACidadeFala\Config\Config;

$isEdit = isset($usuario) && $usuario;
$pageTitle = $isEdit ? "Editar Usuário" : "Novo Usuário";
$activeMenu = "usuarios";

ob_start();
?>

<div style="max-width:800px;">
    <a href="<?= url('admin/usuarios') ?>" class="btn btn-outline" style="margin-bottom:20px;">← Voltar</a>
    
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><?= $isEdit ? '✏️ Editar' : '➕ Novo' ?> Usuário</h3>
        </div>
        <div class="card-body">
            <form id="usuarioForm" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?= $usuario['id'] ?? '' ?>">
                
                <div class="grid-2">
                    <div class="form-group">
                        <label class="form-label">Nome Completo *</label>
                        <input type="text" name="nome" class="form-input" required value="<?= e($usuario['nome'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Email *</label>
                        <input type="email" name="email" class="form-input" required value="<?= e($usuario['email'] ?? '') ?>" <?= $isEdit ? 'readonly' : '' ?>>
                    </div>
                </div>
                
                <?php if (!$isEdit): ?>
                <div class="form-group">
                    <label class="form-label">Senha *</label>
                    <input type="password" name="senha" class="form-input" required minlength="6">
                    <small style="color:#64748b;">Mínimo 6 caracteres</small>
                </div>
                <?php endif; ?>
                
                <div class="grid-2">
                    <div class="form-group">
                        <label class="form-label">Tipo de Usuário *</label>
                        <select name="tipo" class="form-select" required onchange="toggleModeradorCidades(this.value)">
                            <option value="autor" <?= ($usuario['tipo'] ?? '') === 'autor' ? 'selected' : '' ?>>Autor</option>
                            <option value="moderador" <?= ($usuario['tipo'] ?? '') === 'moderador' ? 'selected' : '' ?>>Moderador</option>
                            <option value="anunciante" <?= ($usuario['tipo'] ?? '') === 'anunciante' ? 'selected' : '' ?>>Anunciante</option>
                            <option value="admin" <?= ($usuario['tipo'] ?? '') === 'admin' ? 'selected' : '' ?>>Administrador</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Telefone</label>
                        <input type="text" name="telefone" class="form-input" value="<?= e($usuario['telefone'] ?? '') ?>" placeholder="(00) 00000-0000">
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Cidade Principal</label>
                    <select name="cidade_id" class="form-select">
                        <option value="">Selecione...</option>
                        <?php foreach ($cidades ?? [] as $cidade): ?>
                            <option value="<?= $cidade['id'] ?>" <?= ($usuario['cidade_id'] ?? '') == $cidade['id'] ? 'selected' : '' ?>>
                                <?= e($cidade['nome']) ?> - <?= e($cidade['estado_uf'] ?? '') ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <!-- Cidades do Moderador -->
                <div class="form-group" id="moderadorCidadesGroup" style="display:<?= ($usuario['tipo'] ?? '') === 'moderador' ? 'block' : 'none' ?>;">
                    <label class="form-label">Cidades que pode moderar</label>
                    <div style="max-height:200px;overflow-y:auto;border:1px solid #d1d5db;border-radius:8px;padding:12px;">
                        <?php foreach ($cidades ?? [] as $cidade): ?>
                            <label style="display:flex;align-items:center;gap:8px;padding:6px 0;cursor:pointer;">
                                <input type="checkbox" name="moderar_cidades[]" value="<?= $cidade['id'] ?>" 
                                    <?= in_array($cidade['id'], $moderadorCidades ?? []) ? 'checked' : '' ?>>
                                <?= e($cidade['nome']) ?> - <?= e($cidade['estado_uf'] ?? '') ?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <small style="color:#64748b;">Selecione as cidades que este moderador poderá gerenciar</small>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Biografia</label>
                    <textarea name="bio" class="form-textarea" rows="3" placeholder="Uma breve descrição sobre o usuário..."><?= e($usuario['bio'] ?? '') ?></textarea>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Avatar</label>
                    <?php if (!empty($usuario['avatar'])): ?>
                        <div style="margin-bottom:12px;">
                            <img src="<?= upload($usuario['avatar']) ?>" style="width:80px;height:80px;object-fit:cover;border-radius:50%;">
                        </div>
                    <?php endif; ?>
                    <input type="file" name="avatar" class="form-input" accept="image/*">
                </div>
                
                <div class="form-group">
                    <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                        <input type="checkbox" name="ativo" value="1" <?= ($usuario['ativo'] ?? true) ? 'checked' : '' ?>>
                        Usuário ativo
                    </label>
                </div>
                
                <?php if ($isEdit && !empty($usuario['identidade_verificada'])): ?>
                <div class="alert alert-success">
                    ✓ Identidade verificada em <?= formatDate($usuario['identidade_verificada_em']) ?>
                </div>
                <?php endif; ?>
                
                <div style="display:flex;gap:12px;margin-top:24px;">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <?= $isEdit ? '💾 Salvar Alterações' : '➕ Criar Usuário' ?>
                    </button>
                    <a href="<?= url('admin/usuarios') ?>" class="btn btn-outline btn-lg">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
    
    <?php if ($isEdit): ?>
    <!-- Ações adicionais -->
    <div class="card" style="margin-top:20px;">
        <div class="card-header">
            <h3 class="card-title">⚡ Ações Rápidas</h3>
        </div>
        <div class="card-body">
            <div style="display:flex;gap:12px;flex-wrap:wrap;">
                <button class="btn btn-outline" onclick="resetarSenha(<?= $usuario['id'] ?>)">
                    🔑 Resetar Senha
                </button>
                <a href="<?= url('admin/posts?usuario_id=' . $usuario['id']) ?>" class="btn btn-outline">
                    📰 Ver Posts (<?= $usuario['total_posts'] ?? 0 ?>)
                </a>
                <?php if ($usuario['tipo'] !== 'admin'): ?>
                    <button class="btn btn-danger" onclick="excluirUsuario(<?= $usuario['id'] ?>)">
                        🗑️ Excluir Usuário
                    </button>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
function toggleModeradorCidades(tipo) {
    document.getElementById('moderadorCidadesGroup').style.display = tipo === 'moderador' ? 'block' : 'none';
}

document.getElementById('usuarioForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const isEdit = formData.get('id') ? true : false;
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/usuario${isEdit ? '/' + formData.get('id') : ''}`, {
            method: isEdit ? 'PUT' : 'POST',
            body: formData
        });
        const data = await res.json();
        
        if (data.success) {
            alert(isEdit ? 'Usuário atualizado!' : 'Usuário criado!');
            window.location.href = '<?= url('admin/usuarios') ?>';
        } else {
            alert(data.error || 'Erro ao salvar');
        }
    } catch (e) {
        alert('Erro de conexão');
    }
});

async function resetarSenha(id) {
    if (!confirm('Enviar email para resetar a senha?')) return;
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/usuario/${id}/resetar-senha`, { method: 'POST' });
        const data = await res.json();
        alert(data.success ? 'Email enviado!' : (data.error || 'Erro'));
    } catch (e) {
        alert('Erro de conexão');
    }
}

async function excluirUsuario(id) {
    if (!confirm('ATENÇÃO: Excluir este usuário permanentemente? Esta ação não pode ser desfeita.')) return;
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/usuario/${id}`, { method: 'DELETE' });
        const data = await res.json();
        
        if (data.success) {
            window.location.href = '<?= url('admin/usuarios') ?>';
        } else {
            alert(data.error || 'Erro ao excluir');
        }
    } catch (e) {
        alert('Erro de conexão');
    }
}
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
