<?php
$pageTitle = "Categorias";
$activeMenu = "categorias";
$categorias = $categorias ?? [];
ob_start();
?>

<div class="admin-header">
    <h1>📂 Categorias</h1>
    <button class="btn btn-primary" onclick="openModal()">+ Nova Categoria</button>
</div>

<div class="card">
    <table class="admin-table">
        <thead>
            <tr>
                <th>Ícone</th>
                <th>Nome</th>
                <th>Slug</th>
                <th>Cor</th>
                <th>Status</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($categorias as $cat): ?>
            <tr>
                <td style="font-size:24px"><?= $cat['icone'] ?? '📰' ?></td>
                <td><strong><?= e($cat['nome']) ?></strong></td>
                <td><code><?= e($cat['slug']) ?></code></td>
                <td><span style="display:inline-block;width:24px;height:24px;border-radius:4px;background:<?= e($cat['cor'] ?? '#1a365d') ?>"></span></td>
                <td><?= $cat['ativo'] ? '<span class="badge badge-success">Ativo</span>' : '<span class="badge badge-danger">Inativo</span>' ?></td>
                <td>
                    <button class="btn btn-sm btn-outline" onclick="editCategoria(<?= htmlspecialchars(json_encode($cat)) ?>)">Editar</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteCategoria(<?= $cat['id'] ?>)">Excluir</button>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($categorias)): ?>
            <tr><td colspan="6" style="text-align:center;padding:40px">Nenhuma categoria cadastrada</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Modal -->
<div id="modal" class="modal" style="display:none">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalTitle">Nova Categoria</h3>
            <button onclick="closeModal()" style="background:none;border:none;font-size:24px;cursor:pointer">&times;</button>
        </div>
        <form id="categoriaForm">
            <input type="hidden" name="id" id="catId">
            <div class="form-group">
                <label>Nome</label>
                <input type="text" name="nome" id="catNome" class="form-input" required>
            </div>
            <div class="form-group">
                <label>Ícone (emoji)</label>
                <input type="text" name="icone" id="catIcone" class="form-input" placeholder="📰" required>
            </div>
            <div class="form-group">
                <label>Cor</label>
                <input type="color" name="cor" id="catCor" value="#1a365d">
            </div>
            <div class="form-actions">
                <button type="button" class="btn btn-outline" onclick="closeModal()">Cancelar</button>
                <button type="submit" class="btn btn-primary">Salvar</button>
            </div>
        </form>
    </div>
</div>

<style>
.modal{position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:1000}
.modal-content{background:#fff;border-radius:12px;width:100%;max-width:500px;max-height:90vh;overflow-y:auto}
.modal-header{display:flex;justify-content:space-between;align-items:center;padding:20px;border-bottom:1px solid #e5e7eb}
.modal-header h3{margin:0}
form{padding:20px}
.form-group{margin-bottom:16px}
.form-group label{display:block;margin-bottom:8px;font-weight:500}
.form-input{width:100%;padding:10px;border:1px solid #d1d5db;border-radius:8px}
.form-actions{display:flex;gap:12px;justify-content:flex-end;margin-top:24px}
</style>

<script>
function openModal() {
    document.getElementById('modalTitle').textContent = 'Nova Categoria';
    document.getElementById('categoriaForm').reset();
    document.getElementById('catId').value = '';
    document.getElementById('modal').style.display = 'flex';
}

function closeModal() {
    document.getElementById('modal').style.display = 'none';
}

function editCategoria(cat) {
    document.getElementById('modalTitle').textContent = 'Editar Categoria';
    document.getElementById('catId').value = cat.id;
    document.getElementById('catNome').value = cat.nome;
    document.getElementById('catIcone').value = cat.icone || '📰';
    document.getElementById('catCor').value = cat.cor || '#1a365d';
    document.getElementById('modal').style.display = 'flex';
}

async function deleteCategoria(id) {
    if (!confirm('Excluir esta categoria?')) return;
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/categoria/${id}`, {
            method: 'DELETE',
            headers: {'Content-Type': 'application/json'}
        });
        const data = await res.json();
        if (data.success) location.reload();
        else alert(data.error || 'Erro ao excluir');
    } catch (e) {
        alert('Erro de conexão');
    }
}

document.getElementById('categoriaForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const id = document.getElementById('catId').value;
    const payload = {
        nome: document.getElementById('catNome').value,
        icone: document.getElementById('catIcone').value,
        cor: document.getElementById('catCor').value
    };
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/categoria${id ? '/' + id : ''}`, {
            method: id ? 'PUT' : 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (data.success) location.reload();
        else alert(data.error || 'Erro ao salvar');
    } catch (e) {
        alert('Erro de conexão');
    }
});

document.getElementById('modal').addEventListener('click', function(e) {
    if (e.target === this) closeModal();
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
