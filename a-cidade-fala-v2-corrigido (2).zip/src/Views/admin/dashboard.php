<?php
/**
 * A Cidade Fala v2.0 - Dashboard Admin
 */

use ACidadeFala\Config\Config;

$pageTitle = "Dashboard";
$activeMenu = "dashboard";

// Dados simulados (virão do banco)
$stats = [
    'posts_total' => $stats['posts_total'] ?? 0,
    'posts_pendentes' => $stats['posts_pendentes'] ?? 0,
    'usuarios_total' => $stats['usuarios_total'] ?? 0,
    'comentarios_pendentes' => $stats['comentarios_pendentes'] ?? 0,
    'visualizacoes_mes' => $stats['visualizacoes_mes'] ?? 0,
    'receita_mes' => $stats['receita_mes'] ?? 0,
];

$pendingPosts = $stats['posts_pendentes'];

ob_start();
?>

<!-- Quick Actions -->
<div class="quick-actions">
    <a href="<?= url('admin/moderacao') ?>" class="btn btn-primary">
        ⏳ Moderar Posts (<?= $pendingPosts ?>)
    </a>
    <a href="<?= url('admin/posts/novo') ?>" class="btn btn-outline">
        ➕ Novo Post
    </a>
    <a href="<?= url('admin/usuarios/novo') ?>" class="btn btn-outline">
        👤 Novo Usuário
    </a>
    <a href="<?= url('admin/configuracoes') ?>" class="btn btn-outline">
        ⚙️ Configurações
    </a>
</div>

<!-- Stats Grid -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-card-header">
            <div>
                <div class="stat-card-value"><?= number_format($stats['posts_total']) ?></div>
                <div class="stat-card-label">Posts Publicados</div>
            </div>
            <div class="stat-card-icon blue">📰</div>
        </div>
        <div class="stat-card-change up">↑ 12% este mês</div>
    </div>
    
    <div class="stat-card">
        <div class="stat-card-header">
            <div>
                <div class="stat-card-value"><?= number_format($stats['posts_pendentes']) ?></div>
                <div class="stat-card-label">Aguardando Moderação</div>
            </div>
            <div class="stat-card-icon yellow">⏳</div>
        </div>
        <div class="stat-card-change">Requer atenção</div>
    </div>
    
    <div class="stat-card">
        <div class="stat-card-header">
            <div>
                <div class="stat-card-value"><?= number_format($stats['usuarios_total']) ?></div>
                <div class="stat-card-label">Usuários Cadastrados</div>
            </div>
            <div class="stat-card-icon green">👥</div>
        </div>
        <div class="stat-card-change up">↑ 8% este mês</div>
    </div>
    
    <div class="stat-card">
        <div class="stat-card-header">
            <div>
                <div class="stat-card-value"><?= number_format($stats['visualizacoes_mes']) ?></div>
                <div class="stat-card-label">Visualizações/Mês</div>
            </div>
            <div class="stat-card-icon purple">👁️</div>
        </div>
        <div class="stat-card-change up">↑ 23% vs mês anterior</div>
    </div>
</div>

<!-- Two columns -->
<div class="grid-2">
    <!-- Posts Pendentes -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">⏳ Posts Aguardando Moderação</h3>
            <a href="<?= url('admin/moderacao') ?>" class="btn btn-sm btn-outline">Ver todos</a>
        </div>
        <div class="card-body">
            <?php if (!empty($pendingPostsList)): ?>
                <table>
                    <tbody>
                        <?php foreach (array_slice($pendingPostsList, 0, 5) as $post): ?>
                        <tr>
                            <td>
                                <strong><?= e($post['titulo']) ?></strong>
                                <div style="font-size:12px;color:#64748b;">
                                    Por <?= e($post['autor_nome'] ?? 'Anônimo') ?> • <?= timeAgo($post['created_at'] ?? '') ?>
                                </div>
                            </td>
                            <td>
                                <span class="badge badge-<?= ($post['tipo'] ?? '') === 'denuncia' ? 'danger' : (($post['tipo'] ?? '') === 'opiniao' ? 'info' : 'gray') ?>">
                                    <?= ucfirst($post['tipo'] ?? 'noticia') ?>
                                </span>
                            </td>
                            <td class="actions">
                                <a href="<?= url('admin/moderacao') ?>" class="btn btn-sm btn-primary">Revisar</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-state-icon">✅</div>
                    <div class="empty-state-title">Tudo em dia!</div>
                    <p>Não há posts pendentes de moderação</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Últimos Usuários -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">👥 Novos Usuários</h3>
            <a href="<?= url('admin/usuarios') ?>" class="btn btn-sm btn-outline">Ver todos</a>
        </div>
        <div class="card-body">
            <?php if (!empty($recentUsers)): ?>
                <table>
                    <tbody>
                        <?php foreach (array_slice($recentUsers, 0, 5) as $user): ?>
                        <tr>
                            <td style="display:flex;align-items:center;gap:12px;">
                                <div class="avatar"><?= strtoupper(substr($user['nome'], 0, 1)) ?></div>
                                <div>
                                    <strong><?= e($user['nome']) ?></strong>
                                    <div style="font-size:12px;color:#64748b;"><?= e($user['email']) ?></div>
                                </div>
                            </td>
                            <td>
                                <span class="badge badge-info"><?= ucfirst($user['tipo']) ?></span>
                            </td>
                            <td style="font-size:12px;color:#64748b;">
                                <?= timeAgo($user['created_at']) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-state-icon">👥</div>
                    <p>Nenhum usuário recente</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Comentários Pendentes -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">💬 Comentários Aguardando Aprovação</h3>
        <a href="<?= url('admin/comentarios') ?>" class="btn btn-sm btn-outline">Ver todos</a>
    </div>
    <div class="card-body">
        <?php if (!empty($pendingComments)): ?>
            <table>
                <thead>
                    <tr>
                        <th>Autor</th>
                        <th>Comentário</th>
                        <th>Post</th>
                        <th>Data</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach (array_slice($pendingComments, 0, 5) as $comment): ?>
                    <tr>
                        <td>
                            <strong><?= e($comment['nome']) ?></strong>
                        </td>
                        <td style="max-width:300px;">
                            <?= e(substr($comment['conteudo'], 0, 80)) ?>...
                        </td>
                        <td style="font-size:13px;">
                            <?= e($comment['post_titulo'] ?? 'Post #' . $comment['post_id']) ?>
                        </td>
                        <td style="font-size:12px;color:#64748b;">
                            <?= timeAgo($comment['created_at']) ?>
                        </td>
                        <td class="actions">
                            <button class="btn btn-sm btn-success" onclick="aprovarComentario(<?= $comment['id'] ?>)">✓</button>
                            <button class="btn btn-sm btn-danger" onclick="rejeitarComentario(<?= $comment['id'] ?>)">✕</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="empty-state">
                <div class="empty-state-icon">💬</div>
                <div class="empty-state-title">Nenhum comentário pendente</div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Resumo Financeiro -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">💰 Resumo Financeiro do Mês</h3>
        <a href="<?= url('admin/relatorios') ?>" class="btn btn-sm btn-outline">Ver relatórios</a>
    </div>
    <div class="card-body">
        <div class="stats-grid">
            <div style="text-align:center;padding:20px;background:#f0fdf4;border-radius:8px;">
                <div style="font-size:28px;font-weight:700;color:#16a34a;">
                    R$ <?= number_format($stats['receita_mes'], 2, ',', '.') ?>
                </div>
                <div style="font-size:14px;color:#166534;">Receita Total</div>
            </div>
            <div style="text-align:center;padding:20px;background:#eff6ff;border-radius:8px;">
                <div style="font-size:28px;font-weight:700;color:#2563eb;">
                    <?= $stats['banners_ativos'] ?? 0 ?>
                </div>
                <div style="font-size:14px;color:#1e40af;">Banners Ativos</div>
            </div>
            <div style="text-align:center;padding:20px;background:#fefce8;border-radius:8px;">
                <div style="font-size:28px;font-weight:700;color:#ca8a04;">
                    <?= $stats['destaques_ativos'] ?? 0 ?>
                </div>
                <div style="font-size:14px;color:#92400e;">Destaques Ativos</div>
            </div>
        </div>
    </div>
</div>

<script>
async function aprovarComentario(id) {
    if (!confirm('Aprovar este comentário?')) return;
    try {
        const res = await fetch(window.ACF.apiUrl + '/admin/comentario/' + id + '/aprovar', { method: 'POST' });
        if (res.ok) location.reload();
    } catch (e) { alert('Erro ao aprovar'); }
}

async function rejeitarComentario(id) {
    if (!confirm('Rejeitar este comentário?')) return;
    try {
        const res = await fetch(window.ACF.apiUrl + '/admin/comentario/' + id + '/rejeitar', { method: 'POST' });
        if (res.ok) location.reload();
    } catch (e) { alert('Erro ao rejeitar'); }
}
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
