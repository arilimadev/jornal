<?php
/**
 * A Cidade Fala v2.0 - Gerenciar Banners
 */

use ACidadeFala\Config\Config;

$pageTitle = "Gerenciar Banners";
$activeMenu = "banners";

ob_start();
?>

<div class="quick-actions">
    <a href="<?= url('admin/precos') ?>" class="btn btn-outline">💰 Tabela de Preços</a>
</div>

<!-- Tabs -->
<div class="tabs" style="margin-bottom:0;">
    <a href="?status=pendente" class="tab <?= ($_GET['status'] ?? 'pendente') === 'pendente' ? 'active' : '' ?>">
        ⏳ Pendentes <?php if (($stats['pendentes'] ?? 0) > 0): ?><span class="badge" style="background:#ef4444;color:white;font-size:11px;padding:2px 6px;border-radius:10px;margin-left:4px;"><?= $stats['pendentes'] ?></span><?php endif; ?>
    </a>
    <a href="?status=ativo" class="tab <?= ($_GET['status'] ?? '') === 'ativo' ? 'active' : '' ?>">✓ Ativos (<?= $stats['ativos'] ?? 0 ?>)</a>
    <a href="?status=expirado" class="tab <?= ($_GET['status'] ?? '') === 'expirado' ? 'active' : '' ?>">📅 Expirados</a>
    <a href="?status=" class="tab <?= !isset($_GET['status']) || $_GET['status'] === '' ? '' : '' ?>">📋 Todos</a>
</div>

<!-- Stats -->
<div class="stats-grid" style="margin:24px 0;">
    <div class="stat-card">
        <div class="stat-card-header">
            <div>
                <div class="stat-card-value">R$ <?= number_format($stats['receita_mes'] ?? 0, 2, ',', '.') ?></div>
                <div class="stat-card-label">Receita do Mês</div>
            </div>
            <div class="stat-card-icon green">💰</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-card-header">
            <div>
                <div class="stat-card-value"><?= number_format($stats['impressoes_mes'] ?? 0) ?></div>
                <div class="stat-card-label">Impressões do Mês</div>
            </div>
            <div class="stat-card-icon blue">👁️</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-card-header">
            <div>
                <div class="stat-card-value"><?= number_format($stats['cliques_mes'] ?? 0) ?></div>
                <div class="stat-card-label">Cliques do Mês</div>
            </div>
            <div class="stat-card-icon purple">🖱️</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-card-header">
            <div>
                <div class="stat-card-value"><?= $stats['ativos'] ?? 0 ?></div>
                <div class="stat-card-label">Banners Ativos</div>
            </div>
            <div class="stat-card-icon yellow">🖼️</div>
        </div>
    </div>
</div>

<!-- Lista -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">🖼️ Banners</h3>
    </div>
    
    <?php if (!empty($banners)): ?>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Banner</th>
                    <th>Anunciante</th>
                    <th>Posição</th>
                    <th>Região</th>
                    <th>Período</th>
                    <th>Valor</th>
                    <th>Métricas</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($banners as $banner): ?>
                <tr id="banner-row-<?= $banner['id'] ?>">
                    <td>
                        <div style="display:flex;align-items:center;gap:12px;">
                            <img src="<?= upload($banner['imagem_url']) ?>" style="width:100px;height:60px;object-fit:cover;border-radius:6px;border:1px solid #e2e8f0;">
                            <div>
                                <strong style="display:block;"><?= e($banner['titulo'] ?? 'Sem título') ?></strong>
                                <?php if ($banner['link_url']): ?>
                                    <small style="color:#64748b;"><?= e(substr($banner['link_url'], 0, 30)) ?>...</small>
                                <?php endif; ?>
                            </div>
                        </div>
                    </td>
                    <td>
                        <strong><?= e($banner['anunciante_nome'] ?? 'N/A') ?></strong>
                        <div style="font-size:12px;color:#64748b;"><?= e($banner['anunciante_email'] ?? '') ?></div>
                    </td>
                    <td>
                        <span class="badge badge-info"><?= e($banner['posicao_nome'] ?? 'N/A') ?></span>
                    </td>
                    <td>
                        <?php if ($banner['tipo_regiao'] === 'estado'): ?>
                            🗺️ <?= e($banner['estado_nome'] ?? 'Estado') ?>
                        <?php elseif ($banner['tipo_regiao'] === 'cidade'): ?>
                            🏙️ <?= e($banner['cidade_nome'] ?? 'Cidade') ?>
                        <?php else: ?>
                            📍 Múltiplas cidades
                        <?php endif; ?>
                    </td>
                    <td>
                        <small>
                            <?= formatDate($banner['data_inicio']) ?><br>
                            até <?= formatDate($banner['data_fim']) ?>
                        </small>
                    </td>
                    <td>
                        <strong style="color:#16a34a;">R$ <?= number_format($banner['valor_pago'] ?? 0, 2, ',', '.') ?></strong>
                    </td>
                    <td>
                        <small>
                            👁️ <?= number_format($banner['impressoes']) ?><br>
                            🖱️ <?= number_format($banner['cliques']) ?>
                        </small>
                    </td>
                    <td>
                        <?php
                        $statusClass = match($banner['status']) {
                            'ativo' => 'success',
                            'pendente' => 'warning',
                            'expirado' => 'gray',
                            'rejeitado' => 'danger',
                            default => 'gray'
                        };
                        ?>
                        <span class="badge badge-<?= $statusClass ?>"><?= ucfirst($banner['status']) ?></span>
                    </td>
                    <td>
                        <div class="actions">
                            <?php if ($banner['status'] === 'pendente'): ?>
                                <button class="btn btn-sm btn-success" onclick="aprovarBanner(<?= $banner['id'] ?>)" title="Aprovar">✓</button>
                                <button class="btn btn-sm btn-danger" onclick="rejeitarBanner(<?= $banner['id'] ?>)" title="Rejeitar">✕</button>
                            <?php elseif ($banner['status'] === 'ativo'): ?>
                                <button class="btn btn-sm btn-outline" onclick="pausarBanner(<?= $banner['id'] ?>)" title="Pausar">⏸️</button>
                            <?php endif; ?>
                            <button class="btn btn-sm btn-outline" onclick="visualizarBanner(<?= $banner['id'] ?>)" title="Detalhes">👁️</button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="card-body">
        <div class="empty-state">
            <div class="empty-state-icon">🖼️</div>
            <div class="empty-state-title">Nenhum banner encontrado</div>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Modal Detalhes -->
<div class="modal" id="modalBanner">
    <div class="modal-content modal-lg">
        <div class="modal-header">
            <h3>📋 Detalhes do Banner</h3>
            <button class="modal-close" onclick="fecharModal('modalBanner')">✕</button>
        </div>
        <div class="modal-body" id="bannerDetalhes">
            Carregando...
        </div>
    </div>
</div>

<style>
.modal { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.6); z-index: 1000; align-items: center; justify-content: center; padding: 20px; }
.modal.show { display: flex; }
.modal-content { background: white; border-radius: 12px; max-width: 500px; width: 100%; max-height: 90vh; overflow-y: auto; }
.modal-lg { max-width: 700px; }
.modal-header { padding: 20px 24px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; }
.modal-header h3 { margin: 0; }
.modal-close { background: none; border: none; font-size: 20px; cursor: pointer; color: #64748b; }
.modal-body { padding: 24px; }
</style>

<script>
async function aprovarBanner(id) {
    if (!confirm('Aprovar e ativar este banner?')) return;
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/banner/${id}/aprovar`, { method: 'POST' });
        const data = await res.json();
        
        if (data.success) {
            location.reload();
        } else {
            alert(data.error || 'Erro ao aprovar');
        }
    } catch (e) {
        alert('Erro de conexão');
    }
}

async function rejeitarBanner(id) {
    const motivo = prompt('Motivo da rejeição:');
    if (!motivo) return;
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/banner/${id}/rejeitar`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ motivo })
        });
        const data = await res.json();
        
        if (data.success) {
            location.reload();
        } else {
            alert(data.error || 'Erro ao rejeitar');
        }
    } catch (e) {
        alert('Erro de conexão');
    }
}

async function pausarBanner(id) {
    if (!confirm('Pausar este banner?')) return;
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/banner/${id}/pausar`, { method: 'POST' });
        const data = await res.json();
        
        if (data.success) {
            location.reload();
        } else {
            alert(data.error || 'Erro');
        }
    } catch (e) {
        alert('Erro de conexão');
    }
}

async function visualizarBanner(id) {
    document.getElementById('modalBanner').classList.add('show');
    document.getElementById('bannerDetalhes').innerHTML = 'Carregando...';
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/banner/${id}`);
        const data = await res.json();
        
        if (data.success) {
            const b = data.banner;
            document.getElementById('bannerDetalhes').innerHTML = `
                <img src="${b.imagem_url}" style="width:100%;border-radius:8px;margin-bottom:20px;">
                <h3>${b.titulo || 'Sem título'}</h3>
                <p><strong>Link:</strong> <a href="${b.link_url}" target="_blank">${b.link_url}</a></p>
                <div class="grid-2" style="margin-top:20px;">
                    <div><strong>Anunciante:</strong><br>${b.anunciante_nome}<br>${b.anunciante_email}</div>
                    <div><strong>Posição:</strong><br>${b.posicao_nome}</div>
                    <div><strong>Região:</strong><br>${b.tipo_regiao}</div>
                    <div><strong>Período:</strong><br>${b.data_inicio} a ${b.data_fim}</div>
                    <div><strong>Valor:</strong><br>R$ ${parseFloat(b.valor_pago).toFixed(2)}</div>
                    <div><strong>Status:</strong><br>${b.status}</div>
                </div>
                <div style="margin-top:20px;padding:16px;background:#f8fafc;border-radius:8px;">
                    <strong>Métricas</strong><br>
                    👁️ ${b.impressoes} impressões | 🖱️ ${b.cliques} cliques | CTR: ${b.impressoes > 0 ? ((b.cliques / b.impressoes) * 100).toFixed(2) : 0}%
                </div>
            `;
        }
    } catch (e) {
        document.getElementById('bannerDetalhes').innerHTML = 'Erro ao carregar';
    }
}

function fecharModal(id) {
    document.getElementById(id).classList.remove('show');
}

document.getElementById('modalBanner')?.addEventListener('click', e => {
    if (e.target.id === 'modalBanner') fecharModal('modalBanner');
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
