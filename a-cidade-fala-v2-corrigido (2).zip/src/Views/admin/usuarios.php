<?php
/**
 * A Cidade Fala v2.0 - Gerenciar Usuários
 */

use ACidadeFala\Config\Config;

$pageTitle = "Gerenciar Usuários";
$activeMenu = "usuarios";

$usuarios = $usuarios ?? [];
$tipoFiltro = $_GET['tipo'] ?? '';

ob_start();
?>

<div class="quick-actions">
    <a href="<?= url('admin/usuarios/novo') ?>" class="btn btn-primary">➕ Novo Usuário</a>
    <a href="<?= url('admin/autores') ?>" class="btn btn-outline">✍️ Autores</a>
    <a href="<?= url('admin/moderadores') ?>" class="btn btn-outline">🛡️ Moderadores</a>
    <a href="<?= url('admin/anunciantes') ?>" class="btn btn-outline">📢 Anunciantes</a>
</div>

<!-- Filtros -->
<div class="card" style="margin-bottom:20px;">
    <div class="card-body" style="padding:16px 24px;">
        <form class="search-box" method="GET">
            <select name="tipo" class="form-select" style="width:180px;">
                <option value="">Todos os tipos</option>
                <option value="admin" <?= $tipoFiltro === 'admin' ? 'selected' : '' ?>>Administradores</option>
                <option value="moderador" <?= $tipoFiltro === 'moderador' ? 'selected' : '' ?>>Moderadores</option>
                <option value="autor" <?= $tipoFiltro === 'autor' ? 'selected' : '' ?>>Autores</option>
                <option value="anunciante" <?= $tipoFiltro === 'anunciante' ? 'selected' : '' ?>>Anunciantes</option>
            </select>
            <select name="status" class="form-select" style="width:150px;">
                <option value="">Todos</option>
                <option value="1" <?= ($_GET['status'] ?? '') === '1' ? 'selected' : '' ?>>Ativos</option>
                <option value="0" <?= ($_GET['status'] ?? '') === '0' ? 'selected' : '' ?>>Inativos</option>
            </select>
            <input type="text" name="busca" class="search-input" placeholder="Buscar por nome ou email..." value="<?= e($_GET['busca'] ?? '') ?>">
            <button type="submit" class="btn btn-primary">🔍 Filtrar</button>
        </form>
    </div>
</div>

<!-- Stats -->
<div class="stats-grid" style="margin-bottom:24px;">
    <div class="stat-card">
        <div class="stat-card-header">
            <div>
                <div class="stat-card-value"><?= $stats['total'] ?? 0 ?></div>
                <div class="stat-card-label">Total de Usuários</div>
            </div>
            <div class="stat-card-icon blue">👥</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-card-header">
            <div>
                <div class="stat-card-value"><?= $stats['autores'] ?? 0 ?></div>
                <div class="stat-card-label">Autores</div>
            </div>
            <div class="stat-card-icon green">✍️</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-card-header">
            <div>
                <div class="stat-card-value"><?= $stats['moderadores'] ?? 0 ?></div>
                <div class="stat-card-label">Moderadores</div>
            </div>
            <div class="stat-card-icon purple">🛡️</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-card-header">
            <div>
                <div class="stat-card-value"><?= $stats['anunciantes'] ?? 0 ?></div>
                <div class="stat-card-label">Anunciantes</div>
            </div>
            <div class="stat-card-icon yellow">📢</div>
        </div>
    </div>
</div>

<!-- Lista -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">👥 Usuários Cadastrados</h3>
    </div>
    
    <?php if (!empty($usuarios)): ?>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Usuário</th>
                    <th>Tipo</th>
                    <th>Cidade</th>
                    <th>Posts</th>
                    <th>Status</th>
                    <th>Cadastro</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($usuarios as $user): ?>
                <tr>
                    <td>
                        <div style="display:flex;align-items:center;gap:12px;">
                            <div class="avatar"><?= strtoupper(substr($user['nome'], 0, 1)) ?></div>
                            <div>
                                <strong><?= e($user['nome']) ?></strong>
                                <div style="font-size:12px;color:#64748b;"><?= e($user['email']) ?></div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <?php
                        $tipoClass = match($user['tipo']) {
                            'admin' => 'danger',
                            'moderador' => 'info',
                            'anunciante' => 'warning',
                            default => 'gray'
                        };
                        $tipoIcon = match($user['tipo']) {
                            'admin' => '👑',
                            'moderador' => '🛡️',
                            'anunciante' => '📢',
                            default => '✍️'
                        };
                        ?>
                        <span class="badge badge-<?= $tipoClass ?>">
                            <?= $tipoIcon ?> <?= ucfirst($user['tipo']) ?>
                        </span>
                    </td>
                    <td>
                        <small><?= e($user['cidade_nome'] ?? '-') ?></small>
                    </td>
                    <td>
                        <span style="font-weight:600;"><?= $user['total_posts'] ?? 0 ?></span>
                    </td>
                    <td>
                        <?php if ($user['ativo']): ?>
                            <span class="badge badge-success">Ativo</span>
                        <?php else: ?>
                            <span class="badge badge-danger">Inativo</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <small><?= formatDate($user['created_at']) ?></small>
                    </td>
                    <td>
                        <div class="actions">
                            <a href="<?= url('admin/usuarios/' . $user['id']) ?>" class="btn btn-sm btn-outline" title="Editar">✏️</a>
                            <?php if ($user['tipo'] !== 'admin'): ?>
                                <?php if ($user['ativo']): ?>
                                    <button class="btn btn-sm btn-danger" onclick="toggleUsuario(<?= $user['id'] ?>, false)" title="Desativar">🚫</button>
                                <?php else: ?>
                                    <button class="btn btn-sm btn-success" onclick="toggleUsuario(<?= $user['id'] ?>, true)" title="Ativar">✓</button>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Paginação -->
    <?php if (($totalPages ?? 1) > 1): ?>
    <div class="card-footer">
        <div class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?page=<?= $i ?>&tipo=<?= e($tipoFiltro) ?>" class="<?= ($page ?? 1) == $i ? 'active' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>
        </div>
    </div>
    <?php endif; ?>
    
    <?php else: ?>
    <div class="card-body">
        <div class="empty-state">
            <div class="empty-state-icon">👥</div>
            <div class="empty-state-title">Nenhum usuário encontrado</div>
            <p>Ajuste os filtros ou cadastre um novo usuário</p>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
async function toggleUsuario(id, ativar) {
    const acao = ativar ? 'ativar' : 'desativar';
    if (!confirm(`${ativar ? 'Ativar' : 'Desativar'} este usuário?`)) return;
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/usuario/${id}/${acao}`, { method: 'POST' });
        const data = await res.json();
        
        if (data.success) {
            location.reload();
        } else {
            alert(data.error || 'Erro ao alterar status');
        }
    } catch (e) {
        alert('Erro de conexão');
    }
}
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
