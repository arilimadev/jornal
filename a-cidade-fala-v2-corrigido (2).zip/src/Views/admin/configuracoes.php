<?php
/**
 * A Cidade Fala v2.0 - Configurações do Site
 */

use ACidadeFala\Config\Config;

$pageTitle = "Configurações";
$activeMenu = "configuracoes";

// Configurações é um array associativo: ['chave' => 'valor']
$configs = $configuracoes ?? [];

ob_start();
?>

<form id="configForm">
    <!-- Informações Gerais -->
    <div class="card" style="margin-bottom:24px;">
        <div class="card-header">
            <h3 class="card-title">🏠 Informações Gerais</h3>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label class="form-label">Nome do Site</label>
                <input type="text" name="site_nome" class="form-input" value="<?= e($configs['site_nome'] ?? 'A Cidade Fala') ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Descrição do Site</label>
                <textarea name="site_descricao" class="form-textarea" rows="2"><?= e($configs['site_descricao'] ?? 'Portal de jornalismo colaborativo') ?></textarea>
            </div>
            <div class="form-group">
                <label class="form-label">Email de Contato</label>
                <input type="email" name="email_contato" class="form-input" value="<?= e($configs['email_contato'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Telefone</label>
                <input type="text" name="telefone" class="form-input" value="<?= e($configs['telefone'] ?? '') ?>">
            </div>
        </div>
    </div>

    <!-- Aparência -->
    <div class="card" style="margin-bottom:24px;">
        <div class="card-header">
            <h3 class="card-title">🎨 Aparência</h3>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label class="form-label">Cor Primária</label>
                <div style="display:flex;align-items:center;gap:12px;">
                    <input type="color" name="cor_primaria" value="<?= e($configs['cor_primaria'] ?? '#1e40af') ?>" style="width:60px;height:40px;border:none;cursor:pointer;">
                    <span id="corPrimariaHex"><?= e($configs['cor_primaria'] ?? '#1e40af') ?></span>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Cor Secundária</label>
                <div style="display:flex;align-items:center;gap:12px;">
                    <input type="color" name="cor_secundaria" value="<?= e($configs['cor_secundaria'] ?? '#dc2626') ?>" style="width:60px;height:40px;border:none;cursor:pointer;">
                    <span id="corSecundariaHex"><?= e($configs['cor_secundaria'] ?? '#dc2626') ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Redes Sociais -->
    <div class="card" style="margin-bottom:24px;">
        <div class="card-header">
            <h3 class="card-title">🌐 Redes Sociais</h3>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label class="form-label">Facebook</label>
                <input type="url" name="facebook_url" class="form-input" placeholder="https://facebook.com/..." value="<?= e($configs['facebook_url'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Instagram</label>
                <input type="url" name="instagram_url" class="form-input" placeholder="https://instagram.com/..." value="<?= e($configs['instagram_url'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Twitter/X</label>
                <input type="url" name="twitter_url" class="form-input" placeholder="https://twitter.com/..." value="<?= e($configs['twitter_url'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label class="form-label">WhatsApp</label>
                <input type="text" name="whatsapp" class="form-input" placeholder="(00) 00000-0000" value="<?= e($configs['whatsapp'] ?? '') ?>">
            </div>
        </div>
    </div>

    <!-- SEO -->
    <div class="card" style="margin-bottom:24px;">
        <div class="card-header">
            <h3 class="card-title">🔍 SEO</h3>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label class="form-label">Meta Description Padrão</label>
                <textarea name="meta_description" class="form-textarea" rows="2"><?= e($configs['meta_description'] ?? '') ?></textarea>
            </div>
            <div class="form-group">
                <label class="form-label">Palavras-chave</label>
                <input type="text" name="meta_keywords" class="form-input" placeholder="notícias, cidade, jornalismo" value="<?= e($configs['meta_keywords'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Google Analytics ID</label>
                <input type="text" name="google_analytics" class="form-input" placeholder="G-XXXXXXXXXX" value="<?= e($configs['google_analytics'] ?? '') ?>">
            </div>
        </div>
    </div>

    <!-- Moderação -->
    <div class="card" style="margin-bottom:24px;">
        <div class="card-header">
            <h3 class="card-title">⚙️ Moderação</h3>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                    <input type="checkbox" name="moderacao_automatica" value="1" <?= ($configs['moderacao_automatica'] ?? '') === '1' ? 'checked' : '' ?>>
                    Aprovação automática de posts (sem moderação)
                </label>
            </div>
            <div class="form-group">
                <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                    <input type="checkbox" name="comentarios_ativos" value="1" <?= ($configs['comentarios_ativos'] ?? '1') === '1' ? 'checked' : '' ?>>
                    Permitir comentários nos posts
                </label>
            </div>
            <div class="form-group">
                <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                    <input type="checkbox" name="denuncias_ativas" value="1" <?= ($configs['denuncias_ativas'] ?? '1') === '1' ? 'checked' : '' ?>>
                    Permitir denúncias anônimas
                </label>
            </div>
        </div>
    </div>

    <div style="position:sticky;bottom:0;background:white;padding:20px;border-top:1px solid #e2e8f0;margin:0 -24px -24px;display:flex;gap:12px;justify-content:flex-end;">
        <button type="button" class="btn btn-outline" onclick="location.reload()">Cancelar</button>
        <button type="submit" class="btn btn-primary btn-lg">💾 Salvar Configurações</button>
    </div>
</form>

<script>
// Atualizar hex quando cor mudar
document.querySelectorAll('input[type="color"]').forEach(input => {
    input.addEventListener('input', function() {
        const span = this.parentElement.querySelector('span');
        if (span) span.textContent = this.value;
    });
});

// Submit
document.getElementById('configForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const payload = {};
    
    for (let [key, value] of formData.entries()) {
        payload[key] = value;
    }
    
    // Checkboxes não marcados
    if (!formData.has('moderacao_automatica')) payload['moderacao_automatica'] = '0';
    if (!formData.has('comentarios_ativos')) payload['comentarios_ativos'] = '0';
    if (!formData.has('denuncias_ativas')) payload['denuncias_ativas'] = '0';
    
    try {
        const res = await fetch('<?= url('api/admin/configuracoes') ?>', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        
        if (data.success) {
            alert('✅ Configurações salvas!');
            location.reload();
        } else {
            alert(data.error || 'Erro ao salvar');
        }
    } catch (e) {
        alert('Erro de conexão');
    }
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
