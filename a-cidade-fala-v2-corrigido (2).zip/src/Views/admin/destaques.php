<?php
$pageTitle = "Destaques";
$activeMenu = "destaques";
$destaques = $destaques ?? [];
ob_start();
?>

<div class="admin-header">
    <h1>⭐ Posts em Destaque</h1>
</div>

<div class="card">
    <table class="admin-table">
        <thead>
            <tr>
                <th>Post</th>
                <th>Início</th>
                <th>Fim</th>
                <th>Status</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($destaques as $d): ?>
            <tr>
                <td><?= e($d['post_titulo'] ?? 'Post #' . $d['post_id']) ?></td>
                <td><?= formatDate($d['data_inicio'] ?? '') ?></td>
                <td><?= formatDate($d['data_fim'] ?? '') ?></td>
                <td><?= $d['status'] === 'ativo' ? '<span class="badge badge-success">Ativo</span>' : '<span class="badge badge-warning">' . ucfirst($d['status'] ?? '') . '</span>' ?></td>
                <td>
                    <button class="btn btn-sm btn-danger">Cancelar</button>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($destaques)): ?>
            <tr><td colspan="5" style="text-align:center;padding:40px">Nenhum destaque ativo</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
