<?php
/**
 * A Cidade Fala v2.0 - Gerenciar Comentários
 */

use ACidadeFala\Config\Config;

$pageTitle = "Gerenciar Comentários";
$activeMenu = "comentarios";

ob_start();
?>

<!-- Tabs -->
<div class="tabs" style="margin-bottom:24px;">
    <a href="?status=pendente" class="tab <?= ($_GET['status'] ?? 'pendente') === 'pendente' ? 'active' : '' ?>">
        ⏳ Pendentes <?php if (($stats['pendentes'] ?? 0) > 0): ?><span class="badge" style="background:#ef4444;color:white;font-size:11px;padding:2px 6px;border-radius:10px;margin-left:4px;"><?= $stats['pendentes'] ?></span><?php endif; ?>
    </a>
    <a href="?status=aprovado" class="tab <?= ($_GET['status'] ?? '') === 'aprovado' ? 'active' : '' ?>">✓ Aprovados</a>
    <a href="?status=" class="tab <?= !isset($_GET['status']) || $_GET['status'] === '' ? '' : '' ?>">📋 Todos</a>
</div>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">💬 Comentários</h3>
        <div style="display:flex;gap:8px;">
            <button class="btn btn-sm btn-success" onclick="aprovarSelecionados()">✓ Aprovar Selecionados</button>
            <button class="btn btn-sm btn-danger" onclick="excluirSelecionados()">🗑️ Excluir Selecionados</button>
        </div>
    </div>
    
    <?php if (!empty($comentarios)): ?>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th style="width:40px;"><input type="checkbox" id="selectAll" onchange="toggleSelectAll()"></th>
                    <th>Autor</th>
                    <th>Comentário</th>
                    <th>Post</th>
                    <th>Data</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($comentarios as $comentario): ?>
                <tr id="comment-row-<?= $comentario['id'] ?>">
                    <td><input type="checkbox" class="comment-checkbox" value="<?= $comentario['id'] ?>"></td>
                    <td>
                        <strong><?= e($comentario['nome']) ?></strong>
                        <div style="font-size:12px;color:#64748b;"><?= e($comentario['email']) ?></div>
                    </td>
                    <td style="max-width:300px;">
                        <div style="font-size:14px;line-height:1.5;">
                            <?= e(substr($comentario['conteudo'], 0, 150)) ?><?= strlen($comentario['conteudo']) > 150 ? '...' : '' ?>
                        </div>
                    </td>
                    <td>
                        <a href="<?= url('admin/posts/' . $comentario['post_id']) ?>" style="font-size:13px;color:#3b82f6;">
                            <?= e(substr($comentario['post_titulo'] ?? 'Post #' . $comentario['post_id'], 0, 40)) ?>
                        </a>
                    </td>
                    <td>
                        <small><?= timeAgo($comentario['created_at']) ?></small>
                        <div style="font-size:11px;color:#94a3b8;">IP: <?= e($comentario['ip'] ?? 'N/A') ?></div>
                    </td>
                    <td>
                        <?php if ($comentario['aprovado']): ?>
                            <span class="badge badge-success">Aprovado</span>
                        <?php else: ?>
                            <span class="badge badge-warning">Pendente</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="actions">
                            <?php if (!$comentario['aprovado']): ?>
                                <button class="btn btn-sm btn-success" onclick="aprovarComentario(<?= $comentario['id'] ?>)" title="Aprovar">✓</button>
                            <?php endif; ?>
                            <button class="btn btn-sm btn-outline" onclick="verComentario(<?= htmlspecialchars(json_encode($comentario)) ?>)" title="Ver">👁️</button>
                            <button class="btn btn-sm btn-danger" onclick="excluirComentario(<?= $comentario['id'] ?>)" title="Excluir">🗑️</button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Paginação -->
    <?php if (($totalPages ?? 1) > 1): ?>
    <div class="card-footer">
        <div class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?page=<?= $i ?>&status=<?= e($_GET['status'] ?? '') ?>" class="<?= ($page ?? 1) == $i ? 'active' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>
        </div>
    </div>
    <?php endif; ?>
    
    <?php else: ?>
    <div class="card-body">
        <div class="empty-state">
            <div class="empty-state-icon">💬</div>
            <div class="empty-state-title">Nenhum comentário</div>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Modal Ver Comentário -->
<div class="modal" id="modalComentario">
    <div class="modal-content">
        <div class="modal-header">
            <h3>💬 Detalhes do Comentário</h3>
            <button class="modal-close" onclick="fecharModal('modalComentario')">✕</button>
        </div>
        <div class="modal-body" id="comentarioDetalhes"></div>
        <div class="modal-footer" id="comentarioActions"></div>
    </div>
</div>

<style>
.modal { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.6); z-index: 1000; align-items: center; justify-content: center; padding: 20px; }
.modal.show { display: flex; }
.modal-content { background: white; border-radius: 12px; max-width: 600px; width: 100%; }
.modal-header { padding: 20px 24px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; }
.modal-header h3 { margin: 0; }
.modal-close { background: none; border: none; font-size: 20px; cursor: pointer; }
.modal-body { padding: 24px; }
.modal-footer { padding: 16px 24px; border-top: 1px solid #e2e8f0; display: flex; gap: 12px; justify-content: flex-end; }
</style>

<script>
let comentarioAtual = null;

function toggleSelectAll() {
    const checked = document.getElementById('selectAll').checked;
    document.querySelectorAll('.comment-checkbox').forEach(cb => cb.checked = checked);
}

function verComentario(comentario) {
    comentarioAtual = comentario;
    document.getElementById('comentarioDetalhes').innerHTML = `
        <div style="margin-bottom:16px;">
            <strong>${comentario.nome}</strong>
            <div style="font-size:13px;color:#64748b;">${comentario.email}</div>
        </div>
        <div style="background:#f8fafc;padding:16px;border-radius:8px;margin-bottom:16px;">
            ${comentario.conteudo.replace(/\n/g, '<br>')}
        </div>
        <div style="font-size:13px;color:#64748b;">
            <div>📅 ${comentario.created_at}</div>
            <div>🌐 IP: ${comentario.ip || 'N/A'}</div>
            <div>📰 Post: ${comentario.post_titulo || 'N/A'}</div>
        </div>
    `;
    
    let actions = '<button class="btn btn-outline" onclick="fecharModal(\'modalComentario\')">Fechar</button>';
    if (!comentario.aprovado) {
        actions += '<button class="btn btn-success" onclick="aprovarComentario(' + comentario.id + ');fecharModal(\'modalComentario\');">Aprovar</button>';
    }
    actions += '<button class="btn btn-danger" onclick="excluirComentario(' + comentario.id + ');fecharModal(\'modalComentario\');">Excluir</button>';
    document.getElementById('comentarioActions').innerHTML = actions;
    
    document.getElementById('modalComentario').classList.add('show');
}

function fecharModal(id) {
    document.getElementById(id).classList.remove('show');
}

async function aprovarComentario(id) {
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/comentario/${id}/aprovar`, { method: 'POST' });
        const data = await res.json();
        if (data.success) location.reload();
        else alert(data.error || 'Erro');
    } catch (e) { alert('Erro de conexão'); }
}

async function excluirComentario(id) {
    if (!confirm('Excluir este comentário?')) return;
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/comentario/${id}`, { method: 'DELETE' });
        const data = await res.json();
        if (data.success) document.getElementById(`comment-row-${id}`)?.remove();
        else alert(data.error || 'Erro');
    } catch (e) { alert('Erro de conexão'); }
}

async function aprovarSelecionados() {
    const ids = Array.from(document.querySelectorAll('.comment-checkbox:checked')).map(cb => cb.value);
    if (ids.length === 0) return alert('Selecione pelo menos um comentário');
    
    for (const id of ids) {
        await aprovarComentario(id);
    }
}

async function excluirSelecionados() {
    const ids = Array.from(document.querySelectorAll('.comment-checkbox:checked')).map(cb => cb.value);
    if (ids.length === 0) return alert('Selecione pelo menos um comentário');
    if (!confirm(`Excluir ${ids.length} comentário(s)?`)) return;
    
    for (const id of ids) {
        try {
            await fetch(`${window.ACF.apiUrl}/admin/comentario/${id}`, { method: 'DELETE' });
            document.getElementById(`comment-row-${id}`)?.remove();
        } catch (e) {}
    }
}

document.getElementById('modalComentario')?.addEventListener('click', e => {
    if (e.target.id === 'modalComentario') fecharModal('modalComentario');
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
