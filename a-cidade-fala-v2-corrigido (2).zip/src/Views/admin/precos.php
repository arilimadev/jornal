<?php
/**
 * A Cidade Fala v2.0 - Tabela de Preços
 */

use ACidadeFala\Config\Config;

$pageTitle = "Tabela de Preços";
$activeMenu = "precos";

ob_start();
?>

<div class="quick-actions">
    <button class="btn btn-primary" onclick="abrirModalPreco('banner')">➕ Novo Preço de Banner</button>
    <button class="btn btn-outline" onclick="abrirModalPreco('destaque')">➕ Novo Preço de Destaque</button>
</div>

<!-- Preços de Banner -->
<div class="card" style="margin-bottom:24px;">
    <div class="card-header">
        <h3 class="card-title">🖼️ Preços de Banners</h3>
    </div>
    
    <?php if (!empty($bannerPrecos)): ?>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Posição</th>
                    <th>Tipo de Região</th>
                    <th>Período</th>
                    <th>Preço</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($bannerPrecos as $preco): ?>
                <tr>
                    <td><strong><?= e($preco['posicao_nome'] ?? 'N/A') ?></strong></td>
                    <td>
                        <?php
                        $regiaoIcon = match($preco['tipo_regiao']) {
                            'estado' => '🗺️',
                            'cidade' => '🏙️',
                            'multiplas_cidades' => '📍',
                            default => '📌'
                        };
                        ?>
                        <?= $regiaoIcon ?> <?= ucfirst(str_replace('_', ' ', $preco['tipo_regiao'])) ?>
                    </td>
                    <td><?= $preco['dias'] ?> dias</td>
                    <td><strong style="color:#16a34a;">R$ <?= number_format($preco['preco'], 2, ',', '.') ?></strong></td>
                    <td>
                        <?php if ($preco['ativo']): ?>
                            <span class="badge badge-success">Ativo</span>
                        <?php else: ?>
                            <span class="badge badge-gray">Inativo</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="actions">
                            <button class="btn btn-sm btn-outline" onclick="editarPrecoBanner(<?= htmlspecialchars(json_encode($preco)) ?>)">✏️</button>
                            <button class="btn btn-sm btn-danger" onclick="excluirPreco('banner', <?= $preco['id'] ?>)">🗑️</button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="card-body">
        <div class="empty-state">
            <p>Nenhum preço cadastrado</p>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Preços de Destaque -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">⭐ Preços de Destaques</h3>
    </div>
    
    <?php if (!empty($destaquePrecos)): ?>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Tipo</th>
                    <th>Período</th>
                    <th>Preço</th>
                    <th>Descrição</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($destaquePrecos as $preco): ?>
                <tr>
                    <td>
                        <?php
                        $tipoIcon = match($preco['tipo']) {
                            'home' => '🏠',
                            'cidade' => '🏙️',
                            'categoria' => '🏷️',
                            default => '⭐'
                        };
                        ?>
                        <strong><?= $tipoIcon ?> <?= ucfirst($preco['tipo']) ?></strong>
                    </td>
                    <td><?= $preco['dias'] ?> dias</td>
                    <td><strong style="color:#16a34a;">R$ <?= number_format($preco['preco'], 2, ',', '.') ?></strong></td>
                    <td><small><?= e($preco['descricao'] ?? '-') ?></small></td>
                    <td>
                        <?php if ($preco['ativo']): ?>
                            <span class="badge badge-success">Ativo</span>
                        <?php else: ?>
                            <span class="badge badge-gray">Inativo</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="actions">
                            <button class="btn btn-sm btn-outline" onclick="editarPrecoDestaque(<?= htmlspecialchars(json_encode($preco)) ?>)">✏️</button>
                            <button class="btn btn-sm btn-danger" onclick="excluirPreco('destaque', <?= $preco['id'] ?>)">🗑️</button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="card-body">
        <div class="empty-state">
            <p>Nenhum preço cadastrado</p>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Modal Preço Banner -->
<div class="modal" id="modalPrecoBanner">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalPrecoBannerTitle">Preço de Banner</h3>
            <button class="modal-close" onclick="fecharModal('modalPrecoBanner')">✕</button>
        </div>
        <form id="precoBannerForm">
            <div class="modal-body">
                <input type="hidden" name="id" id="precoBannerId">
                
                <div class="form-group">
                    <label class="form-label">Posição do Banner *</label>
                    <select name="posicao_id" id="precoBannerPosicao" class="form-select" required>
                        <option value="">Selecione...</option>
                        <?php foreach ($posicoes ?? [] as $pos): ?>
                            <option value="<?= $pos['id'] ?>"><?= e($pos['nome']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Tipo de Região *</label>
                    <select name="tipo_regiao" id="precoBannerRegiao" class="form-select" required>
                        <option value="cidade">Por Cidade</option>
                        <option value="estado">Por Estado</option>
                        <option value="multiplas_cidades">Múltiplas Cidades</option>
                    </select>
                </div>
                
                <div class="grid-2">
                    <div class="form-group">
                        <label class="form-label">Período (dias) *</label>
                        <input type="number" name="dias" id="precoBannerDias" class="form-input" required min="1">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Preço (R$) *</label>
                        <input type="number" name="preco" id="precoBannerPreco" class="form-input" required min="0" step="0.01">
                    </div>
                </div>
                
                <div class="form-group">
                    <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                        <input type="checkbox" name="ativo" id="precoBannerAtivo" value="1" checked>
                        Preço ativo
                    </label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="fecharModal('modalPrecoBanner')">Cancelar</button>
                <button type="submit" class="btn btn-primary">💾 Salvar</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Preço Destaque -->
<div class="modal" id="modalPrecoDestaque">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalPrecoDestaqueTitle">Preço de Destaque</h3>
            <button class="modal-close" onclick="fecharModal('modalPrecoDestaque')">✕</button>
        </div>
        <form id="precoDestaqueForm">
            <div class="modal-body">
                <input type="hidden" name="id" id="precoDestaqueId">
                
                <div class="form-group">
                    <label class="form-label">Tipo de Destaque *</label>
                    <select name="tipo" id="precoDestaqueTipo" class="form-select" required>
                        <option value="home">🏠 Home (Página Inicial)</option>
                        <option value="cidade">🏙️ Cidade</option>
                        <option value="categoria">🏷️ Categoria</option>
                    </select>
                </div>
                
                <div class="grid-2">
                    <div class="form-group">
                        <label class="form-label">Período (dias) *</label>
                        <input type="number" name="dias" id="precoDestaqueDias" class="form-input" required min="1">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Preço (R$) *</label>
                        <input type="number" name="preco" id="precoDestaquePreco" class="form-input" required min="0" step="0.01">
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Descrição</label>
                    <input type="text" name="descricao" id="precoDestaqueDesc" class="form-input" placeholder="Ex: Destaque na home por 7 dias">
                </div>
                
                <div class="form-group">
                    <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                        <input type="checkbox" name="ativo" id="precoDestaqueAtivo" value="1" checked>
                        Preço ativo
                    </label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="fecharModal('modalPrecoDestaque')">Cancelar</button>
                <button type="submit" class="btn btn-primary">💾 Salvar</button>
            </div>
        </form>
    </div>
</div>

<style>
.modal { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.6); z-index: 1000; align-items: center; justify-content: center; padding: 20px; }
.modal.show { display: flex; }
.modal-content { background: white; border-radius: 12px; max-width: 500px; width: 100%; }
.modal-header { padding: 20px 24px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; }
.modal-header h3 { margin: 0; }
.modal-close { background: none; border: none; font-size: 20px; cursor: pointer; }
.modal-body { padding: 24px; }
.modal-footer { padding: 16px 24px; border-top: 1px solid #e2e8f0; display: flex; gap: 12px; justify-content: flex-end; }
</style>

<script>
function abrirModalPreco(tipo) {
    if (tipo === 'banner') {
        document.getElementById('precoBannerForm').reset();
        document.getElementById('precoBannerId').value = '';
        document.getElementById('modalPrecoBannerTitle').textContent = '➕ Novo Preço de Banner';
        document.getElementById('modalPrecoBanner').classList.add('show');
    } else {
        document.getElementById('precoDestaqueForm').reset();
        document.getElementById('precoDestaqueId').value = '';
        document.getElementById('modalPrecoDestaqueTitle').textContent = '➕ Novo Preço de Destaque';
        document.getElementById('modalPrecoDestaque').classList.add('show');
    }
}

function editarPrecoBanner(preco) {
    document.getElementById('modalPrecoBannerTitle').textContent = '✏️ Editar Preço de Banner';
    document.getElementById('precoBannerId').value = preco.id;
    document.getElementById('precoBannerPosicao').value = preco.posicao_id;
    document.getElementById('precoBannerRegiao').value = preco.tipo_regiao;
    document.getElementById('precoBannerDias').value = preco.dias;
    document.getElementById('precoBannerPreco').value = preco.preco;
    document.getElementById('precoBannerAtivo').checked = preco.ativo;
    document.getElementById('modalPrecoBanner').classList.add('show');
}

function editarPrecoDestaque(preco) {
    document.getElementById('modalPrecoDestaqueTitle').textContent = '✏️ Editar Preço de Destaque';
    document.getElementById('precoDestaqueId').value = preco.id;
    document.getElementById('precoDestaqueTipo').value = preco.tipo;
    document.getElementById('precoDestaqueDias').value = preco.dias;
    document.getElementById('precoDestaquePreco').value = preco.preco;
    document.getElementById('precoDestaqueDesc').value = preco.descricao || '';
    document.getElementById('precoDestaqueAtivo').checked = preco.ativo;
    document.getElementById('modalPrecoDestaque').classList.add('show');
}

function fecharModal(id) {
    document.getElementById(id).classList.remove('show');
}

document.querySelectorAll('.modal').forEach(m => {
    m.addEventListener('click', e => { if (e.target === m) fecharModal(m.id); });
});

document.getElementById('precoBannerForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const id = document.getElementById('precoBannerId').value;
    const payload = {
        tipo_preco: 'banner',
        nome: document.getElementById('precoBannerPosicao').options[document.getElementById('precoBannerPosicao').selectedIndex]?.text || 'Banner',
        posicao_id: document.getElementById('precoBannerPosicao').value,
        dias: document.getElementById('precoBannerDias').value,
        preco: document.getElementById('precoBannerPreco').value
    };
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/preco${id ? '/' + id : ''}`, {
            method: id ? 'PUT' : 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (data.success) location.reload();
        else alert(data.error || 'Erro');
    } catch (e) { alert('Erro de conexão'); }
});

document.getElementById('precoDestaqueForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const id = document.getElementById('precoDestaqueId').value;
    const payload = {
        tipo_preco: 'destaque',
        nome: document.getElementById('precoDestaqueDesc').value || document.getElementById('precoDestaqueTipo').value,
        dias: document.getElementById('precoDestaqueDias').value,
        preco: document.getElementById('precoDestaquePreco').value
    };
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/preco${id ? '/' + id : ''}`, {
            method: id ? 'PUT' : 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (data.success) location.reload();
        else alert(data.error || 'Erro');
    } catch (e) { alert('Erro de conexão'); }
});

async function excluirPreco(tipo, id) {
    if (!confirm('Excluir este preço?')) return;
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/preco/${id}`, { 
            method: 'DELETE',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({tipo_preco: tipo})
        });
        const data = await res.json();
        if (data.success) location.reload();
        else alert(data.error || 'Erro');
    } catch (e) { alert('Erro de conexão'); }
}
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
