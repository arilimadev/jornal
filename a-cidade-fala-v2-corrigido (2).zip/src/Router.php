<?php
/**
 * A Cidade Fala v2.0 - Router Principal
 * Usa apenas API REST do Supabase
 */

namespace ACidadeFala;

use ACidadeFala\Config\Config;
use ACidadeFala\Config\Database;

class Router
{
    private $db;
    private $uri;
    private $method;
    private $segments;
    
    public function __construct()
    {
        $this->db = Database::getInstance();
        $this->method = $_SERVER['REQUEST_METHOD'];
        
        $this->uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $subdir = Config::SUBDIR;
        if ($subdir && strpos($this->uri, $subdir) === 0) {
            $this->uri = substr($this->uri, strlen($subdir));
        }
        $this->uri = '/' . trim($this->uri, '/');
        $this->segments = array_values(array_filter(explode('/', $this->uri)));
    }
    
    public function handle()
    {
        if (str_starts_with($this->uri, '/api/')) return $this->handleApi();
        if (str_starts_with($this->uri, '/admin')) return $this->handleAdmin();
        if (str_starts_with($this->uri, '/autor')) return $this->handleAuthor();
        return $this->handlePublic();
    }
    
    private function handlePublic()
    {
        if ($this->uri === '/' || $this->uri === '') return $this->renderHome();
        
        if ($this->uri === '/login') return $this->renderLogin();
        if ($this->uri === '/registro') return $this->renderRegister();
        if ($this->uri === '/logout') return $this->logout();
        
        if ($this->uri === '/noticias') return $this->renderListByType('noticia', 'Notícias');
        if ($this->uri === '/opinioes') return $this->renderListByType('opiniao', 'Opiniões');
        if ($this->uri === '/denuncias') return $this->renderListByType('denuncia', 'Denúncias');
        
        if ($this->uri === '/sobre') return $this->renderAbout();
        if ($this->uri === '/contato') return $this->renderContact();
        if ($this->uri === '/termos') return $this->renderTerms();
        if ($this->uri === '/privacidade') return $this->renderPrivacy();
        if ($this->uri === '/anunciar') return $this->renderAnunciar();
        if ($this->uri === '/planos') return $this->renderAnunciar();
        if ($this->uri === '/anunciante') return $this->redirectToAnunciante();
        
        if ($this->uri === '/selecionar-cidade') return $this->renderSelectCity();
        if ($this->uri === '/definir-cidade') return $this->setCity();
        if ($this->uri === '/busca') return $this->renderSearch();
        
        if (preg_match('#^/banner/click/(\d+)$#', $this->uri, $m)) return $this->handleBannerClick($m[1]);
        if (preg_match('#^/categoria/([a-z0-9\-]+)$#', $this->uri, $m)) return $this->renderCategoria($m[1]);
        if (preg_match('#^/perfil/(\d+)$#', $this->uri, $m)) return $this->renderAutorPublico($m[1]);
        if (preg_match('#^/post/([a-z0-9\-]+)$#', $this->uri, $m)) return $this->renderPostBySlug($m[1]);
        
        $segments = $this->segments;
        
        if (count($segments) === 1 && strlen($segments[0]) === 2 && ctype_alpha($segments[0])) {
            return $this->renderEstado(strtoupper($segments[0]));
        }
        
        if (count($segments) === 2 && strlen($segments[0]) === 2 && ctype_alpha($segments[0])) {
            return $this->renderCidade(strtoupper($segments[0]), $segments[1]);
        }
        
        if (count($segments) === 3 && strlen($segments[0]) === 2 && ctype_alpha($segments[0])) {
            return $this->renderPost(strtoupper($segments[0]), $segments[1], $segments[2]);
        }
        
        return $this->error404();
    }
    
    private function handleAdmin()
    {
        if (!$this->isAdmin()) {
            return $this->redirect(url('login?redirect=' . urlencode($_SERVER['REQUEST_URI'])));
        }
        
        $path = substr($this->uri, 6);
        $path = '/' . trim($path, '/');
        
        switch ($path) {
            case '/': case '': return $this->renderAdminDashboard();
            case '/moderacao': return $this->renderAdminModeracao();
            case '/posts': return $this->renderAdminPosts();
            case '/categorias': return $this->renderAdminCategorias();
            case '/usuarios': return $this->renderAdminUsuarios();
            case '/autores': return $this->renderAdminUsuariosPorTipo('autor', 'Autores');
            case '/moderadores': return $this->renderAdminUsuariosPorTipo('moderador', 'Moderadores');
            case '/anunciantes': return $this->renderAdminUsuariosPorTipo('anunciante', 'Anunciantes');
            case '/cidades': return $this->renderAdminCidades();
            case '/estados': return $this->renderAdminEstados();
            case '/bairros': return $this->renderAdminBairros();
            case '/banners': return $this->renderAdminBanners();
            case '/destaques': return $this->renderAdminDestaques();
            case '/comentarios': return $this->renderAdminComentarios();
            case '/precos': return $this->renderAdminPrecos();
            case '/configuracoes': return $this->renderAdminConfiguracoes();
            case '/paginas': return $this->renderAdminPaginas();
            case '/relatorios': return $this->renderAdminRelatorios();
        }
        
        if (preg_match('#^/usuarios/(\d+|novo)$#', $path, $m)) {
            return $this->renderAdminUsuarioForm($m[1] === 'novo' ? null : $m[1]);
        }
        
        return $this->error404();
    }
    
    private function handleAuthor()
    {
        if (!$this->isLoggedIn()) {
            return $this->redirect(url('login?redirect=' . urlencode($_SERVER['REQUEST_URI'])));
        }
        
        $path = substr($this->uri, 6);
        $path = '/' . trim($path, '/');
        
        switch ($path) {
            case '/': case '': return $this->renderAuthorDashboard();
            case '/publicar': return $this->renderAuthorPostCreate();
            case '/posts': return $this->renderAuthorPosts();
            case '/verificacao': return $this->renderAuthorVerificacao();
            case '/anunciar': return $this->renderAuthorAnunciar();
            case '/perfil': return $this->renderAuthorPerfil();
        }
        
        if (preg_match('#^/editar/(\d+)$#', $path, $m)) {
            return $this->renderAuthorPostEdit($m[1]);
        }
        
        return $this->error404();
    }
    
    private function handleApi()
    {
        header('Content-Type: application/json');
        
        $path = substr($this->uri, 4);
        $path = '/' . trim($path, '/');
        
        try {
            if ($path === '/login' && $this->method === 'POST') return $this->apiLogin();
            if ($path === '/register' && $this->method === 'POST') return $this->apiRegister();
            
            if ($path === '/estados') return $this->apiGetEstados();
            if ($path === '/cidades') return $this->apiGetCidades();
            if ($path === '/bairros') return $this->apiGetBairros();
            if ($path === '/categorias') return $this->apiGetCategorias();
            
            if ($path === '/posts' && $this->method === 'POST') return $this->apiCreatePost();
            if ($path === '/comentario' && $this->method === 'POST') return $this->apiCreateComentario();
            if ($path === '/denuncia' && $this->method === 'POST') return $this->apiCreateDenuncia();
            if ($path === '/newsletter' && $this->method === 'POST') return $this->apiNewsletter();
            if ($path === '/contato' && $this->method === 'POST') return $this->apiContato();
            
            if ($path === '/autor/verificacao' && $this->method === 'POST') return $this->apiAutorVerificacao();
            if ($path === '/autor/perfil' && $this->method === 'POST') return $this->apiAutorPerfil();
            if ($path === '/autor/banner' && $this->method === 'POST') return $this->apiAutorSolicitarBanner();
            
            // Rotas de autor para posts
            if (preg_match('#^/autor/post/(\d+)$#', $path, $m) && $this->method === 'DELETE') {
                return $this->apiAutorDeletePost($m[1]);
            }
            if (preg_match('#^/autor/post/(\d+)/destaque$#', $path, $m) && $this->method === 'POST') {
                return $this->apiAutorToggleDestaque($m[1]);
            }
            
            if (str_starts_with($path, '/admin/')) {
                if (!$this->isAdmin()) return $this->json(['success' => false, 'error' => 'Não autorizado'], 403);
                return $this->handleAdminApi($path);
            }
            
            return $this->json(['success' => false, 'error' => 'Rota não encontrada'], 404);
        } catch (\Exception $e) {
            return $this->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }
    
    private function handleAdminApi($path)
    {
        if (preg_match('#^/admin/post/(\d+)/aprovar$#', $path, $m)) return $this->apiAdminAprovarPost($m[1]);
        if (preg_match('#^/admin/post/(\d+)/rejeitar$#', $path, $m)) return $this->apiAdminRejeitarPost($m[1]);
        if (preg_match('#^/admin/post/(\d+)$#', $path, $m) && $this->method === 'GET') return $this->apiAdminGetPost($m[1]);
        
        if (preg_match('#^/admin/comentario/(\d+)/aprovar$#', $path, $m)) return $this->apiAdminAprovarComentario($m[1]);
        if (preg_match('#^/admin/comentario/(\d+)$#', $path, $m) && $this->method === 'DELETE') return $this->apiAdminDeleteComentario($m[1]);
        
        if ($path === '/admin/usuario' && $this->method === 'POST') return $this->apiAdminCreateUsuario();
        if (preg_match('#^/admin/usuario/(\d+)$#', $path, $m) && $this->method === 'PUT') return $this->apiAdminUpdateUsuario($m[1]);
        if (preg_match('#^/admin/usuario/(\d+)/(ativar|desativar)$#', $path, $m)) return $this->apiAdminToggleUsuario($m[1], $m[2] === 'ativar');
        
        if ($path === '/admin/estado' && $this->method === 'POST') return $this->apiAdminCreateEstado();
        if (preg_match('#^/admin/estado/(\d+)$#', $path, $m) && $this->method === 'PUT') return $this->apiAdminUpdateEstado($m[1]);
        if (preg_match('#^/admin/estado/(\d+)/(ativar|desativar)$#', $path, $m)) return $this->apiAdminToggleEstado($m[1], $m[2] === 'ativar');
        
        if ($path === '/admin/cidade' && $this->method === 'POST') return $this->apiAdminCreateCidade();
        if (preg_match('#^/admin/cidade/(\d+)$#', $path, $m) && $this->method === 'PUT') return $this->apiAdminUpdateCidade($m[1]);
        if (preg_match('#^/admin/cidade/(\d+)$#', $path, $m) && $this->method === 'GET') return $this->apiAdminGetCidade($m[1]);
        if (preg_match('#^/admin/cidade/(\d+)$#', $path, $m) && $this->method === 'DELETE') return $this->apiAdminDeleteCidade($m[1]);
        
        if ($path === '/admin/bairro' && $this->method === 'POST') return $this->apiAdminCreateBairro();
        if (preg_match('#^/admin/bairro/(\d+)$#', $path, $m) && $this->method === 'PUT') return $this->apiAdminUpdateBairro($m[1]);
        if (preg_match('#^/admin/bairro/(\d+)$#', $path, $m) && $this->method === 'DELETE') return $this->apiAdminDeleteBairro($m[1]);
        
        if ($path === '/admin/categoria' && $this->method === 'POST') return $this->apiAdminCreateCategoria();
        if (preg_match('#^/admin/categoria/(\d+)$#', $path, $m) && $this->method === 'PUT') return $this->apiAdminUpdateCategoria($m[1]);
        if (preg_match('#^/admin/categoria/(\d+)$#', $path, $m) && $this->method === 'DELETE') return $this->apiAdminDeleteCategoria($m[1]);
        
        if ($path === '/admin/preco' && $this->method === 'POST') return $this->apiAdminCreatePreco();
        if (preg_match('#^/admin/preco/(\d+)$#', $path, $m) && $this->method === 'PUT') return $this->apiAdminUpdatePreco($m[1]);
        if (preg_match('#^/admin/preco/(\d+)$#', $path, $m) && $this->method === 'DELETE') return $this->apiAdminDeletePreco($m[1]);
        
        if ($path === '/admin/pagina' && $this->method === 'POST') return $this->apiAdminSavePagina();
        if ($path === '/admin/configuracoes' && $this->method === 'POST') return $this->apiAdminSaveConfig();
        
        return $this->json(['success' => false, 'error' => 'Rota não encontrada'], 404);
    }
    
    // ==================== PUBLIC RENDERS ====================
    
    private function renderHome()
    {
        // Tenta usar a view, se não funcionar usa select normal
        $posts = $this->db->select('vw_posts_completos', ['status' => 'aprovado'], 20, 0, ['created_at' => 'DESC']);
        
        // Fallback se a view não existir
        if (empty($posts) || $this->db->getLastError()) {
            $posts = $this->db->select('posts', ['status' => 'aprovado'], 20, 0, ['created_at' => 'DESC']);
        }
        $posts = $posts ?: [];
        
        $categorias = $this->db->select('categorias', ['ativo' => true], null, 0, ['ordem' => 'ASC']);
        
        $destaques = $this->db->select('vw_posts_completos', ['status' => 'aprovado', 'destaque' => true], 5, 0, ['created_at' => 'DESC']);
        if (empty($destaques) || $this->db->getLastError()) {
            $destaques = $this->db->select('posts', ['status' => 'aprovado', 'destaque' => true], 5, 0, ['created_at' => 'DESC']);
        }
        $destaques = $destaques ?: [];
        
        return $this->view('public/home', ['posts' => $posts, 'categorias' => $categorias, 'destaques' => $destaques, 'featured' => !empty($destaques) ? $destaques : $posts]);
    }
    
    private function renderLogin()
    {
        if ($this->isLoggedIn()) return $this->redirect(url('autor'));
        return $this->view('public/login', []);
    }
    
    private function renderRegister()
    {
        if ($this->isLoggedIn()) return $this->redirect(url('autor'));
        $estados = $this->db->select('estados', ['ativo' => true], null, 0, ['nome' => 'ASC']);
        return $this->view('public/register', ['estados' => $estados]);
    }
    
    private function renderListByType($tipo, $titulo)
    {
        $page = max(1, intval($_GET['page'] ?? 1));
        $perPage = 12;
        $offset = ($page - 1) * $perPage;
        
        // Tenta usar a view, se não funcionar usa select normal
        $posts = $this->db->select('vw_posts_completos', ['status' => 'aprovado', 'tipo' => $tipo], $perPage, $offset, ['created_at' => 'DESC']);
        
        // Fallback se a view não existir
        if (empty($posts) && $this->db->getLastError()) {
            $posts = $this->db->select('posts', ['status' => 'aprovado', 'tipo' => $tipo], $perPage, $offset, ['created_at' => 'DESC']);
        }
        $posts = $posts ?: [];
        
        $total = $this->db->count('posts', ['status' => 'aprovado', 'tipo' => $tipo]);
        $categorias = $this->db->select('categorias', ['ativo' => true], null, 0, ['ordem' => 'ASC']);
        
        return $this->view('public/list', [
            'posts' => $posts, 
            'titulo' => $titulo, 
            'tipo' => $tipo, 
            'page' => $page, 
            'totalPages' => ceil($total / $perPage), 
            'total' => $total,
            'categorias' => $categorias
        ]);
    }
    
    private function renderAbout()
    {
        $pagina = $this->db->select('paginas', ['slug' => 'sobre'], 1);
        $pagina = $pagina[0] ?? ['titulo' => 'Sobre Nós', 'conteudo' => '<p>O <strong>A Cidade Fala</strong> é um portal de jornalismo colaborativo.</p>'];
        return $this->view('public/about', ['pagina' => $pagina]);
    }
    
    private function renderContact() { return $this->view('public/contact', []); }
    
    private function renderTerms()
    {
        $termo = $this->db->select('termos', ['tipo' => 'uso', 'ativo' => true], 1);
        $termo = $termo[0] ?? ['titulo' => 'Termos de Uso', 'conteudo' => '<p>Em construção.</p>'];
        return $this->view('public/terms', ['termo' => $termo]);
    }
    
    private function renderPrivacy()
    {
        $termo = $this->db->select('termos', ['tipo' => 'privacidade', 'ativo' => true], 1);
        $termo = $termo[0] ?? ['titulo' => 'Política de Privacidade', 'conteudo' => '<p>Em construção.</p>'];
        return $this->view('public/privacy', ['termo' => $termo]);
    }
    
    private function renderAnunciar()
    {
        $posicoes = $this->db->select('banner_posicoes', ['ativo' => true]);
        $bannerPrecos = $this->db->select('banner_precos', ['ativo' => true]);
        $destaquePrecos = $this->db->select('destaque_precos', ['ativo' => true]);
        return $this->view('public/anunciar', ['posicoes' => $posicoes, 'bannerPrecos' => $bannerPrecos, 'destaquePrecos' => $destaquePrecos]);
    }
    
    private function renderSelectCity()
    {
        $estados = $this->db->select('estados', ['ativo' => true], null, 0, ['nome' => 'ASC']);
        return $this->view('public/select-city', ['estados' => $estados]);
    }
    
    private function renderSearch()
    {
        $query = trim($_GET['q'] ?? '');
        $posts = [];
        if (strlen($query) >= 3) {
            $posts = $this->db->search('posts', 'titulo', $query, 50, ['created_at' => 'DESC']);
            $posts = array_filter($posts, fn($p) => ($p['status'] ?? '') === 'aprovado');
        }
        return $this->view('public/search', ['query' => $query, 'posts' => array_values($posts)]);
    }
    
    private function renderEstado($uf)
    {
        $estado = $this->db->select('estados', ['uf' => $uf, 'ativo' => true], 1);
        if (empty($estado)) return $this->error404();
        $estado = $estado[0];
        $cidades = $this->db->select('cidades', ['estado_id' => $estado['id'], 'ativo' => true], null, 0, ['nome' => 'ASC']);
        $posts = $this->db->select('posts', ['estado_id' => $estado['id'], 'status' => 'aprovado'], 20, 0, ['created_at' => 'DESC']);
        return $this->view('public/estado', ['estado' => $estado, 'cidades' => $cidades, 'posts' => $posts]);
    }
    
    private function renderCidade($uf, $cidadeSlug)
    {
        $estado = $this->db->select('estados', ['uf' => $uf], 1);
        if (empty($estado)) return $this->error404();
        $estado = $estado[0];
        $cidade = $this->db->select('cidades', ['slug' => $cidadeSlug, 'estado_id' => $estado['id'], 'ativo' => true], 1);
        if (empty($cidade)) return $this->error404();
        $cidade = $cidade[0];
        $where = ['cidade_id' => $cidade['id'], 'status' => 'aprovado'];
        $page = max(1, intval($_GET['page'] ?? 1));
        $perPage = 12;
        $offset = ($page - 1) * $perPage;
        $posts = $this->db->select('posts', $where, $perPage, $offset, ['destaque' => 'DESC', 'created_at' => 'DESC']);
        $total = $this->db->count('posts', $where);
        $categorias = $this->db->select('categorias', ['ativo' => true], null, 0, ['ordem' => 'ASC']);
        return $this->view('public/cidade', ['estado' => $estado, 'cidade' => $cidade, 'posts' => $posts, 'categorias' => $categorias, 'page' => $page, 'totalPages' => ceil($total / $perPage), 'maisLidas' => [], 'rankingAutores' => []]);
    }
    
    private function renderPost($uf, $cidadeSlug, $postSlug)
    {
        $estado = $this->db->select('estados', ['uf' => $uf], 1);
        if (empty($estado)) return $this->error404();
        $estado = $estado[0];
        
        $cidade = $this->db->select('cidades', ['slug' => $cidadeSlug, 'estado_id' => $estado['id']], 1);
        if (empty($cidade)) return $this->error404();
        $cidade = $cidade[0];
        
        $post = $this->db->select('posts', ['slug' => $postSlug, 'cidade_id' => $cidade['id']], 1);
        if (empty($post)) return $this->error404();
        $post = $post[0];
        
        if ($post['status'] !== 'aprovado') {
            if (!$this->isLoggedIn()) return $this->error404();
            if ($_SESSION['user_id'] != $post['usuario_id'] && ($_SESSION['user_tipo'] ?? '') !== 'admin') {
                return $this->error404();
            }
        }
        
        $this->db->update('posts', ['visualizacoes' => ($post['visualizacoes'] ?? 0) + 1], ['id' => $post['id']]);
        
        $autor = null;
        if (!empty($post['usuario_id'])) {
            $autor = $this->db->select('usuarios', ['id' => $post['usuario_id']], 1);
            $autor = $autor[0] ?? null;
        }
        
        $categoria = null;
        if (!empty($post['categoria_id'])) {
            $categoria = $this->db->select('categorias', ['id' => $post['categoria_id']], 1);
            $categoria = $categoria[0] ?? null;
        }
        
        $comentarios = $this->db->select('comentarios', ['post_id' => $post['id'], 'aprovado' => true], null, 0, ['created_at' => 'DESC']);
        $relacionados = $this->db->select('posts', ['cidade_id' => $cidade['id'], 'status' => 'aprovado'], 5, 0, ['created_at' => 'DESC']);
        $relacionados = array_filter($relacionados, fn($p) => $p['id'] != $post['id']);
        
        // Adiciona cidade_slug e estado_uf aos relacionados
        foreach ($relacionados as &$rel) {
            $rel['cidade_slug'] = $cidade['slug'];
            $rel['estado_uf'] = $estado['uf'];
        }
        
        return $this->view('public/post', [
            'post' => $post, 
            'autor' => $autor, 
            'categoria' => $categoria, 
            'estado' => $estado, 
            'cidade' => $cidade, 
            'comentarios' => $comentarios, 
            'relacionados' => array_values(array_slice($relacionados, 0, 4))
        ]);
    }
    
    private function renderPostBySlug($postSlug)
    {
        // Busca o post pelo slug - tenta usar a view
        $post = $this->db->select('vw_posts_completos', ['slug' => $postSlug, 'status' => 'aprovado'], 1);
        
        // Fallback se a view não existir
        if (empty($post) && $this->db->getLastError()) {
            $post = $this->db->select('posts', ['slug' => $postSlug, 'status' => 'aprovado'], 1);
        }
        
        if (empty($post)) return $this->error404();
        $post = $post[0];
        
        // Se tem cidade e estado, redireciona para URL canônica
        if (!empty($post['estado_uf']) && !empty($post['cidade_slug'])) {
            return $this->redirect(url($post['estado_uf'] . '/' . $post['cidade_slug'] . '/' . $post['slug']));
        }
        
        // Se não tem cidade, exibe o post mesmo assim
        $this->db->update('posts', ['visualizacoes' => ($post['visualizacoes'] ?? 0) + 1], ['id' => $post['id']]);
        
        $autor = null;
        if (!empty($post['usuario_id'])) {
            $autor = $this->db->select('usuarios', ['id' => $post['usuario_id']], 1);
            $autor = $autor[0] ?? null;
        }
        
        $categoria = null;
        if (!empty($post['categoria_id'])) {
            $categoria = $this->db->select('categorias', ['id' => $post['categoria_id']], 1);
            $categoria = $categoria[0] ?? null;
        }
        
        $comentarios = $this->db->select('comentarios', ['post_id' => $post['id'], 'aprovado' => true], null, 0, ['created_at' => 'DESC']);
        $relacionados = [];
        
        return $this->view('public/post', [
            'post' => $post, 
            'autor' => $autor, 
            'categoria' => $categoria, 
            'estado' => null, 
            'cidade' => null, 
            'comentarios' => $comentarios, 
            'relacionados' => $relacionados
        ]);
    }
    
    private function renderCategoria($slug)
    {
        $categoria = $this->db->select('categorias', ['slug' => $slug, 'ativo' => true], 1);
        if (empty($categoria)) return $this->error404();
        $categoria = $categoria[0];
        $page = max(1, intval($_GET['page'] ?? 1));
        $perPage = 12;
        $offset = ($page - 1) * $perPage;
        
        // Tenta usar a view, se não funcionar usa select normal
        $posts = $this->db->select('vw_posts_completos', ['categoria_id' => $categoria['id'], 'status' => 'aprovado'], $perPage, $offset, ['created_at' => 'DESC']);
        
        // Fallback se a view não existir
        if (empty($posts) && $this->db->getLastError()) {
            $posts = $this->db->select('posts', ['categoria_id' => $categoria['id'], 'status' => 'aprovado'], $perPage, $offset, ['created_at' => 'DESC']);
        }
        $posts = $posts ?: [];
        
        $total = $this->db->count('posts', ['categoria_id' => $categoria['id'], 'status' => 'aprovado']);
        return $this->view('public/categoria', ['categoria' => $categoria, 'posts' => $posts, 'page' => $page, 'totalPages' => ceil($total / $perPage)]);
    }
    
    private function renderAutorPublico($id)
    {
        $autor = $this->db->select('usuarios', ['id' => $id, 'ativo' => true], 1);
        if (empty($autor)) return $this->error404();
        $autor = $autor[0];
        
        // Tenta usar a view, se não funcionar usa select normal
        $posts = $this->db->select('vw_posts_completos', ['usuario_id' => $id, 'status' => 'aprovado'], 20, 0, ['created_at' => 'DESC']);
        
        // Fallback se a view não existir
        if (empty($posts) && $this->db->getLastError()) {
            $posts = $this->db->select('posts', ['usuario_id' => $id, 'status' => 'aprovado'], 20, 0, ['created_at' => 'DESC']);
        }
        $posts = $posts ?: [];
        
        return $this->view('public/autor', ['autor' => $autor, 'posts' => $posts]);
    }
    
    // ==================== ADMIN RENDERS ====================
    
    private function renderAdminDashboard()
    {
        $pendingCount = $this->db->count('posts', ['status' => 'pendente']);
        $stats = [
            'posts_total' => $this->db->count('posts', ['status' => 'aprovado']),
            'posts_pendentes' => $pendingCount,
            'usuarios_total' => $this->db->count('usuarios', ['ativo' => true]),
            'comentarios_pendentes' => $this->db->count('comentarios', ['aprovado' => false])
        ];
        
        $pendingPosts = $this->db->select('posts', ['status' => 'pendente'], 10, 0, ['created_at' => 'DESC']);
        
        foreach ($pendingPosts as &$p) {
            if (!empty($p['usuario_id'])) {
                $autor = $this->db->select('usuarios', ['id' => $p['usuario_id']], 1);
                $p['autor_nome'] = $autor[0]['nome'] ?? 'Anônimo';
            } else {
                $p['autor_nome'] = 'Anônimo';
            }
        }
        
        $recentUsers = $this->db->select('usuarios', [], 5, 0, ['created_at' => 'DESC']);
        
        return $this->view('admin/dashboard', [
            'stats' => $stats, 
            'pendingPosts' => $pendingCount,
            'pendingPostsList' => $pendingPosts, 
            'recentUsers' => $recentUsers, 
            'pendingComments' => []
        ]);
    }
    
    private function renderAdminModeracao()
    {
        $status = $_GET['status'] ?? 'pendente';
        $where = $status !== 'todos' ? ['status' => $status] : [];
        $posts = $this->db->select('posts', $where, 50, 0, ['created_at' => 'DESC']);
        
        foreach ($posts as &$p) {
            if (!empty($p['usuario_id'])) {
                $autor = $this->db->select('usuarios', ['id' => $p['usuario_id']], 1);
                $p['autor_nome'] = $autor[0]['nome'] ?? 'Anônimo';
            } else {
                $p['autor_nome'] = 'Anônimo';
            }
            if (!empty($p['cidade_id'])) {
                $cidade = $this->db->select('cidades', ['id' => $p['cidade_id']], 1);
                $p['cidade_nome'] = $cidade[0]['nome'] ?? '';
            }
        }
        
        $cidades = $this->db->select('cidades', ['ativo' => true], null, 0, ['nome' => 'ASC']);
        $pendingCount = $this->db->count('posts', ['status' => 'pendente']);
        
        return $this->view('admin/moderacao', [
            'posts' => $posts, 
            'pendingPosts' => $pendingCount,
            'cidades' => $cidades, 
            'stats' => ['pendentes' => $pendingCount]
        ]);
    }
    
    private function renderAdminPosts()
    {
        $posts = $this->db->select('posts', [], 100, 0, ['created_at' => 'DESC']);
        foreach ($posts as &$p) {
            if (!empty($p['usuario_id'])) {
                $autor = $this->db->select('usuarios', ['id' => $p['usuario_id']], 1);
                $p['autor_nome'] = $autor[0]['nome'] ?? 'Anônimo';
            } else {
                $p['autor_nome'] = 'Anônimo';
            }
        }
        $pendingCount = $this->db->count('posts', ['status' => 'pendente']);
        return $this->view('admin/moderacao', ['posts' => $posts, 'pendingPosts' => $pendingCount, 'pageTitle' => 'Todos os Posts']);
    }
    
    private function renderAdminCategorias()
    {
        $categorias = $this->db->select('categorias', [], null, 0, ['ordem' => 'ASC']);
        $pendingCount = $this->db->count('posts', ['status' => 'pendente']);
        return $this->view('admin/categorias', ['categorias' => $categorias, 'pendingPosts' => $pendingCount]);
    }
    
    private function renderAdminUsuarios()
    {
        $tipo = $_GET['tipo'] ?? null;
        $where = $tipo ? ['tipo' => $tipo] : [];
        $usuarios = $this->db->select('usuarios', $where, 100, 0, ['created_at' => 'DESC']);
        $pendingCount = $this->db->count('posts', ['status' => 'pendente']);
        return $this->view('admin/usuarios', [
            'usuarios' => $usuarios, 
            'pendingPosts' => $pendingCount,
            'stats' => [
                'total' => count($usuarios), 
                'autores' => $this->db->count('usuarios', ['tipo' => 'autor']), 
                'moderadores' => $this->db->count('usuarios', ['tipo' => 'moderador']), 
                'anunciantes' => $this->db->count('usuarios', ['tipo' => 'anunciante'])
            ]
        ]);
    }
    
    private function renderAdminUsuariosPorTipo($tipo, $titulo)
    {
        $usuarios = $this->db->select('usuarios', ['tipo' => $tipo], null, 0, ['nome' => 'ASC']);
        $pendingCount = $this->db->count('posts', ['status' => 'pendente']);
        return $this->view('admin/usuarios', [
            'usuarios' => $usuarios, 
            'pendingPosts' => $pendingCount,
            'pageTitle' => $titulo, 
            'filtroTipo' => $tipo,
            'stats' => ['total' => count($usuarios)]
        ]);
    }
    
    private function renderAdminUsuarioForm($id)
    {
        $usuario = $id ? ($this->db->select('usuarios', ['id' => $id], 1)[0] ?? null) : null;
        $cidades = $this->db->select('cidades', ['ativo' => true], null, 0, ['nome' => 'ASC']);
        $pendingCount = $this->db->count('posts', ['status' => 'pendente']);
        return $this->view('admin/usuario-form', ['usuario' => $usuario, 'cidades' => $cidades, 'pendingPosts' => $pendingCount]);
    }
    
    private function renderAdminCidades()
    {
        $estados = $this->db->select('estados', [], null, 0, ['nome' => 'ASC']);
        $estadoId = $_GET['estado_id'] ?? null;
        $where = $estadoId ? ['estado_id' => $estadoId] : [];
        $cidades = $this->db->select('cidades', $where, null, 0, ['nome' => 'ASC']);
        $pendingCount = $this->db->count('posts', ['status' => 'pendente']);
        return $this->view('admin/cidades', ['estados' => $estados, 'cidades' => $cidades, 'pendingPosts' => $pendingCount]);
    }
    
    private function renderAdminEstados()
    {
        $estados = $this->db->select('estados', [], null, 0, ['nome' => 'ASC']);
        $pendingCount = $this->db->count('posts', ['status' => 'pendente']);
        return $this->view('admin/estados', ['estados' => $estados, 'pendingPosts' => $pendingCount]);
    }
    
    private function renderAdminBairros()
    {
        $estados = $this->db->select('estados', ['ativo' => true], null, 0, ['nome' => 'ASC']);
        $cidades = $this->db->select('cidades', ['ativo' => true], null, 0, ['nome' => 'ASC']);
        $cidadeId = $_GET['cidade_id'] ?? null;
        $where = $cidadeId ? ['cidade_id' => $cidadeId] : [];
        $bairros = $this->db->select('bairros', $where, null, 0, ['nome' => 'ASC']);
        $pendingCount = $this->db->count('posts', ['status' => 'pendente']);
        return $this->view('admin/bairros', ['estados' => $estados, 'cidades' => $cidades, 'bairros' => $bairros, 'pendingPosts' => $pendingCount]);
    }
    
    private function renderAdminBanners()
    {
        $status = $_GET['status'] ?? 'pendente';
        $where = $status !== 'todos' ? ['status' => $status] : [];
        $banners = $this->db->select('banners', $where, null, 0, ['created_at' => 'DESC']);
        $pendingCount = $this->db->count('posts', ['status' => 'pendente']);
        return $this->view('admin/banners', [
            'banners' => $banners, 
            'pendingPosts' => $pendingCount,
            'stats' => [
                'pendentes' => $this->db->count('banners', ['status' => 'pendente']), 
                'ativos' => $this->db->count('banners', ['status' => 'ativo'])
            ]
        ]);
    }
    
    private function renderAdminDestaques()
    {
        $destaques = $this->db->select('destaques', [], null, 0, ['created_at' => 'DESC']);
        $pendingCount = $this->db->count('posts', ['status' => 'pendente']);
        return $this->view('admin/destaques', ['destaques' => $destaques, 'pendingPosts' => $pendingCount]);
    }
    
    private function renderAdminComentarios()
    {
        $status = $_GET['status'] ?? 'pendente';
        $where = $status === 'pendente' ? ['aprovado' => false] : ($status === 'aprovado' ? ['aprovado' => true] : []);
        $comentarios = $this->db->select('comentarios', $where, 100, 0, ['created_at' => 'DESC']);
        $pendingCount = $this->db->count('posts', ['status' => 'pendente']);
        return $this->view('admin/comentarios', [
            'comentarios' => $comentarios, 
            'pendingPosts' => $pendingCount,
            'stats' => [
                'total' => $this->db->count('comentarios', []), 
                'pendentes' => $this->db->count('comentarios', ['aprovado' => false]), 
                'aprovados' => $this->db->count('comentarios', ['aprovado' => true])
            ]
        ]);
    }
    
    private function renderAdminPrecos()
    {
        $pendingCount = $this->db->count('posts', ['status' => 'pendente']);
        return $this->view('admin/precos', [
            'bannerPrecos' => $this->db->select('banner_precos', []), 
            'destaquePrecos' => $this->db->select('destaque_precos', []), 
            'posicoes' => $this->db->select('banner_posicoes', ['ativo' => true]),
            'pendingPosts' => $pendingCount
        ]);
    }
    
    private function renderAdminConfiguracoes()
    {
        $configList = $this->db->select('configuracoes', []);
        $configs = [];
        foreach ($configList as $c) {
            $configs[$c['chave']] = $c['valor'];
        }
        $pendingCount = $this->db->count('posts', ['status' => 'pendente']);
        return $this->view('admin/configuracoes', ['configuracoes' => $configs, 'pendingPosts' => $pendingCount]);
    }
    
    private function renderAdminPaginas()
    {
        $pendingCount = $this->db->count('posts', ['status' => 'pendente']);
        return $this->view('admin/paginas', [
            'paginas' => $this->db->select('paginas', []), 
            'termos' => $this->db->select('termos', ['ativo' => true]),
            'pendingPosts' => $pendingCount
        ]);
    }
    
    private function renderAdminRelatorios()
    {
        $cidades = $this->db->select('cidades', ['ativo' => true], null, 0, ['nome' => 'ASC']);
        $pendingCount = $this->db->count('posts', ['status' => 'pendente']);
        
        // Top Posts (mais visualizados) - usa view ou select simples
        $topPosts = $this->db->select('vw_posts_completos', ['status' => 'aprovado'], 10, 0, ['visualizacoes' => 'DESC']);
        if (empty($topPosts) && $this->db->getLastError()) {
            $topPosts = $this->db->select('posts', ['status' => 'aprovado'], 10, 0, ['visualizacoes' => 'DESC']);
        }
        $topPosts = $topPosts ?: [];
        
        // Top Autores - usa view ou cria lista simplificada
        $topAutores = $this->db->select('vw_ranking_autores', [], 10, 0, ['total_visualizacoes' => 'DESC']);
        if (empty($topAutores) && $this->db->getLastError()) {
            $topAutores = $this->db->select('usuarios', ['tipo' => 'autor', 'ativo' => true], 10);
        }
        $topAutores = $topAutores ?: [];
        
        // Top Cidades - usa view ou select simples
        $topCidades = $this->db->select('vw_cidades_stats', [], 10, 0, ['total_posts' => 'DESC']);
        if (empty($topCidades) && $this->db->getLastError()) {
            $topCidades = $this->db->select('cidades', ['ativo' => true], 10);
        }
        $topCidades = $topCidades ?: [];
        
        // Stats básicos
        $stats = [
            'posts_periodo' => $this->db->count('posts', ['status' => 'aprovado']),
            'visualizacoes_periodo' => 0,
            'usuarios_novos' => $this->db->count('usuarios', ['ativo' => true]),
            'receita_periodo' => 0,
            'posts_variacao' => 0,
            'views_variacao' => 0,
            'usuarios_variacao' => 0,
            'receita_variacao' => 0
        ];
        
        return $this->view('admin/relatorios', [
            'cidades' => $cidades,
            'pendingPosts' => $pendingCount,
            'stats' => $stats,
            'topPosts' => $topPosts,
            'topAutores' => $topAutores,
            'topCidades' => $topCidades,
            'dadosCategorias' => [],
            'dadosDias' => [],
            'dadosReceita' => []
        ]);
    }
    
    // ==================== AUTHOR RENDERS ====================
    
    private function renderAuthorDashboard()
    {
        $userId = $_SESSION['user_id'];
        $stats = [
            'total_posts' => $this->db->count('posts', ['usuario_id' => $userId]),
            'posts_aprovados' => $this->db->count('posts', ['usuario_id' => $userId, 'status' => 'aprovado']),
            'posts_pendentes' => $this->db->count('posts', ['usuario_id' => $userId, 'status' => 'pendente']),
            'total_views' => 0
        ];
        $posts = $this->db->select('posts', ['usuario_id' => $userId], 10, 0, ['created_at' => 'DESC']);
        $usuario = $this->db->select('usuarios', ['id' => $userId], 1)[0] ?? [];
        return $this->view('author/dashboard', ['stats' => $stats, 'posts' => $posts, 'usuario' => $usuario]);
    }
    
    private function renderAuthorPostCreate()
    {
        $estados = $this->db->select('estados', ['ativo' => true], null, 0, ['nome' => 'ASC']);
        $categorias = $this->db->select('categorias', ['ativo' => true], null, 0, ['ordem' => 'ASC']);
        $usuario = $this->db->select('usuarios', ['id' => $_SESSION['user_id']], 1)[0] ?? [];
        return $this->view('author/post-create', ['estados' => $estados, 'categorias' => $categorias, 'usuario' => $usuario]);
    }
    
    private function renderAuthorPostEdit($id)
    {
        $post = $this->db->select('posts', ['id' => $id, 'usuario_id' => $_SESSION['user_id']], 1);
        if (empty($post)) return $this->error404();
        $estados = $this->db->select('estados', ['ativo' => true], null, 0, ['nome' => 'ASC']);
        $categorias = $this->db->select('categorias', ['ativo' => true], null, 0, ['ordem' => 'ASC']);
        $usuario = $this->db->select('usuarios', ['id' => $_SESSION['user_id']], 1)[0] ?? [];
        return $this->view('author/post-create', ['post' => $post[0], 'estados' => $estados, 'categorias' => $categorias, 'usuario' => $usuario]);
    }
    
    private function renderAuthorPosts()
    {
        // Tenta usar a view, se não funcionar usa select normal
        $posts = $this->db->select('vw_posts_completos', ['usuario_id' => $_SESSION['user_id']], null, 0, ['created_at' => 'DESC']);
        
        // Fallback se a view não existir
        if (empty($posts) && $this->db->getLastError()) {
            $posts = $this->db->select('posts', ['usuario_id' => $_SESSION['user_id']], null, 0, ['created_at' => 'DESC']);
        }
        $posts = $posts ?: [];
        return $this->view('author/posts', ['posts' => $posts]);
    }
    
    private function renderAuthorVerificacao()
    {
        $usuario = $this->db->select('usuarios', ['id' => $_SESSION['user_id']], 1)[0] ?? [];
        return $this->view('author/verificacao', ['usuario' => $usuario]);
    }
    
    private function renderAuthorAnunciar()
    {
        $usuario = $this->db->select('usuarios', ['id' => $_SESSION['user_id']], 1)[0] ?? [];
        $posicoes = $this->db->select('banner_posicoes', ['ativo' => true]);
        $estados = $this->db->select('estados', ['ativo' => true], null, 0, ['nome' => 'ASC']);
        $bannerPrecos = $this->db->select('banner_precos', ['ativo' => true]);
        $destaquePrecos = $this->db->select('destaque_precos', ['ativo' => true]);
        $banners = $this->db->select('banners', ['anunciante_id' => $_SESSION['user_id']], null, 0, ['created_at' => 'DESC']);
        $destaques = $this->db->select('destaques', ['usuario_id' => $_SESSION['user_id']], null, 0, ['created_at' => 'DESC']);
        $meusPosts = $this->db->select('posts', ['usuario_id' => $_SESSION['user_id'], 'status' => 'aprovado'], null, 0, ['created_at' => 'DESC']);
        
        // Stats
        $stats = [
            'banners_ativos' => count(array_filter($banners, fn($b) => $b['status'] === 'ativo')),
            'impressoes_total' => array_sum(array_column($banners, 'impressoes')),
            'cliques_total' => array_sum(array_column($banners, 'cliques'))
        ];
        
        return $this->view('author/anunciar', [
            'usuario' => $usuario,
            'posicoes' => $posicoes, 
            'estados' => $estados, 
            'bannerPrecos' => $bannerPrecos, 
            'destaquePrecos' => $destaquePrecos,
            'banners' => $banners,
            'destaques' => $destaques,
            'meusPosts' => $meusPosts,
            'stats' => $stats
        ]);
    }
    
    private function renderAuthorPerfil()
    {
        $usuario = $this->db->select('usuarios', ['id' => $_SESSION['user_id']], 1)[0] ?? [];
        $estados = $this->db->select('estados', ['ativo' => true], null, 0, ['nome' => 'ASC']);
        return $this->view('author/perfil', ['usuario' => $usuario, 'estados' => $estados]);
    }
    
    // ==================== API HANDLERS ====================
    
    private function apiLogin()
    {
        $input = $this->getJsonInput();
        $email = trim($input['email'] ?? '');
        $password = $input['senha'] ?? '';
        
        if (!$email || !$password) {
            return $this->json(['success' => false, 'error' => 'Email e senha são obrigatórios']);
        }
        
        $auth = new \ACidadeFala\Config\SupabaseAuth();
        $result = $auth->signIn($email, $password);
        
        if (!$result['success']) {
            return $this->json(['success' => false, 'error' => $result['error'] ?? 'Credenciais inválidas']);
        }
        
        $usuario = $this->db->select('usuarios', ['email' => $email], 1);
        if (empty($usuario)) {
            return $this->json(['success' => false, 'error' => 'Usuário não encontrado']);
        }
        
        $usuario = $usuario[0];
        
        if (!$usuario['ativo']) {
            return $this->json(['success' => false, 'error' => 'Conta desativada']);
        }
        
        $_SESSION['user_id'] = $usuario['id'];
        $_SESSION['user_email'] = $usuario['email'];
        $_SESSION['user_nome'] = $usuario['nome'];
        $_SESSION['user_tipo'] = $usuario['tipo'];
        $_SESSION['user_avatar'] = $usuario['avatar'] ?? null;
        
        $redirect = $_POST['redirect'] ?? '';
        if ($usuario['tipo'] === 'admin') {
            $redirect = $redirect ?: url('admin');
        } else {
            $redirect = $redirect ?: url('autor');
        }
        
        return $this->json(['success' => true, 'redirect' => $redirect]);
    }
    
    private function apiRegister()
    {
        $input = $this->getJsonInput();
        $email = trim($input['email'] ?? '');
        $password = $input['senha'] ?? '';
        $nome = trim($input['nome'] ?? '');
        
        if (!$email || !$password || !$nome) {
            return $this->json(['success' => false, 'error' => 'Preencha todos os campos']);
        }
        
        if (strlen($password) < 6) {
            return $this->json(['success' => false, 'error' => 'Senha deve ter pelo menos 6 caracteres']);
        }
        
        $existing = $this->db->select('usuarios', ['email' => $email], 1);
        if (!empty($existing)) {
            return $this->json(['success' => false, 'error' => 'Email já cadastrado']);
        }
        
        $auth = new \ACidadeFala\Config\SupabaseAuth();
        $result = $auth->signUp($email, $password, ['nome' => $nome]);
        
        if (!$result['success']) {
            return $this->json(['success' => false, 'error' => $result['error'] ?? 'Erro ao criar conta']);
        }
        
        $authId = $result['user']['id'] ?? null;
        
        $userData = [
            'auth_id' => $authId,
            'email' => $email,
            'nome' => $nome,
            'tipo' => 'autor',
            'ativo' => true
        ];
        
        $inserted = $this->db->insert('usuarios', $userData);
        
        if (!$inserted) {
            $lastError = $this->db->getLastError();
            return $this->json([
                'success' => false, 
                'error' => 'Erro ao salvar: ' . ($lastError ?: 'desconhecido')
            ]);
        }
        
        return $this->json(['success' => true, 'message' => 'Conta criada com sucesso!']);
    }
    
    private function apiGetEstados() { 
        return $this->json(['success' => true, 'estados' => $this->db->select('estados', ['ativo' => true], null, 0, ['nome' => 'ASC'])]); 
    }
    
    private function apiGetCidades() { 
        $estadoId = $_GET['estado_id'] ?? null; 
        $where = ['ativo' => true]; 
        if ($estadoId) $where['estado_id'] = $estadoId; 
        return $this->json(['success' => true, 'cidades' => $this->db->select('cidades', $where, null, 0, ['nome' => 'ASC'])]); 
    }
    
    private function apiGetBairros() { 
        $cidadeId = $_GET['cidade_id'] ?? null; 
        if (!$cidadeId) return $this->json(['success' => false, 'error' => 'Cidade não informada']); 
        return $this->json(['success' => true, 'bairros' => $this->db->select('bairros', ['cidade_id' => $cidadeId, 'ativo' => true], null, 0, ['nome' => 'ASC'])]); 
    }
    
    private function apiGetCategorias() { 
        return $this->json(['success' => true, 'categorias' => $this->db->select('categorias', ['ativo' => true], null, 0, ['ordem' => 'ASC'])]); 
    }
    
    private function apiCreatePost()
    {
        if (!$this->isLoggedIn()) return $this->json(['success' => false, 'error' => 'Não autorizado'], 403);
        
        $titulo = trim($_POST['titulo'] ?? '');
        $conteudo = $_POST['conteudo'] ?? '';
        $cidadeId = intval($_POST['cidade_id'] ?? 0);
        
        if (!$titulo || !$conteudo || !$cidadeId) {
            return $this->json(['success' => false, 'error' => 'Preencha os campos obrigatórios']);
        }
        
        $cidade = $this->db->select('cidades', ['id' => $cidadeId], 1);
        if (empty($cidade)) return $this->json(['success' => false, 'error' => 'Cidade inválida']);
        $cidade = $cidade[0];
        
        $slug = $this->slugify($titulo);
        $slugBase = $slug;
        $i = 1;
        while (!empty($this->db->select('posts', ['cidade_id' => $cidadeId, 'slug' => $slug], 1))) { 
            $slug = $slugBase . '-' . $i++; 
        }
        
        $imagemCapa = null;
        if (!empty($_FILES['imagem']['tmp_name'])) {
            $imagemCapa = $this->uploadImage($_FILES['imagem']);
        }
        
        $status = $_POST['status'] ?? 'pendente';
        if (!in_array($status, ['rascunho', 'pendente'])) $status = 'pendente';
        
        $this->db->insert('posts', [
            'usuario_id' => $_SESSION['user_id'], 
            'estado_id' => $cidade['estado_id'], 
            'cidade_id' => $cidadeId, 
            'bairro_id' => $_POST['bairro_id'] ?: null, 
            'categoria_id' => $_POST['categoria_id'] ?: null, 
            'tipo' => $_POST['tipo'] ?? 'noticia', 
            'titulo' => $titulo, 
            'subtitulo' => $_POST['subtitulo'] ?? null, 
            'slug' => $slug, 
            'conteudo' => $conteudo, 
            'imagem_capa' => $imagemCapa, 
            'anonimo' => isset($_POST['anonimo']), 
            'status' => $status, 
            'publicado_em' => $status === 'pendente' ? date('c') : null
        ]);
        
        return $this->json(['success' => true, 'message' => 'Post enviado para moderação!']);
    }
    
    private function apiCreateComentario()
    {
        $postId = intval($_POST['post_id'] ?? 0);
        $nome = trim($_POST['nome'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $conteudo = trim($_POST['conteudo'] ?? '');
        
        if (!$postId || !$nome || !$email || !$conteudo) {
            return $this->json(['success' => false, 'error' => 'Preencha todos os campos']);
        }
        
        $this->db->insert('comentarios', [
            'post_id' => $postId, 
            'usuario_id' => $_SESSION['user_id'] ?? null, 
            'nome' => $nome, 
            'email' => $email, 
            'conteudo' => $conteudo, 
            'ip' => $_SERVER['REMOTE_ADDR'] ?? null, 
            'aprovado' => false
        ]);
        
        return $this->json(['success' => true, 'message' => 'Comentário enviado!']);
    }
    
    private function apiCreateDenuncia() { 
        $data = $this->getJsonInput(); 
        $this->db->insert('denuncias', [
            'post_id' => $data['post_id'] ?? null, 
            'comentario_id' => $data['comentario_id'] ?? null, 
            'motivo' => $data['motivo'] ?? '', 
            'ip' => $_SERVER['REMOTE_ADDR'] ?? null
        ]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiNewsletter() { 
        $email = trim($_POST['email'] ?? ''); 
        if (!$email) return $this->json(['success' => false, 'error' => 'Email inválido']); 
        $this->db->insert('newsletter', ['email' => $email]); 
        return $this->json(['success' => true, 'message' => 'Cadastrado!']); 
    }
    
    private function apiContato() { 
        $this->db->insert('contatos', [
            'nome' => $_POST['nome'] ?? '', 
            'email' => $_POST['email'] ?? '', 
            'assunto' => $_POST['assunto'] ?? '', 
            'mensagem' => $_POST['mensagem'] ?? ''
        ]); 
        return $this->json(['success' => true, 'message' => 'Enviado!']); 
    }
    
    private function apiAutorVerificacao()
    {
        if (!$this->isLoggedIn()) return $this->json(['success' => false, 'error' => 'Não autorizado'], 403);
        
        $documentoUrl = null;
        $selfieUrl = null;
        
        if (!empty($_FILES['documento']['tmp_name'])) {
            $documentoUrl = $this->uploadImage($_FILES['documento']);
        }
        if (!empty($_FILES['selfie']['tmp_name'])) {
            $selfieUrl = $this->uploadImage($_FILES['selfie']);
        }
        
        if (!$documentoUrl && !$selfieUrl) {
            return $this->json(['success' => false, 'error' => 'Envie pelo menos um documento']);
        }
        
        $updateData = [];
        if ($documentoUrl) $updateData['documento_url'] = $documentoUrl;
        if ($selfieUrl) $updateData['selfie_url'] = $selfieUrl;
        
        $this->db->update('usuarios', $updateData, ['id' => $_SESSION['user_id']]);
        
        return $this->json(['success' => true, 'message' => 'Documentos enviados para análise!']);
    }
    
    private function apiAutorPerfil()
    {
        if (!$this->isLoggedIn()) return $this->json(['success' => false, 'error' => 'Não autorizado'], 403);
        
        $updateData = [
            'nome' => trim($_POST['nome'] ?? ''),
            'telefone' => trim($_POST['telefone'] ?? ''),
            'bio' => trim($_POST['bio'] ?? '')
        ];
        
        if (!empty($_FILES['avatar']['tmp_name'])) {
            $avatarUrl = $this->uploadImage($_FILES['avatar']);
            if ($avatarUrl) {
                $updateData['avatar'] = $avatarUrl;
            }
        }
        
        $this->db->update('usuarios', $updateData, ['id' => $_SESSION['user_id']]);
        $_SESSION['user_nome'] = $updateData['nome'];
        
        return $this->json(['success' => true, 'message' => 'Perfil atualizado!']);
    }
    
    private function apiAutorSolicitarBanner()
    {
        if (!$this->isLoggedIn()) return $this->json(['success' => false, 'error' => 'Não autorizado'], 403);
        
        $imagemUrl = null;
        if (!empty($_FILES['imagem']['tmp_name'])) {
            $imagemUrl = $this->uploadImage($_FILES['imagem']);
        }
        
        $this->db->insert('banners', [
            'anunciante_id' => $_SESSION['user_id'],
            'posicao_id' => $_POST['posicao_id'] ?? null,
            'estado_id' => $_POST['estado_id'] ?? null,
            'cidade_id' => $_POST['cidade_id'] ?? null,
            'titulo' => $_POST['titulo'] ?? '',
            'imagem_url' => $imagemUrl,
            'link_url' => $_POST['link_url'] ?? '',
            'status' => 'pendente'
        ]);
        
        return $this->json(['success' => true, 'message' => 'Banner solicitado!']);
    }
    
    private function apiAutorDeletePost($id)
    {
        if (!$this->isLoggedIn()) return $this->json(['success' => false, 'error' => 'Não autorizado'], 403);
        
        // Verificar se o post pertence ao usuário
        $post = $this->db->select('posts', ['id' => $id, 'usuario_id' => $_SESSION['user_id']], 1);
        if (empty($post)) {
            return $this->json(['success' => false, 'error' => 'Post não encontrado'], 404);
        }
        
        $this->db->delete('posts', ['id' => $id]);
        return $this->json(['success' => true, 'message' => 'Post excluído!']);
    }
    
    private function apiAutorToggleDestaque($id)
    {
        if (!$this->isLoggedIn()) return $this->json(['success' => false, 'error' => 'Não autorizado'], 403);
        
        // Verificar se o post pertence ao usuário e está aprovado
        $post = $this->db->select('posts', ['id' => $id, 'usuario_id' => $_SESSION['user_id'], 'status' => 'aprovado'], 1);
        if (empty($post)) {
            return $this->json(['success' => false, 'error' => 'Post não encontrado ou não aprovado'], 404);
        }
        
        $novoDestaque = !($post[0]['destaque'] ?? false);
        $this->db->update('posts', ['destaque' => $novoDestaque], ['id' => $id]);
        
        return $this->json(['success' => true, 'destaque' => $novoDestaque, 'message' => $novoDestaque ? 'Post destacado!' : 'Destaque removido!']);
    }
    
    private function apiAdminAprovarPost($id) { 
        $this->db->update('posts', ['status' => 'aprovado', 'moderado_por' => $_SESSION['user_id'], 'moderado_em' => date('c'), 'publicado_em' => date('c')], ['id' => $id]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminRejeitarPost($id) { 
        $data = $this->getJsonInput(); 
        $this->db->update('posts', ['status' => 'rejeitado', 'moderado_por' => $_SESSION['user_id'], 'motivo_rejeicao' => $data['motivo'] ?? ''], ['id' => $id]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminGetPost($id) { 
        $post = $this->db->select('posts', ['id' => $id], 1); 
        return $this->json(['success' => true, 'post' => $post[0] ?? null]); 
    }
    
    private function apiAdminAprovarComentario($id) { 
        $this->db->update('comentarios', ['aprovado' => true], ['id' => $id]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminDeleteComentario($id) { 
        $this->db->delete('comentarios', ['id' => $id]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminCreateUsuario() { 
        $data = $this->getJsonInput(); 
        $auth = new \ACidadeFala\Config\SupabaseAuth(); 
        $result = $auth->signUp($data['email'], $data['senha']); 
        if (!$result['success']) return $this->json(['success' => false, 'error' => $result['error'] ?? 'Erro']); 
        $this->db->insert('usuarios', ['auth_id' => $result['user']['id'] ?? null, 'email' => $data['email'], 'nome' => $data['nome'], 'tipo' => $data['tipo'] ?? 'autor', 'ativo' => true]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminUpdateUsuario($id) { 
        $data = $this->getJsonInput(); 
        $this->db->update('usuarios', ['nome' => $data['nome'] ?? '', 'tipo' => $data['tipo'] ?? 'autor', 'ativo' => $data['ativo'] ?? true], ['id' => $id]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminToggleUsuario($id, $ativar) { 
        $this->db->update('usuarios', ['ativo' => $ativar], ['id' => $id]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminCreateEstado() { 
        $data = $this->getJsonInput(); 
        $this->db->insert('estados', ['nome' => $data['nome'], 'uf' => strtoupper($data['uf']), 'ativo' => true]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminUpdateEstado($id) { 
        $data = $this->getJsonInput(); 
        $this->db->update('estados', ['nome' => $data['nome'], 'uf' => strtoupper($data['uf'])], ['id' => $id]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminToggleEstado($id, $ativar) { 
        $this->db->update('estados', ['ativo' => $ativar], ['id' => $id]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminCreateCidade() { 
        $data = $this->getJsonInput(); 
        $this->db->insert('cidades', ['estado_id' => $data['estado_id'], 'nome' => $data['nome'], 'slug' => $this->slugify($data['nome']), 'ativo' => true]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminUpdateCidade($id) { 
        $data = $this->getJsonInput(); 
        $this->db->update('cidades', ['estado_id' => $data['estado_id'], 'nome' => $data['nome'], 'slug' => $data['slug'] ?: $this->slugify($data['nome']), 'ativo' => $data['ativo'] ?? true], ['id' => $id]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminGetCidade($id) { 
        $cidade = $this->db->select('cidades', ['id' => $id], 1); 
        return $this->json(['success' => true, 'cidade' => $cidade[0] ?? null]); 
    }
    
    private function apiAdminDeleteCidade($id) { 
        $this->db->delete('cidades', ['id' => $id]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminCreateBairro() { 
        $data = $this->getJsonInput(); 
        $this->db->insert('bairros', ['cidade_id' => $data['cidade_id'], 'nome' => $data['nome'], 'slug' => $this->slugify($data['nome']), 'ativo' => true]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminUpdateBairro($id) { 
        $data = $this->getJsonInput(); 
        $this->db->update('bairros', ['cidade_id' => $data['cidade_id'], 'nome' => $data['nome'], 'slug' => $data['slug'] ?: $this->slugify($data['nome']), 'ativo' => $data['ativo'] ?? true], ['id' => $id]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminDeleteBairro($id) { 
        $this->db->delete('bairros', ['id' => $id]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminCreateCategoria() { 
        $data = $this->getJsonInput(); 
        $this->db->insert('categorias', ['nome' => $data['nome'], 'slug' => $this->slugify($data['nome']), 'icone' => $data['icone'] ?? '📰', 'cor' => $data['cor'] ?? '#1a365d', 'ativo' => true]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminUpdateCategoria($id) { 
        $data = $this->getJsonInput(); 
        $this->db->update('categorias', ['nome' => $data['nome'], 'slug' => $this->slugify($data['nome']), 'icone' => $data['icone'], 'cor' => $data['cor'], 'ativo' => $data['ativo'] ?? true], ['id' => $id]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminDeleteCategoria($id) { 
        $this->db->delete('categorias', ['id' => $id]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminCreatePreco() { 
        $data = $this->getJsonInput(); 
        $table = ($data['tipo_preco'] ?? 'banner') === 'destaque' ? 'destaque_precos' : 'banner_precos'; 
        $insertData = ['nome' => $data['nome'], 'dias' => intval($data['dias']), 'preco' => floatval($data['preco']), 'ativo' => true];
        $this->db->insert($table, $insertData); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminUpdatePreco($id) { 
        $data = $this->getJsonInput(); 
        $table = ($data['tipo_preco'] ?? 'banner') === 'destaque' ? 'destaque_precos' : 'banner_precos'; 
        $this->db->update($table, ['nome' => $data['nome'], 'dias' => intval($data['dias']), 'preco' => floatval($data['preco']), 'ativo' => $data['ativo'] ?? true], ['id' => $id]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminDeletePreco($id) { 
        $data = $this->getJsonInput(); 
        $table = ($data['tipo_preco'] ?? 'banner') === 'destaque' ? 'destaque_precos' : 'banner_precos'; 
        $this->db->delete($table, ['id' => $id]); 
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminSavePagina() { 
        $data = $this->getJsonInput(); 
        $slug = $data['slug'] ?? $this->slugify($data['titulo']);
        $existing = $this->db->select('paginas', ['slug' => $slug], 1);
        if (!empty($existing)) {
            $this->db->update('paginas', ['titulo' => $data['titulo'], 'conteudo' => $data['conteudo']], ['slug' => $slug]);
        } else {
            $this->db->insert('paginas', ['titulo' => $data['titulo'], 'slug' => $slug, 'conteudo' => $data['conteudo'], 'ativo' => true]);
        }
        return $this->json(['success' => true]); 
    }
    
    private function apiAdminSaveConfig() { 
        $data = $this->getJsonInput();
        foreach ($data as $key => $value) { 
            if (is_string($value) && !empty($key)) {
                $existing = $this->db->select('configuracoes', ['chave' => $key], 1);
                if (!empty($existing)) {
                    $this->db->update('configuracoes', ['valor' => $value], ['chave' => $key]);
                } else {
                    $this->db->insert('configuracoes', ['chave' => $key, 'valor' => $value]);
                }
            }
        } 
        return $this->json(['success' => true, 'message' => 'Configurações salvas!']); 
    }
    
    // ==================== HELPERS ====================
    
    private function view($name, $data = []) { 
        extract($data); 
        $viewPath = __DIR__ . '/Views/' . $name . '.php'; 
        if (!file_exists($viewPath)) return $this->error404(); 
        require $viewPath; 
    }
    
    private function json($data, $statusCode = 200) { 
        http_response_code($statusCode); 
        echo json_encode($data); 
        exit; 
    }
    
    private function redirect($url) { 
        header('Location: ' . $url); 
        exit; 
    }
    
    private function error404() { 
        http_response_code(404); 
        $this->view('errors/404'); 
        exit; 
    }
    
    private function isLoggedIn() { 
        return isset($_SESSION['user_id']); 
    }
    
    private function isAdmin() { 
        return $this->isLoggedIn() && ($_SESSION['user_tipo'] ?? '') === 'admin'; 
    }
    
    private function logout() { 
        session_destroy(); 
        $this->redirect(url('/')); 
    }
    
    private function redirectToAnunciante() {
        if ($this->isLoggedIn()) {
            return $this->redirect(url('autor/anunciar'));
        }
        return $this->redirect(url('anunciar'));
    }
    
    private function setCity() { 
        $cidadeId = $_POST['cidade_id'] ?? $_GET['cidade_id'] ?? null; 
        if ($cidadeId) setcookie('cidade_id', $cidadeId, time() + 365 * 24 * 60 * 60, '/'); 
        $this->redirect(url($_POST['redirect'] ?? $_GET['redirect'] ?? '/')); 
    }
    
    private function handleBannerClick($id) { 
        $banner = $this->db->select('banners', ['id' => $id, 'status' => 'ativo'], 1); 
        if (!empty($banner) && !empty($banner[0]['link_url'])) { 
            $this->db->update('banners', ['cliques' => ($banner[0]['cliques'] ?? 0) + 1], ['id' => $id]); 
            $this->redirect($banner[0]['link_url']); 
        } 
        $this->redirect(url('/')); 
    }
    
    private function getJsonInput() { 
        $rawInput = file_get_contents('php://input');
        $input = json_decode($rawInput, true);
        
        // Se o JSON foi parseado com sucesso, retorna
        if ($input !== null && is_array($input)) {
            return $input;
        }
        
        // Se não, tenta $_POST
        if (!empty($_POST)) {
            return $_POST;
        }
        
        // Última tentativa - parse manual se for form data
        if ($rawInput && strpos($rawInput, '=') !== false) {
            parse_str($rawInput, $parsed);
            return $parsed;
        }
        
        return [];
    }
    
    private function slugify($text) { 
        $text = preg_replace('/[^\pL\d]+/u', '-', $text); 
        $text = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text); 
        $text = preg_replace('/[^-\w]+/', '', $text); 
        $text = trim($text, '-'); 
        $text = preg_replace('/-+/', '-', $text); 
        return strtolower($text) ?: 'n-a'; 
    }
    
    private function uploadImage($file) { 
        if (!isset($file['tmp_name']) || !$file['tmp_name']) return null;
        if (!in_array($file['type'], ['image/jpeg', 'image/png', 'image/webp', 'image/gif'])) return null; 
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION); 
        $filename = uniqid() . '_' . time() . '.' . $ext; 
        $uploadDir = __DIR__ . '/../uploads/images/'; 
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true); 
        if (move_uploaded_file($file['tmp_name'], $uploadDir . $filename)) return $filename; 
        return null; 
    }
}
