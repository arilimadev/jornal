-- =====================================================
-- A Cidade Fala v2.0 - CORREÇÃO DE VIEWS
-- Execute ANTES do schema.sql se já existirem views
-- =====================================================

-- Dropar todas as views existentes para recriar
DROP VIEW IF EXISTS vw_posts_completos CASCADE;
DROP VIEW IF EXISTS vw_ranking_autores CASCADE;
DROP VIEW IF EXISTS vw_cidades_stats CASCADE;
DROP VIEW IF EXISTS vw_estados_stats CASCADE;
DROP VIEW IF EXISTS vw_banners_completos CASCADE;
DROP VIEW IF EXISTS vw_comentarios CASCADE;
DROP VIEW IF EXISTS vw_usuarios_stats CASCADE;

-- Confirmar que foram removidas
SELECT 'Views removidas com sucesso!' as status;
