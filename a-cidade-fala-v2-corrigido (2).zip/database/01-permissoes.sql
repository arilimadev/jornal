-- =====================================================
-- A CIDADE FALA v2.0 - PERMISSÕES DO SUPABASE
-- =====================================================
-- EXECUTE ESTE SCRIPT APÓS CRIAR AS TABELAS
-- Isso garante que a API REST do Supabase funcione
-- =====================================================

-- =====================================================
-- 1. PERMISSÕES NO SCHEMA
-- =====================================================
-- O Supabase usa roles (anon, authenticated, service_role)
-- para controlar acesso via API REST.
-- Sem isso, a API retorna "permission denied for schema public"

GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;

-- =====================================================
-- 2. PERMISSÕES NAS TABELAS EXISTENTES
-- =====================================================
-- Permite SELECT, INSERT, UPDATE, DELETE em todas as tabelas

GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO anon;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO authenticated;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO service_role;

-- =====================================================
-- 3. PERMISSÕES NAS SEQUENCES (AUTO-INCREMENT)
-- =====================================================
-- Necessário para INSERT funcionar com campos SERIAL/auto-increment

GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO anon;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO service_role;

-- =====================================================
-- 4. PERMISSÕES NAS FUNÇÕES
-- =====================================================
-- Permite executar funções criadas no banco

GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public TO anon;
GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public TO authenticated;
GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public TO service_role;

-- =====================================================
-- 5. PERMISSÕES PADRÃO PARA OBJETOS FUTUROS
-- =====================================================
-- IMPORTANTE: Isso garante que novas tabelas criadas
-- automaticamente terão as permissões corretas

ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO service_role;

ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;

ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;

-- =====================================================
-- 6. DESABILITAR RLS (Row Level Security)
-- =====================================================
-- RLS adiciona uma camada extra de segurança por linha
-- Para simplificar, desabilitamos nas tabelas principais
-- Em produção, você pode habilitar e criar policies específicas

ALTER TABLE IF EXISTS usuarios DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS posts DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS comentarios DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS categorias DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS estados DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS cidades DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS bairros DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS banners DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS banner_posicoes DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS newsletter DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS contatos DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS denuncias DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS configuracoes DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS paginas DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS destaques DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS destaque_precos DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS moderadores_cidades DISABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS termos DISABLE ROW LEVEL SECURITY;

-- =====================================================
-- VERIFICAÇÃO
-- =====================================================
SELECT 'Permissões configuradas com sucesso!' as status;

-- Para verificar as permissões atuais, rode:
-- SELECT grantee, privilege_type, table_name 
-- FROM information_schema.table_privileges 
-- WHERE table_schema = 'public';
