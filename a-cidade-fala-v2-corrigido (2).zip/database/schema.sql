-- =====================================================
-- A CIDADE FALA v2.0 - SCHEMA COMPLETO
-- Portal de Jornalismo Colaborativo Local
-- =====================================================

-- Dropar views existentes para evitar conflitos
DROP VIEW IF EXISTS vw_posts_completos CASCADE;
DROP VIEW IF EXISTS vw_ranking_autores CASCADE;
DROP VIEW IF EXISTS vw_cidades_stats CASCADE;
DROP VIEW IF EXISTS vw_estados_stats CASCADE;
DROP VIEW IF EXISTS vw_banners_completos CASCADE;
DROP VIEW IF EXISTS vw_comentarios CASCADE;
DROP VIEW IF EXISTS vw_usuarios_stats CASCADE;

-- Habilitar extensões
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =====================================================
-- TABELAS DE LOCALIZAÇÃO
-- =====================================================

CREATE TABLE IF NOT EXISTS estados (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(50) NOT NULL,
    uf CHAR(2) NOT NULL UNIQUE,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS cidades (
    id SERIAL PRIMARY KEY,
    estado_id INTEGER REFERENCES estados(id) ON DELETE CASCADE,
    nome VARCHAR(100) NOT NULL,
    slug VARCHAR(120) NOT NULL,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(estado_id, slug)
);

CREATE TABLE IF NOT EXISTS bairros (
    id SERIAL PRIMARY KEY,
    cidade_id INTEGER REFERENCES cidades(id) ON DELETE CASCADE,
    nome VARCHAR(100) NOT NULL,
    slug VARCHAR(120) NOT NULL,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(cidade_id, slug)
);

-- =====================================================
-- TABELAS DE USUÁRIOS
-- =====================================================

CREATE TABLE IF NOT EXISTS usuarios (
    id SERIAL PRIMARY KEY,
    auth_id UUID UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    nome VARCHAR(100) NOT NULL,
    tipo VARCHAR(20) DEFAULT 'autor' CHECK (tipo IN ('admin', 'moderador', 'autor', 'anunciante')),
    avatar VARCHAR(255),
    bio TEXT,
    telefone VARCHAR(20),
    cidade_id INTEGER REFERENCES cidades(id),
    documento_url VARCHAR(255),
    selfie_url VARCHAR(255),
    identidade_verificada BOOLEAN DEFAULT false,
    identidade_verificada_em TIMESTAMP,
    termos_aceitos BOOLEAN DEFAULT false,
    termos_aceitos_em TIMESTAMP,
    termos_aceitos_ip VARCHAR(45),
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS moderadores_cidades (
    id SERIAL PRIMARY KEY,
    usuario_id INTEGER REFERENCES usuarios(id) ON DELETE CASCADE,
    cidade_id INTEGER REFERENCES cidades(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(usuario_id, cidade_id)
);

-- =====================================================
-- TABELAS DE CONTEÚDO
-- =====================================================

CREATE TABLE IF NOT EXISTS categorias (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(50) NOT NULL,
    slug VARCHAR(60) NOT NULL UNIQUE,
    descricao TEXT,
    icone VARCHAR(10),
    cor VARCHAR(7) DEFAULT '#1e40af',
    ordem INTEGER DEFAULT 0,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS posts (
    id SERIAL PRIMARY KEY,
    usuario_id INTEGER REFERENCES usuarios(id),
    categoria_id INTEGER REFERENCES categorias(id),
    estado_id INTEGER REFERENCES estados(id) NOT NULL,
    cidade_id INTEGER REFERENCES cidades(id) NOT NULL,
    bairro_id INTEGER REFERENCES bairros(id),
    tipo VARCHAR(20) DEFAULT 'noticia' CHECK (tipo IN ('noticia', 'opiniao', 'denuncia')),
    titulo VARCHAR(200) NOT NULL,
    subtitulo VARCHAR(300),
    slug VARCHAR(220) NOT NULL,
    conteudo TEXT NOT NULL,
    imagem_capa VARCHAR(255),
    imagem_credito VARCHAR(100),
    anonimo BOOLEAN DEFAULT false,
    status VARCHAR(20) DEFAULT 'pendente' CHECK (status IN ('rascunho', 'pendente', 'aprovado', 'rejeitado')),
    moderado_por INTEGER REFERENCES usuarios(id),
    moderado_em TIMESTAMP,
    motivo_rejeicao TEXT,
    visualizacoes INTEGER DEFAULT 0,
    compartilhamentos INTEGER DEFAULT 0,
    destaque BOOLEAN DEFAULT false,
    destaque_ate TIMESTAMP,
    meta_description VARCHAR(160),
    meta_keywords VARCHAR(255),
    publicado_em TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(cidade_id, slug)
);

CREATE TABLE IF NOT EXISTS comentarios (
    id SERIAL PRIMARY KEY,
    post_id INTEGER REFERENCES posts(id) ON DELETE CASCADE,
    usuario_id INTEGER REFERENCES usuarios(id),
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    conteudo TEXT NOT NULL,
    aprovado BOOLEAN DEFAULT false,
    moderado_por INTEGER REFERENCES usuarios(id),
    moderado_em TIMESTAMP,
    ip VARCHAR(45),
    created_at TIMESTAMP DEFAULT NOW()
);

-- =====================================================
-- TABELAS DE MONETIZAÇÃO - BANNERS
-- =====================================================

CREATE TABLE IF NOT EXISTS banner_posicoes (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(50) NOT NULL,
    slug VARCHAR(60) NOT NULL UNIQUE,
    descricao TEXT,
    largura INTEGER,
    altura INTEGER,
    local VARCHAR(50),
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS banner_precos (
    id SERIAL PRIMARY KEY,
    posicao_id INTEGER REFERENCES banner_posicoes(id) ON DELETE CASCADE,
    tipo_regiao VARCHAR(20) NOT NULL CHECK (tipo_regiao IN ('estado', 'cidade', 'multiplas_cidades')),
    dias INTEGER NOT NULL,
    preco DECIMAL(10,2) NOT NULL,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(posicao_id, tipo_regiao, dias)
);

CREATE TABLE IF NOT EXISTS banners (
    id SERIAL PRIMARY KEY,
    anunciante_id INTEGER REFERENCES usuarios(id) ON DELETE CASCADE,
    posicao_id INTEGER REFERENCES banner_posicoes(id),
    tipo_regiao VARCHAR(20) NOT NULL CHECK (tipo_regiao IN ('estado', 'cidade', 'multiplas_cidades')),
    estado_id INTEGER REFERENCES estados(id),
    titulo VARCHAR(100),
    imagem_url VARCHAR(255) NOT NULL,
    link_url VARCHAR(500),
    data_inicio DATE NOT NULL,
    data_fim DATE NOT NULL,
    valor_pago DECIMAL(10,2),
    status VARCHAR(20) DEFAULT 'pendente' CHECK (status IN ('pendente', 'ativo', 'pausado', 'expirado', 'rejeitado')),
    impressoes INTEGER DEFAULT 0,
    cliques INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS banner_cidades (
    id SERIAL PRIMARY KEY,
    banner_id INTEGER REFERENCES banners(id) ON DELETE CASCADE,
    cidade_id INTEGER REFERENCES cidades(id) ON DELETE CASCADE,
    UNIQUE(banner_id, cidade_id)
);

CREATE TABLE IF NOT EXISTS banner_cliques (
    id SERIAL PRIMARY KEY,
    banner_id INTEGER REFERENCES banners(id) ON DELETE CASCADE,
    ip VARCHAR(45),
    user_agent TEXT,
    referer TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

-- =====================================================
-- TABELAS DE DESTAQUES
-- =====================================================

CREATE TABLE IF NOT EXISTS destaques (
    id SERIAL PRIMARY KEY,
    post_id INTEGER REFERENCES posts(id) ON DELETE CASCADE,
    usuario_id INTEGER REFERENCES usuarios(id),
    tipo VARCHAR(30) NOT NULL,
    cidade_id INTEGER REFERENCES cidades(id),
    data_inicio DATE NOT NULL,
    data_fim DATE NOT NULL,
    valor_pago DECIMAL(10,2),
    status VARCHAR(20) DEFAULT 'pendente' CHECK (status IN ('pendente', 'ativo', 'expirado')),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS destaque_precos (
    id SERIAL PRIMARY KEY,
    tipo VARCHAR(30) NOT NULL,
    dias INTEGER NOT NULL,
    preco DECIMAL(10,2) NOT NULL,
    descricao TEXT,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(tipo, dias)
);

-- =====================================================
-- TABELAS DE CONFIGURAÇÃO
-- =====================================================

CREATE TABLE IF NOT EXISTS configuracoes (
    id SERIAL PRIMARY KEY,
    chave VARCHAR(100) NOT NULL UNIQUE,
    valor TEXT,
    tipo VARCHAR(20) DEFAULT 'text',
    grupo VARCHAR(50) DEFAULT 'geral',
    descricao TEXT,
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS paginas (
    id SERIAL PRIMARY KEY,
    slug VARCHAR(100) NOT NULL UNIQUE,
    titulo VARCHAR(200) NOT NULL,
    conteudo TEXT,
    meta_description VARCHAR(160),
    ativo BOOLEAN DEFAULT true,
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS termos (
    id SERIAL PRIMARY KEY,
    tipo VARCHAR(30) NOT NULL,
    versao VARCHAR(20) NOT NULL,
    titulo VARCHAR(200) NOT NULL,
    conteudo TEXT NOT NULL,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(tipo, versao)
);

CREATE TABLE IF NOT EXISTS aceites_termos (
    id SERIAL PRIMARY KEY,
    usuario_id INTEGER REFERENCES usuarios(id) ON DELETE CASCADE,
    termo_id INTEGER REFERENCES termos(id),
    ip VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

-- =====================================================
-- OUTRAS TABELAS
-- =====================================================

CREATE TABLE IF NOT EXISTS newsletter (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    cidade_id INTEGER REFERENCES cidades(id),
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS contatos (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    telefone VARCHAR(20),
    assunto VARCHAR(200),
    mensagem TEXT NOT NULL,
    lido BOOLEAN DEFAULT false,
    respondido BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS denuncias (
    id SERIAL PRIMARY KEY,
    post_id INTEGER REFERENCES posts(id) ON DELETE CASCADE,
    comentario_id INTEGER REFERENCES comentarios(id) ON DELETE CASCADE,
    motivo VARCHAR(50) NOT NULL,
    descricao TEXT,
    email VARCHAR(255),
    resolvido BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_log (
    id SERIAL PRIMARY KEY,
    usuario_id INTEGER REFERENCES usuarios(id),
    acao VARCHAR(50) NOT NULL,
    tabela VARCHAR(50),
    registro_id INTEGER,
    dados_antigos JSONB,
    dados_novos JSONB,
    ip VARCHAR(45),
    created_at TIMESTAMP DEFAULT NOW()
);

-- =====================================================
-- ÍNDICES
-- =====================================================

CREATE INDEX IF NOT EXISTS idx_posts_cidade ON posts(cidade_id);
CREATE INDEX IF NOT EXISTS idx_posts_estado ON posts(estado_id);
CREATE INDEX IF NOT EXISTS idx_posts_bairro ON posts(bairro_id);
CREATE INDEX IF NOT EXISTS idx_posts_categoria ON posts(categoria_id);
CREATE INDEX IF NOT EXISTS idx_posts_usuario ON posts(usuario_id);
CREATE INDEX IF NOT EXISTS idx_posts_status ON posts(status);
CREATE INDEX IF NOT EXISTS idx_posts_tipo ON posts(tipo);
CREATE INDEX IF NOT EXISTS idx_posts_publicado ON posts(publicado_em DESC);
CREATE INDEX IF NOT EXISTS idx_posts_visualizacoes ON posts(visualizacoes DESC);
CREATE INDEX IF NOT EXISTS idx_comentarios_post ON comentarios(post_id);
CREATE INDEX IF NOT EXISTS idx_comentarios_aprovado ON comentarios(aprovado);
CREATE INDEX IF NOT EXISTS idx_banners_status ON banners(status);
CREATE INDEX IF NOT EXISTS idx_banners_datas ON banners(data_inicio, data_fim);
CREATE INDEX IF NOT EXISTS idx_banners_anunciante ON banners(anunciante_id);
CREATE INDEX IF NOT EXISTS idx_cidades_estado ON cidades(estado_id);
CREATE INDEX IF NOT EXISTS idx_bairros_cidade ON bairros(cidade_id);
CREATE INDEX IF NOT EXISTS idx_moderadores_cidades ON moderadores_cidades(usuario_id, cidade_id);

-- =====================================================
-- VIEWS
-- =====================================================

CREATE OR REPLACE VIEW vw_posts_completos AS
SELECT 
    p.*,
    u.nome as autor_nome,
    u.avatar as autor_avatar,
    c.nome as categoria_nome,
    c.slug as categoria_slug,
    c.icone as categoria_icone,
    c.cor as categoria_cor,
    e.nome as estado_nome,
    e.uf as estado_uf,
    ci.nome as cidade_nome,
    ci.slug as cidade_slug,
    b.nome as bairro_nome,
    b.slug as bairro_slug,
    (SELECT COUNT(*) FROM comentarios cm WHERE cm.post_id = p.id AND cm.aprovado = true) as total_comentarios
FROM posts p
LEFT JOIN usuarios u ON p.usuario_id = u.id
LEFT JOIN categorias c ON p.categoria_id = c.id
LEFT JOIN estados e ON p.estado_id = e.id
LEFT JOIN cidades ci ON p.cidade_id = ci.id
LEFT JOIN bairros b ON p.bairro_id = b.id;

CREATE OR REPLACE VIEW vw_ranking_autores AS
SELECT 
    u.id,
    u.nome,
    u.avatar,
    p.cidade_id,
    ci.nome as cidade_nome,
    COUNT(p.id) as total_posts,
    COALESCE(SUM(p.visualizacoes), 0) as total_visualizacoes
FROM usuarios u
INNER JOIN posts p ON p.usuario_id = u.id AND p.status = 'aprovado'
LEFT JOIN cidades ci ON p.cidade_id = ci.id
WHERE u.tipo = 'autor' AND u.ativo = true
GROUP BY u.id, u.nome, u.avatar, p.cidade_id, ci.nome
ORDER BY total_visualizacoes DESC, total_posts DESC;

CREATE OR REPLACE VIEW vw_estatisticas_cidade AS
SELECT 
    c.id as cidade_id,
    c.nome as cidade_nome,
    c.slug as cidade_slug,
    e.uf as estado_uf,
    COUNT(DISTINCT p.id) as total_posts,
    COUNT(DISTINCT p.usuario_id) as total_autores,
    COALESCE(SUM(p.visualizacoes), 0) as total_visualizacoes
FROM cidades c
LEFT JOIN estados e ON c.estado_id = e.id
LEFT JOIN posts p ON p.cidade_id = c.id AND p.status = 'aprovado'
WHERE c.ativo = true
GROUP BY c.id, c.nome, c.slug, e.uf;

-- =====================================================
-- TRIGGERS
-- =====================================================

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_usuarios_updated_at ON usuarios;
CREATE TRIGGER trigger_usuarios_updated_at
    BEFORE UPDATE ON usuarios
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS trigger_posts_updated_at ON posts;
CREATE TRIGGER trigger_posts_updated_at
    BEFORE UPDATE ON posts
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS trigger_banners_updated_at ON banners;
CREATE TRIGGER trigger_banners_updated_at
    BEFORE UPDATE ON banners
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE OR REPLACE FUNCTION incrementar_visualizacao(post_id_param INTEGER)
RETURNS VOID AS $$
BEGIN
    UPDATE posts SET visualizacoes = visualizacoes + 1 WHERE id = post_id_param;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION registrar_clique_banner(
    banner_id_param INTEGER,
    ip_param VARCHAR,
    user_agent_param TEXT,
    referer_param TEXT
)
RETURNS VOID AS $$
BEGIN
    INSERT INTO banner_cliques (banner_id, ip, user_agent, referer) 
    VALUES (banner_id_param, ip_param, user_agent_param, referer_param);
    UPDATE banners SET cliques = cliques + 1 WHERE id = banner_id_param;
END;
$$ LANGUAGE plpgsql;

-- =====================================================
-- DADOS INICIAIS
-- =====================================================

INSERT INTO estados (nome, uf) VALUES
('Acre', 'AC'), ('Alagoas', 'AL'), ('Amapá', 'AP'), ('Amazonas', 'AM'),
('Bahia', 'BA'), ('Ceará', 'CE'), ('Distrito Federal', 'DF'), ('Espírito Santo', 'ES'),
('Goiás', 'GO'), ('Maranhão', 'MA'), ('Mato Grosso', 'MT'), ('Mato Grosso do Sul', 'MS'),
('Minas Gerais', 'MG'), ('Pará', 'PA'), ('Paraíba', 'PB'), ('Paraná', 'PR'),
('Pernambuco', 'PE'), ('Piauí', 'PI'), ('Rio de Janeiro', 'RJ'), ('Rio Grande do Norte', 'RN'),
('Rio Grande do Sul', 'RS'), ('Rondônia', 'RO'), ('Roraima', 'RR'), ('Santa Catarina', 'SC'),
('São Paulo', 'SP'), ('Sergipe', 'SE'), ('Tocantins', 'TO')
ON CONFLICT (uf) DO NOTHING;

INSERT INTO cidades (estado_id, nome, slug) VALUES
((SELECT id FROM estados WHERE uf = 'SC'), 'Florianópolis', 'florianopolis'),
((SELECT id FROM estados WHERE uf = 'SC'), 'Joinville', 'joinville'),
((SELECT id FROM estados WHERE uf = 'SC'), 'Blumenau', 'blumenau'),
((SELECT id FROM estados WHERE uf = 'SC'), 'São José', 'sao-jose'),
((SELECT id FROM estados WHERE uf = 'SC'), 'Chapecó', 'chapeco'),
((SELECT id FROM estados WHERE uf = 'SP'), 'São Paulo', 'sao-paulo'),
((SELECT id FROM estados WHERE uf = 'SP'), 'Campinas', 'campinas'),
((SELECT id FROM estados WHERE uf = 'SP'), 'Santos', 'santos'),
((SELECT id FROM estados WHERE uf = 'RJ'), 'Rio de Janeiro', 'rio-de-janeiro'),
((SELECT id FROM estados WHERE uf = 'RJ'), 'Niterói', 'niteroi'),
((SELECT id FROM estados WHERE uf = 'MG'), 'Belo Horizonte', 'belo-horizonte'),
((SELECT id FROM estados WHERE uf = 'RS'), 'Porto Alegre', 'porto-alegre'),
((SELECT id FROM estados WHERE uf = 'PR'), 'Curitiba', 'curitiba'),
((SELECT id FROM estados WHERE uf = 'DF'), 'Brasília', 'brasilia'),
((SELECT id FROM estados WHERE uf = 'BA'), 'Salvador', 'salvador'),
((SELECT id FROM estados WHERE uf = 'CE'), 'Fortaleza', 'fortaleza'),
((SELECT id FROM estados WHERE uf = 'PE'), 'Recife', 'recife'),
((SELECT id FROM estados WHERE uf = 'AM'), 'Manaus', 'manaus'),
((SELECT id FROM estados WHERE uf = 'PA'), 'Belém', 'belem'),
((SELECT id FROM estados WHERE uf = 'GO'), 'Goiânia', 'goiania')
ON CONFLICT DO NOTHING;

INSERT INTO categorias (nome, slug, icone, cor, ordem) VALUES
('Política', 'politica', '🏛️', '#dc2626', 1),
('Economia', 'economia', '💰', '#16a34a', 2),
('Segurança', 'seguranca', '🚨', '#ea580c', 3),
('Saúde', 'saude', '🏥', '#0891b2', 4),
('Educação', 'educacao', '📚', '#7c3aed', 5),
('Cultura', 'cultura', '🎭', '#db2777', 6),
('Esportes', 'esportes', '⚽', '#65a30d', 7),
('Infraestrutura', 'infraestrutura', '🏗️', '#ca8a04', 8),
('Meio Ambiente', 'meio-ambiente', '🌳', '#059669', 9),
('Tecnologia', 'tecnologia', '💻', '#6366f1', 10),
('Comunidade', 'comunidade', '👥', '#8b5cf6', 11),
('Entretenimento', 'entretenimento', '🎬', '#f43f5e', 12)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO banner_posicoes (nome, slug, descricao, largura, altura, local) VALUES
('Banner Topo Home', 'topo-home', 'Banner principal no topo da página inicial', 1200, 200, 'home'),
('Banner Lateral Home', 'lateral-home', 'Banner na sidebar da home', 300, 250, 'home'),
('Banner Topo Cidade', 'topo-cidade', 'Banner no topo da página da cidade', 1200, 150, 'cidade'),
('Banner Lateral Cidade', 'lateral-cidade', 'Banner na sidebar da página da cidade', 300, 250, 'cidade'),
('Banner Dentro Notícia', 'dentro-noticia', 'Banner dentro do conteúdo da notícia', 728, 90, 'noticia'),
('Banner Rodapé', 'rodape', 'Banner no rodapé do site', 1200, 100, 'footer')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO banner_precos (posicao_id, tipo_regiao, dias, preco) VALUES
(1, 'estado', 10, 500.00), (1, 'estado', 30, 1200.00), (1, 'estado', 90, 3000.00),
(1, 'cidade', 10, 150.00), (1, 'cidade', 30, 400.00), (1, 'cidade', 90, 1000.00),
(2, 'cidade', 10, 80.00), (2, 'cidade', 30, 200.00), (2, 'cidade', 90, 500.00),
(3, 'cidade', 10, 100.00), (3, 'cidade', 30, 250.00), (3, 'cidade', 90, 600.00),
(5, 'cidade', 10, 60.00), (5, 'cidade', 30, 150.00), (5, 'cidade', 90, 350.00)
ON CONFLICT DO NOTHING;

INSERT INTO destaque_precos (tipo, dias, preco, descricao) VALUES
('home', 1, 25.00, 'Destaque na home por 1 dia'),
('home', 3, 60.00, 'Destaque na home por 3 dias'),
('home', 7, 120.00, 'Destaque na home por 7 dias'),
('cidade', 1, 15.00, 'Destaque na cidade por 1 dia'),
('cidade', 3, 35.00, 'Destaque na cidade por 3 dias'),
('cidade', 7, 70.00, 'Destaque na cidade por 7 dias'),
('categoria', 7, 50.00, 'Destaque na categoria por 7 dias')
ON CONFLICT DO NOTHING;

INSERT INTO configuracoes (chave, valor, tipo, grupo, descricao) VALUES
('site_nome', 'A Cidade Fala', 'text', 'geral', 'Nome do site'),
('site_descricao', 'O jornalismo independente da sua cidade', 'text', 'geral', 'Descrição do site'),
('site_keywords', 'notícias locais, jornalismo cidadão, denúncias, cidade', 'text', 'seo', 'Palavras-chave para SEO'),
('cor_primaria', '#1e40af', 'color', 'aparencia', 'Cor primária do site'),
('cor_secundaria', '#dc2626', 'color', 'aparencia', 'Cor secundária/destaque'),
('logo_url', '/assets/images/logo.svg', 'image', 'aparencia', 'URL do logo'),
('favicon_url', '/assets/images/favicon.svg', 'image', 'aparencia', 'URL do favicon'),
('email_contato', 'contato@acidadefala.com.br', 'text', 'contato', 'Email de contato'),
('telefone_contato', '', 'text', 'contato', 'Telefone de contato'),
('whatsapp', '', 'text', 'contato', 'WhatsApp'),
('facebook_url', '', 'text', 'redes', 'URL do Facebook'),
('instagram_url', '', 'text', 'redes', 'URL do Instagram'),
('twitter_url', '', 'text', 'redes', 'URL do Twitter'),
('moderacao_automatica', 'false', 'boolean', 'moderacao', 'Aprovar posts automaticamente'),
('comentarios_moderados', 'true', 'boolean', 'moderacao', 'Moderar comentários antes de publicar'),
('permitir_anonimo', 'true', 'boolean', 'posts', 'Permitir posts anônimos'),
('exigir_verificacao_anonimo', 'true', 'boolean', 'posts', 'Exigir verificação de identidade para posts anônimos')
ON CONFLICT (chave) DO NOTHING;

INSERT INTO paginas (slug, titulo, conteudo) VALUES
('sobre', 'Sobre Nós', '<h2>Quem Somos</h2><p>O A Cidade Fala é um portal de jornalismo colaborativo focado em notícias locais.</p>'),
('politica-editorial', 'Política Editorial', '<h2>Nossa Política Editorial</h2><p>Prezamos pela veracidade, imparcialidade e responsabilidade.</p>'),
('termos-autor', 'Termos do Autor', '<h2>Termos e Condições para Autores</h2><p>Ao publicar conteúdo em nosso portal você se compromete com a veracidade das informações.</p>'),
('anunciar', 'Anuncie Conosco', '<h2>Anuncie no A Cidade Fala</h2><p>Alcance o público da sua cidade com nossos planos de anúncio.</p>'),
('planos', 'Planos de Anúncio', '<h2>Nossos Planos</h2><p>Oferecemos diversas opções de anúncio para seu negócio.</p>')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO termos (tipo, versao, titulo, conteudo) VALUES
('uso', '1.0', 'Termos de Uso', '<h2>1. Aceitação dos Termos</h2><p>Ao acessar e usar o portal A Cidade Fala, você concorda com estes termos.</p>'),
('privacidade', '1.0', 'Política de Privacidade', '<h2>1. Coleta de Dados</h2><p>Coletamos informações necessárias para o funcionamento do portal.</p>'),
('autor', '1.0', 'Termos do Autor', '<h2>1. Responsabilidade pelo Conteúdo</h2><p>O autor é inteiramente responsável pelo conteúdo que publica.</p><h2>2. Publicação Anônima</h2><p>Ao optar por publicação anônima, você entende que sua identidade será protegida publicamente, mas seus dados serão armazenados de forma segura e poderão ser fornecidos mediante ordem judicial.</p>'),
('editorial', '1.0', 'Política Editorial', '<h2>1. Compromisso com a Verdade</h2><p>O A Cidade Fala se compromete com a veracidade das informações publicadas.</p>')
ON CONFLICT DO NOTHING;
