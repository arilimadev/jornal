-- =====================================================
-- A Cidade Fala v2.0 - SCRIPT COMPLETO
-- Rode este arquivo único no Supabase SQL Editor
-- =====================================================

-- PASSO 1: LIMPAR VIEWS E FUNÇÕES EXISTENTES
DROP VIEW IF EXISTS vw_posts_completos CASCADE;
DROP VIEW IF EXISTS vw_ranking_autores CASCADE;
DROP VIEW IF EXISTS vw_cidades_stats CASCADE;
DROP VIEW IF EXISTS vw_estados_stats CASCADE;
DROP VIEW IF EXISTS vw_banners_completos CASCADE;
DROP VIEW IF EXISTS vw_comentarios CASCADE;
DROP VIEW IF EXISTS vw_usuarios_stats CASCADE;
DROP FUNCTION IF EXISTS execute_sql(TEXT) CASCADE;

-- PASSO 2: CRIAR FUNÇÃO execute_sql
CREATE OR REPLACE FUNCTION execute_sql(query_text TEXT)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    result JSONB;
BEGIN
    EXECUTE 'SELECT COALESCE(jsonb_agg(row_to_json(t)), ''[]''::jsonb) FROM (' || query_text || ') t'
    INTO result;
    RETURN result;
EXCEPTION WHEN OTHERS THEN
    BEGIN
        EXECUTE query_text;
        RETURN '[]'::jsonb;
    EXCEPTION WHEN OTHERS THEN
        RAISE;
    END;
END;
$$;

-- Permissões da função
GRANT EXECUTE ON FUNCTION execute_sql(TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION execute_sql(TEXT) TO service_role;
GRANT EXECUTE ON FUNCTION execute_sql(TEXT) TO anon;

-- PASSO 3: CRIAR VIEWS

-- View posts completos
CREATE VIEW vw_posts_completos AS
SELECT 
    p.*,
    u.nome as autor_nome,
    u.avatar as autor_avatar,
    u.bio as autor_bio,
    c.nome as categoria_nome,
    c.icone as categoria_icone,
    c.cor as categoria_cor,
    c.slug as categoria_slug,
    ci.nome as cidade_nome,
    ci.slug as cidade_slug,
    e.nome as estado_nome,
    e.uf as estado_uf,
    b.nome as bairro_nome
FROM posts p
LEFT JOIN usuarios u ON p.usuario_id = u.id
LEFT JOIN categorias c ON p.categoria_id = c.id
LEFT JOIN cidades ci ON p.cidade_id = ci.id
LEFT JOIN estados e ON p.estado_id = e.id
LEFT JOIN bairros b ON p.bairro_id = b.id;

-- View ranking autores
CREATE VIEW vw_ranking_autores AS
SELECT 
    u.id,
    u.nome,
    u.avatar,
    p.cidade_id,
    COUNT(p.id) as total_posts,
    COALESCE(SUM(p.visualizacoes), 0) as total_visualizacoes
FROM usuarios u
INNER JOIN posts p ON p.usuario_id = u.id AND p.status = 'aprovado'
WHERE u.ativo = true
GROUP BY u.id, u.nome, u.avatar, p.cidade_id;

-- View cidades stats
CREATE VIEW vw_cidades_stats AS
SELECT 
    c.*,
    e.uf as estado_uf,
    e.nome as estado_nome,
    (SELECT COUNT(*) FROM posts WHERE cidade_id = c.id AND status = 'aprovado') as total_posts,
    (SELECT COUNT(*) FROM bairros WHERE cidade_id = c.id) as total_bairros,
    (SELECT COUNT(DISTINCT usuario_id) FROM posts WHERE cidade_id = c.id AND status = 'aprovado') as total_autores
FROM cidades c
JOIN estados e ON c.estado_id = e.id;

-- View estados stats
CREATE VIEW vw_estados_stats AS
SELECT 
    e.*,
    (SELECT COUNT(*) FROM cidades WHERE estado_id = e.id) as total_cidades,
    (SELECT COUNT(*) FROM posts WHERE estado_id = e.id AND status = 'aprovado') as total_posts
FROM estados e;

-- View banners completos
CREATE VIEW vw_banners_completos AS
SELECT 
    b.*,
    u.nome as anunciante_nome,
    u.email as anunciante_email,
    bp.nome as posicao_nome,
    bp.largura,
    bp.altura,
    e.nome as estado_nome,
    e.uf as estado_uf
FROM banners b
LEFT JOIN usuarios u ON b.anunciante_id = u.id
LEFT JOIN banner_posicoes bp ON b.posicao_id = bp.id
LEFT JOIN estados e ON b.estado_id = e.id;

-- View comentários
CREATE VIEW vw_comentarios AS
SELECT 
    c.*,
    p.titulo as post_titulo,
    p.slug as post_slug
FROM comentarios c
LEFT JOIN posts p ON c.post_id = p.id;

-- View usuários stats
CREATE VIEW vw_usuarios_stats AS
SELECT 
    u.*,
    ci.nome as cidade_nome,
    (SELECT COUNT(*) FROM posts WHERE usuario_id = u.id) as total_posts,
    (SELECT COALESCE(SUM(visualizacoes), 0) FROM posts WHERE usuario_id = u.id) as total_visualizacoes
FROM usuarios u
LEFT JOIN cidades ci ON u.cidade_id = ci.id;

-- PASSO 4: PERMISSÕES DAS VIEWS
GRANT SELECT ON vw_posts_completos TO authenticated, anon, service_role;
GRANT SELECT ON vw_ranking_autores TO authenticated, anon, service_role;
GRANT SELECT ON vw_cidades_stats TO authenticated, anon, service_role;
GRANT SELECT ON vw_estados_stats TO authenticated, anon, service_role;
GRANT SELECT ON vw_banners_completos TO authenticated, anon, service_role;
GRANT SELECT ON vw_comentarios TO authenticated, anon, service_role;
GRANT SELECT ON vw_usuarios_stats TO authenticated, anon, service_role;

-- CONFIRMAÇÃO
SELECT 'Script executado com sucesso!' as status;
