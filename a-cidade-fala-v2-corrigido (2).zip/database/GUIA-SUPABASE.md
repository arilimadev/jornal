# Guia de Configuração do Supabase - A Cidade Fala v2.0

## Por que acontece o erro "permission denied"?

O Supabase usa **3 roles** para controlar acesso via API REST:

| Role | Descrição | Quando é usada |
|------|-----------|----------------|
| `anon` | Usuário anônimo | Requisições sem autenticação |
| `authenticated` | Usuário logado | Requisições com token JWT |
| `service_role` | Acesso total | Requisições com service_key (backend) |

Quando você cria tabelas via SQL Editor, elas **não têm permissões** para essas roles por padrão. Por isso a API retorna "permission denied".

---

## Ordem correta de execução dos scripts

### 1️⃣ Primeiro: Criar as tabelas
```
database/schema.sql
```

### 2️⃣ Segundo: Configurar permissões
```
database/01-permissoes.sql
```

### 3️⃣ Terceiro: Criar funções e views
```
database/setup-completo.sql
```

---

## Checklist de configuração

- [ ] Criar projeto no Supabase
- [ ] Copiar credenciais (Project URL, anon key, service_role key)
- [ ] Atualizar `src/Config/Database.php` com as credenciais
- [ ] Atualizar `src/Config/SupabaseAuth.php` com as credenciais
- [ ] Executar `schema.sql` no SQL Editor
- [ ] Executar `01-permissoes.sql` no SQL Editor
- [ ] Executar `setup-completo.sql` no SQL Editor
- [ ] Testar criação de usuário

---

## Erros comuns e soluções

### Erro: "permission denied for schema public"
**Causa:** Roles não têm permissão no schema
**Solução:** Executar `01-permissoes.sql`

### Erro: "Invalid API key"
**Causa:** Chaves incorretas ou expiradas
**Solução:** Verificar Settings → API no Supabase e atualizar os arquivos PHP

### Erro: "relation does not exist"
**Causa:** Tabela não foi criada
**Solução:** Executar `schema.sql`

### Erro: "cannot drop columns from view"
**Causa:** Views antigas com estrutura diferente
**Solução:** Executar `setup-completo.sql` (ele dropa e recria as views)

### Erro no RLS: "new row violates row-level security"
**Causa:** RLS habilitado sem policies
**Solução:** Desabilitar RLS ou criar policies adequadas

---

## Estrutura de arquivos do banco

```
database/
├── schema.sql          # Criação das tabelas
├── 01-permissoes.sql   # Permissões para API REST
├── setup-completo.sql  # Views e funções
├── functions.sql       # Apenas funções (alternativa)
└── fix-views.sql       # Corrigir views existentes
```

---

## Dicas de segurança para produção

1. **Nunca exponha a service_role key** no frontend
2. Use **RLS com policies** para controle granular
3. Crie policies específicas por tabela:

```sql
-- Exemplo: Usuário só pode editar seus próprios posts
CREATE POLICY "Users can edit own posts" ON posts
FOR UPDATE USING (usuario_id = auth.uid());
```

4. **Valide dados no backend** antes de inserir
5. Use **prepared statements** (o Supabase já faz isso via API)

---

## Testando a conexão

Crie um arquivo `teste-supabase.php`:

```php
<?php
require_once 'src/Config/Database.php';

$db = ACidadeFala\Config\Database::getInstance();
$result = $db->select('usuarios', [], 1);

echo '<pre>';
print_r($result);
echo '</pre>';
```

Se retornar dados ou array vazio, a conexão está OK.
Se der erro, verifique as credenciais e permissões.

---

## Links úteis

- [Documentação Supabase](https://supabase.com/docs)
- [RLS no Supabase](https://supabase.com/docs/guides/auth/row-level-security)
- [API REST do PostgREST](https://postgrest.org/en/stable/)
