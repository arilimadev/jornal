<?php
/**
 * A Cidade Fala v2.0 - Funções Helper
 */

use ACidadeFala\Config\Config;

// Data por extenso em português
if (!function_exists('dataExtenso')) {
    function dataExtenso($timestamp = null) {
        $timestamp = $timestamp ?? time();
        
        $diasSemana = [
            'Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira',
            'Quinta-feira', 'Sexta-feira', 'Sábado'
        ];
        
        $meses = [
            1 => 'janeiro', 2 => 'fevereiro', 3 => 'março', 4 => 'abril',
            5 => 'maio', 6 => 'junho', 7 => 'julho', 8 => 'agosto',
            9 => 'setembro', 10 => 'outubro', 11 => 'novembro', 12 => 'dezembro'
        ];
        
        $diaSemana = $diasSemana[date('w', $timestamp)];
        $dia = date('d', $timestamp);
        $mes = $meses[(int)date('n', $timestamp)];
        $ano = date('Y', $timestamp);
        
        return "{$diaSemana}, {$dia} de {$mes} de {$ano}";
    }
}

// Escape HTML
if (!function_exists('e')) {
    function e($string) {
        return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
    }
}

// URL base
if (!function_exists('url')) {
    function url($path = '') {
        return Config::getBaseUrl() . '/' . ltrim($path, '/');
    }
}

// Assets URL
if (!function_exists('asset')) {
    function asset($path) {
        return Config::getBaseUrl() . '/assets/' . ltrim($path, '/');
    }
}

// Upload URL
if (!function_exists('upload')) {
    function upload($path) {
        return Config::getBaseUrl() . '/uploads/' . ltrim($path, '/');
    }
}

// Time ago
if (!function_exists('timeAgo')) {
    function timeAgo($datetime) {
        return Config::timeAgo($datetime);
    }
}

// Format date
if (!function_exists('formatDate')) {
    function formatDate($date, $format = 'd/m/Y') {
        return Config::formatDate($date, $format);
    }
}
