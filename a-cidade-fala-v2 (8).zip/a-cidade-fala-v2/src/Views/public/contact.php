<?php
use ACidadeFala\Config\Config;
$pageTitle = "Contato";
ob_start();
?>

<div class="container" style="padding:var(--space-12) 0;">
    <div style="max-width:800px;margin:0 auto;">
        <h1 style="font-size:var(--text-4xl);margin-bottom:var(--space-2);">Entre em Contato</h1>
        <p style="color:var(--color-gray-500);margin-bottom:var(--space-8);font-size:var(--text-lg);">
            Tem dúvidas, sugestões ou quer anunciar? Preencha o formulário abaixo.
        </p>
        
        <div style="display:grid;grid-template-columns:1fr;gap:var(--space-8);">
            
            <!-- Formulário -->
            <div style="background:var(--color-white);padding:var(--space-8);border-radius:var(--radius-xl);box-shadow:var(--shadow-sm);border:1px solid var(--color-border);">
                <form id="contactForm">
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:var(--space-4);">
                        <div class="form-group">
                            <label class="form-label required">Nome</label>
                            <input type="text" name="nome" class="form-input" required placeholder="Seu nome completo">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label required">Email</label>
                            <input type="email" name="email" class="form-input" required placeholder="seu@email.com">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Telefone</label>
                        <input type="tel" name="telefone" class="form-input" placeholder="(00) 00000-0000">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label required">Assunto</label>
                        <select name="assunto" class="form-select" required>
                            <option value="">Selecione o assunto...</option>
                            <option value="duvida">Dúvida</option>
                            <option value="sugestao">Sugestão</option>
                            <option value="reclamacao">Reclamação</option>
                            <option value="anunciar">Quero Anunciar</option>
                            <option value="parceria">Parceria</option>
                            <option value="outro">Outro</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label required">Mensagem</label>
                        <textarea name="mensagem" class="form-textarea" rows="6" required placeholder="Escreva sua mensagem..."></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-lg" id="btnSend">
                        <i class="lucide-send"></i> Enviar Mensagem
                    </button>
                </form>
            </div>
            
            <!-- Info de Contato -->
            <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(200px, 1fr));gap:var(--space-4);">
                <div style="background:var(--color-gray-50);padding:var(--space-6);border-radius:var(--radius-xl);text-align:center;">
                    <i class="lucide-mail" style="font-size:32px;color:var(--color-primary);margin-bottom:var(--space-3);display:block;"></i>
                    <h3 style="font-size:var(--text-lg);margin-bottom:var(--space-2);">Email</h3>
                    <p style="color:var(--color-gray-600);">contato@acidadefala.com.br</p>
                </div>
                
                <div style="background:var(--color-gray-50);padding:var(--space-6);border-radius:var(--radius-xl);text-align:center;">
                    <i class="lucide-clock" style="font-size:32px;color:var(--color-primary);margin-bottom:var(--space-3);display:block;"></i>
                    <h3 style="font-size:var(--text-lg);margin-bottom:var(--space-2);">Horário</h3>
                    <p style="color:var(--color-gray-600);">Seg-Sex: 8h às 18h</p>
                </div>
                
                <div style="background:var(--color-gray-50);padding:var(--space-6);border-radius:var(--radius-xl);text-align:center;">
                    <i class="lucide-message-circle" style="font-size:32px;color:var(--color-primary);margin-bottom:var(--space-3);display:block;"></i>
                    <h3 style="font-size:var(--text-lg);margin-bottom:var(--space-2);">WhatsApp</h3>
                    <p style="color:var(--color-gray-600);">(00) 00000-0000</p>
                </div>
            </div>
            
        </div>
    </div>
</div>

<script>
document.getElementById('contactForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const btn = document.getElementById('btnSend');
    btn.disabled = true;
    btn.innerHTML = '<i class="lucide-loader-2" style="animation:spin 1s linear infinite;"></i> Enviando...';
    
    const formData = new FormData(this);
    
    try {
        const response = await fetch(window.ACF.apiUrl + '/contact', {
            method: 'POST',
            body: new URLSearchParams(formData),
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        
        const result = await response.json();
        
        if (result.success) {
            showToast('Mensagem enviada com sucesso! Responderemos em breve.', 'success');
            this.reset();
        } else {
            showToast(result.error || 'Erro ao enviar mensagem', 'error');
        }
    } catch (error) {
        showToast('Erro de conexão', 'error');
    }
    
    btn.disabled = false;
    btn.innerHTML = '<i class="lucide-send"></i> Enviar Mensagem';
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/../partials/layout.php';
?>
