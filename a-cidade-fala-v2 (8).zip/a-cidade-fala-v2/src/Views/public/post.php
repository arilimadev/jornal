<?php
/**
 * A Cidade Fala v2.0 - Visualização de Post
 */

use ACidadeFala\Config\Config;

$pageTitle = $post['titulo'] ?? 'Post';
$pageDescription = mb_substr(strip_tags($post['conteudo'] ?? ''), 0, 160);

ob_start();
?>

<style>
.post-page {
    padding: var(--space-6) 0;
}

.post-header {
    margin-bottom: var(--space-6);
}

.post-breadcrumb {
    display: flex;
    align-items: center;
    gap: var(--space-2);
    font-size: var(--text-sm);
    color: var(--color-gray-500);
    margin-bottom: var(--space-4);
}

.post-breadcrumb a {
    color: var(--color-gray-500);
}

.post-breadcrumb a:hover {
    color: var(--color-primary);
}

.post-badges {
    display: flex;
    gap: var(--space-2);
    margin-bottom: var(--space-4);
}

.post-title {
    font-size: var(--text-3xl);
    font-weight: var(--font-extrabold);
    line-height: var(--leading-tight);
    margin-bottom: var(--space-4);
}

@media (min-width: 768px) {
    .post-title {
        font-size: var(--text-4xl);
    }
}

.post-subtitle {
    font-size: var(--text-xl);
    color: var(--color-gray-600);
    margin-bottom: var(--space-6);
}

.post-meta {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: var(--space-4);
    padding: var(--space-4);
    background: var(--color-gray-50);
    border-radius: var(--radius-lg);
}

.post-author {
    display: flex;
    align-items: center;
    gap: var(--space-3);
}

.post-author-avatar {
    width: 48px;
    height: 48px;
    border-radius: var(--radius-full);
    background: var(--color-primary-100);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: var(--font-bold);
    color: var(--color-primary);
}

.post-author-info {
    display: flex;
    flex-direction: column;
}

.post-author-name {
    font-weight: var(--font-semibold);
}

.post-author-role {
    font-size: var(--text-sm);
    color: var(--color-gray-500);
}

.post-meta-item {
    display: flex;
    align-items: center;
    gap: var(--space-2);
    font-size: var(--text-sm);
    color: var(--color-gray-600);
}

.post-featured-image {
    width: 100%;
    border-radius: var(--radius-xl);
    margin-bottom: var(--space-6);
    overflow: hidden;
}

.post-featured-image img {
    width: 100%;
    height: auto;
}

.post-content {
    font-size: var(--text-lg);
    line-height: var(--leading-relaxed);
    color: var(--color-gray-800);
}

.post-content p {
    margin-bottom: var(--space-4);
}

.post-content h2 {
    margin-top: var(--space-8);
    margin-bottom: var(--space-4);
}

.post-content img {
    max-width: 100%;
    border-radius: var(--radius-lg);
    margin: var(--space-6) 0;
}

.post-share {
    display: flex;
    align-items: center;
    gap: var(--space-4);
    padding: var(--space-6);
    background: var(--color-gray-50);
    border-radius: var(--radius-xl);
    margin: var(--space-8) 0;
}

.post-share-label {
    font-weight: var(--font-semibold);
}

.post-share-buttons {
    display: flex;
    gap: var(--space-2);
}

.share-btn {
    width: 40px;
    height: 40px;
    border-radius: var(--radius-full);
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--color-white);
    transition: transform var(--transition-fast);
}

.share-btn:hover {
    transform: scale(1.1);
}

.share-btn.facebook { background: #1877f2; }
.share-btn.twitter { background: #1da1f2; }
.share-btn.whatsapp { background: #25d366; }
.share-btn.telegram { background: #0088cc; }
.share-btn.linkedin { background: #0077b5; }

.comments-section {
    margin-top: var(--space-12);
}

.comments-title {
    font-size: var(--text-2xl);
    margin-bottom: var(--space-6);
    display: flex;
    align-items: center;
    gap: var(--space-2);
}

.comment-form {
    background: var(--color-gray-50);
    padding: var(--space-6);
    border-radius: var(--radius-xl);
    margin-bottom: var(--space-8);
}

.comments-list {
    display: flex;
    flex-direction: column;
    gap: var(--space-4);
}

.comment {
    background: var(--color-white);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-xl);
    padding: var(--space-5);
}

.comment-header {
    display: flex;
    align-items: center;
    gap: var(--space-3);
    margin-bottom: var(--space-3);
}

.comment-avatar {
    width: 40px;
    height: 40px;
    border-radius: var(--radius-full);
    background: var(--color-gray-200);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: var(--font-semibold);
    color: var(--color-gray-600);
}

.comment-author {
    font-weight: var(--font-semibold);
}

.comment-date {
    font-size: var(--text-sm);
    color: var(--color-gray-500);
}

.comment-content {
    color: var(--color-gray-700);
    line-height: var(--leading-relaxed);
}

.related-section {
    margin-top: var(--space-12);
    padding-top: var(--space-8);
    border-top: 1px solid var(--color-border);
}
</style>

<div class="post-page">
    <div class="container">
        <div class="content-layout">
            
            <!-- Conteúdo Principal -->
            <article class="content-main">
                
                <!-- Header do Post -->
                <header class="post-header">
                    <nav class="post-breadcrumb">
                        <a href="<?= url('/') ?>"><i class="lucide-home"></i></a>
                        <i class="lucide-chevron-right"></i>
                        <a href="<?= url($post['tipo'] . 's') ?>"><?= ucfirst($post['tipo']) ?>s</a>
                        <i class="lucide-chevron-right"></i>
                        <span><?= e(mb_substr($post['titulo'], 0, 50)) ?>...</span>
                    </nav>
                    
                    <div class="post-badges">
                        <span class="badge badge-<?= $post['tipo'] ?>"><?= ucfirst($post['tipo']) ?></span>
                        <?php if ($post['categoria_id']): ?>
                            <?php $cat = Config::getCategory($post['categoria_id']); ?>
                            <?php if ($cat): ?>
                            <span class="badge badge-categoria"><?= $cat['icon'] ?> <?= e($cat['nome']) ?></span>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    
                    <h1 class="post-title"><?= e($post['titulo']) ?></h1>
                    
                    <?php if (!empty($post['subtitulo'])): ?>
                    <p class="post-subtitle"><?= e($post['subtitulo']) ?></p>
                    <?php endif; ?>
                    
                    <div class="post-meta">
                        <?php if (!$post['anonimo'] && isset($post['autor'])): ?>
                        <div class="post-author">
                            <div class="post-author-avatar">
                                <?= strtoupper(substr($post['autor']['nome'] ?? 'A', 0, 1)) ?>
                            </div>
                            <div class="post-author-info">
                                <span class="post-author-name"><?= e($post['autor']['nome'] ?? 'Autor') ?></span>
                                <span class="post-author-role">Colaborador</span>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="post-author">
                            <div class="post-author-avatar">
                                <i class="lucide-user"></i>
                            </div>
                            <div class="post-author-info">
                                <span class="post-author-name">Cidadão Anônimo</span>
                                <span class="post-author-role">Colaborador</span>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <div class="post-meta-item">
                            <i class="lucide-calendar"></i>
                            <?= formatDate($post['publicado_em'] ?? $post['created_at'], 'd/m/Y H:i') ?>
                        </div>
                        
                        <div class="post-meta-item">
                            <i class="lucide-eye"></i>
                            <?= number_format($post['views'] ?? 0) ?> visualizações
                        </div>
                    </div>
                </header>
                
                <!-- Imagem Destaque -->
                <?php if (!empty($post['imagem_destaque'])): ?>
                <figure class="post-featured-image">
                    <img src="<?= upload($post['imagem_destaque']) ?>" alt="<?= e($post['titulo']) ?>">
                </figure>
                <?php endif; ?>
                
                <!-- Conteúdo -->
                <div class="post-content">
                    <?= nl2br(e($post['conteudo'])) ?>
                </div>
                
                <!-- Compartilhar -->
                <div class="post-share">
                    <span class="post-share-label">Compartilhar:</span>
                    <div class="post-share-buttons">
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?= urlencode(url(($post['tipo'] ?? 'noticia') . '/' . $post['slug'])) ?>" 
                           target="_blank" class="share-btn facebook" title="Facebook">
                            <i class="lucide-facebook"></i>
                        </a>
                        <a href="https://twitter.com/intent/tweet?text=<?= urlencode($post['titulo']) ?>&url=<?= urlencode(url(($post['tipo'] ?? 'noticia') . '/' . $post['slug'])) ?>" 
                           target="_blank" class="share-btn twitter" title="Twitter">
                            <i class="lucide-twitter"></i>
                        </a>
                        <a href="https://wa.me/?text=<?= urlencode($post['titulo'] . ' - ' . url(($post['tipo'] ?? 'noticia') . '/' . $post['slug'])) ?>" 
                           target="_blank" class="share-btn whatsapp" title="WhatsApp">
                            <i class="lucide-message-circle"></i>
                        </a>
                        <a href="https://t.me/share/url?url=<?= urlencode(url(($post['tipo'] ?? 'noticia') . '/' . $post['slug'])) ?>&text=<?= urlencode($post['titulo']) ?>" 
                           target="_blank" class="share-btn telegram" title="Telegram">
                            <i class="lucide-send"></i>
                        </a>
                    </div>
                </div>
                
                <!-- Comentários -->
                <section class="comments-section">
                    <h2 class="comments-title">
                        <i class="lucide-message-circle"></i>
                        Comentários (<?= count($comentarios ?? []) ?>)
                    </h2>
                    
                    <?php if (isset($currentUser)): ?>
                    <form class="comment-form" id="commentForm">
                        <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                        <div class="form-group" style="margin-bottom:var(--space-4);">
                            <textarea name="conteudo" class="form-textarea" placeholder="Escreva seu comentário..." rows="4" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="lucide-send"></i> Enviar Comentário
                        </button>
                    </form>
                    <?php else: ?>
                    <div class="comment-form" style="text-align:center;">
                        <p style="margin-bottom:var(--space-4);color:var(--color-gray-600);">
                            Faça login para comentar nesta notícia.
                        </p>
                        <a href="<?= url('login') ?>" class="btn btn-primary">
                            <i class="lucide-log-in"></i> Entrar para Comentar
                        </a>
                    </div>
                    <?php endif; ?>
                    
                    <div class="comments-list" id="commentsList">
                        <?php if (empty($comentarios)): ?>
                        <p style="text-align:center;color:var(--color-gray-500);padding:var(--space-8);">
                            Seja o primeiro a comentar!
                        </p>
                        <?php else: ?>
                            <?php foreach ($comentarios as $comentario): ?>
                            <div class="comment">
                                <div class="comment-header">
                                    <div class="comment-avatar">
                                        <?= strtoupper(substr($comentario['usuario_nome'] ?? 'U', 0, 1)) ?>
                                    </div>
                                    <div>
                                        <div class="comment-author"><?= e($comentario['usuario_nome'] ?? 'Usuário') ?></div>
                                        <div class="comment-date"><?= timeAgo($comentario['created_at']) ?></div>
                                    </div>
                                </div>
                                <div class="comment-content">
                                    <?= nl2br(e($comentario['conteudo'])) ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </section>
                
                <!-- Relacionados -->
                <?php if (!empty($relacionados)): ?>
                <section class="related-section">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="lucide-layers section-title-icon"></i>
                            Notícias Relacionadas
                        </h2>
                    </div>
                    
                    <div class="news-grid">
                        <?php foreach (array_slice($relacionados, 0, 3) as $rel): ?>
                            <?php if ($rel['id'] != $post['id']): ?>
                            <article class="news-card">
                                <div class="news-card-image-wrapper">
                                    <?php if (!empty($rel['imagem_destaque'])): ?>
                                    <img src="<?= upload($rel['imagem_destaque']) ?>" alt="<?= e($rel['titulo']) ?>" class="news-card-image">
                                    <?php else: ?>
                                    <div class="news-card-image" style="background:var(--color-gray-200);"></div>
                                    <?php endif; ?>
                                </div>
                                <div class="news-card-content">
                                    <h3 class="news-card-title">
                                        <a href="<?= url(($rel['tipo'] ?? 'noticia') . '/' . $rel['slug']) ?>">
                                            <?= e($rel['titulo']) ?>
                                        </a>
                                    </h3>
                                    <div class="news-card-footer">
                                        <span class="news-card-meta"><?= timeAgo($rel['publicado_em'] ?? $rel['created_at']) ?></span>
                                    </div>
                                </div>
                            </article>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </section>
                <?php endif; ?>
                
            </article>
            
            <!-- Sidebar -->
            <aside class="sidebar">
                <!-- Banner Sidebar -->
                <div class="ad-container">
                    <div class="ad-label">Publicidade</div>
                    <div class="ad-block ad-block-sidebar">
                        <span class="ad-placeholder">Anuncie aqui<br>300x250</span>
                    </div>
                </div>
                
                <!-- Mais Lidas -->
                <div class="sidebar-widget">
                    <h3 class="sidebar-widget-title">
                        <i class="lucide-trending-up"></i> Mais Lidas
                    </h3>
                    <?php if (!empty($relacionados)): ?>
                    <div class="news-list news-list-numbered">
                        <?php foreach (array_slice($relacionados, 0, 5) as $rel): ?>
                        <div class="news-list-item">
                            <div class="news-list-content">
                                <h4 class="news-list-title">
                                    <a href="<?= url(($rel['tipo'] ?? 'noticia') . '/' . $rel['slug']) ?>">
                                        <?= e($rel['titulo']) ?>
                                    </a>
                                </h4>
                                <span class="news-list-meta"><?= timeAgo($rel['publicado_em'] ?? $rel['created_at']) ?></span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Banner -->
                <div class="ad-container">
                    <div class="ad-label">Publicidade</div>
                    <div class="ad-block ad-block-sidebar">
                        <span class="ad-placeholder">Anuncie aqui<br>300x250</span>
                    </div>
                </div>
            </aside>
            
        </div>
    </div>
</div>

<script>
document.getElementById('commentForm')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const btn = this.querySelector('button[type="submit"]');
    
    btn.disabled = true;
    btn.innerHTML = '<i class="lucide-loader-2" style="animation:spin 1s linear infinite;"></i> Enviando...';
    
    try {
        const response = await fetch(window.ACF.apiUrl + '/comentarios', {
            method: 'POST',
            body: new URLSearchParams(formData),
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        
        const result = await response.json();
        
        if (result.success) {
            showToast('Comentário enviado! Aguardando aprovação.', 'success');
            this.reset();
        } else {
            showToast(result.error || 'Erro ao enviar comentário', 'error');
        }
    } catch (error) {
        showToast('Erro de conexão', 'error');
    }
    
    btn.disabled = false;
    btn.innerHTML = '<i class="lucide-send"></i> Enviar Comentário';
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/../partials/layout.php';
?>
