<?php
/**
 * A Cidade Fala v2.0 - Registro
 */

use ACidadeFala\Config\Config;

$pageTitle = "Criar Conta";

ob_start();
?>

<style>
.auth-container {
    min-height: calc(100vh - 200px);
    display: flex;
    align-items: center;
    justify-content: center;
    padding: var(--space-8) var(--space-4);
    background: linear-gradient(135deg, var(--color-primary-50) 0%, var(--color-gray-100) 100%);
}

.auth-card {
    background: var(--color-white);
    border-radius: var(--radius-2xl);
    box-shadow: var(--shadow-xl);
    max-width: 450px;
    width: 100%;
    overflow: hidden;
}

.auth-header {
    background: var(--color-primary);
    color: var(--color-white);
    padding: var(--space-8);
    text-align: center;
}

.auth-logo {
    font-family: var(--font-heading);
    font-size: var(--text-2xl);
    font-weight: var(--font-extrabold);
    margin-bottom: var(--space-2);
}

.auth-title {
    font-size: var(--text-lg);
    opacity: 0.9;
}

.auth-body {
    padding: var(--space-8);
}

.auth-footer {
    padding: var(--space-6);
    background: var(--color-gray-50);
    text-align: center;
    border-top: 1px solid var(--color-border);
}

.auth-benefits {
    background: var(--color-primary-50);
    border-radius: var(--radius-lg);
    padding: var(--space-4);
    margin-bottom: var(--space-6);
}

.auth-benefits-title {
    font-weight: var(--font-semibold);
    color: var(--color-primary);
    margin-bottom: var(--space-2);
    font-size: var(--text-sm);
}

.auth-benefits-list {
    font-size: var(--text-sm);
    color: var(--color-gray-600);
}

.auth-benefits-list li {
    margin-bottom: var(--space-1);
    display: flex;
    align-items: center;
    gap: var(--space-2);
}

.auth-benefits-list li::before {
    content: "✓";
    color: var(--color-success);
    font-weight: bold;
}
</style>

<div class="auth-container">
    <div class="auth-card">
        <div class="auth-header">
            <div class="auth-logo"><?= e(Config::SITE_NAME) ?></div>
            <div class="auth-title">Crie sua conta gratuita</div>
        </div>
        
        <div class="auth-body">
            <div class="auth-benefits">
                <div class="auth-benefits-title">Com sua conta você pode:</div>
                <ul class="auth-benefits-list">
                    <li>Publicar notícias, opiniões e denúncias</li>
                    <li>Comentar em publicações</li>
                    <li>Destacar seus posts</li>
                    <li>Criar anúncios para sua cidade</li>
                </ul>
            </div>
            
            <form id="registerForm">
                <input type="hidden" name="tipo" value="autor">
                
                <div class="form-group">
                    <label class="form-label required">Nome completo</label>
                    <input type="text" name="nome" class="form-input" placeholder="Seu nome" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label required">Email</label>
                    <input type="email" name="email" class="form-input" placeholder="seu@email.com" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label required">Senha</label>
                    <input type="password" name="senha" class="form-input" placeholder="Mínimo 6 caracteres" required minlength="6">
                </div>
                
                <div class="form-group">
                    <label class="form-check">
                        <input type="checkbox" name="termos" class="form-check-input" required>
                        <span class="form-check-label">
                            Li e aceito os <a href="<?= url('termos') ?>" target="_blank">Termos de Uso</a> e a 
                            <a href="<?= url('privacidade') ?>" target="_blank">Política de Privacidade</a>
                        </span>
                    </label>
                </div>
                
                <div id="registerError" class="alert alert-error" style="display:none;"></div>
                
                <button type="submit" class="btn btn-primary btn-lg btn-block" id="btnRegister">
                    <i class="lucide-user-plus"></i>
                    Criar Conta
                </button>
            </form>
        </div>
        
        <div class="auth-footer">
            <p>Já tem uma conta? <a href="<?= url('login') ?>"><strong>Faça login</strong></a></p>
        </div>
    </div>
</div>

<script>
document.getElementById('registerForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const btn = document.getElementById('btnRegister');
    const errorDiv = document.getElementById('registerError');
    
    btn.disabled = true;
    btn.innerHTML = '<i class="lucide-loader-2" style="animation:spin 1s linear infinite;"></i> Criando conta...';
    errorDiv.style.display = 'none';
    
    const formData = new FormData(this);
    
    try {
        const response = await fetch(window.ACF.apiUrl + '/register', {
            method: 'POST',
            body: new URLSearchParams(formData),
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert(result.message || 'Conta criada com sucesso!');
            window.location.href = window.ACF.baseUrl + '/login';
        } else {
            errorDiv.textContent = result.error || 'Erro ao criar conta';
            errorDiv.style.display = 'block';
            btn.disabled = false;
            btn.innerHTML = '<i class="lucide-user-plus"></i> Criar Conta';
        }
    } catch (error) {
        errorDiv.textContent = 'Erro de conexão. Tente novamente.';
        errorDiv.style.display = 'block';
        btn.disabled = false;
        btn.innerHTML = '<i class="lucide-user-plus"></i> Criar Conta';
    }
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/../partials/layout.php';
?>
