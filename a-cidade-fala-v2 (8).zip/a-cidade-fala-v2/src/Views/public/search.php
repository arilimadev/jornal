<?php
use ACidadeFala\Config\Config;
$query = $query ?? '';
$posts = $posts ?? [];
$pageTitle = "Busca" . ($query ? ": " . $query : "");
ob_start();
?>

<div class="container" style="padding:var(--space-8) 0;">
    
    <!-- Formulário de Busca -->
    <div style="max-width:600px;margin:0 auto var(--space-8);">
        <form action="<?= url('busca') ?>" method="GET">
            <div style="position:relative;">
                <input type="text" name="q" value="<?= e($query) ?>" 
                       class="form-input" 
                       placeholder="O que você está procurando?"
                       style="padding:var(--space-4) var(--space-6);padding-left:var(--space-12);font-size:var(--text-lg);border-radius:var(--radius-full);">
                <i class="lucide-search" style="position:absolute;left:var(--space-4);top:50%;transform:translateY(-50%);color:var(--color-gray-400);font-size:24px;"></i>
                <button type="submit" class="btn btn-primary" style="position:absolute;right:var(--space-2);top:50%;transform:translateY(-50%);border-radius:var(--radius-full);">
                    Buscar
                </button>
            </div>
        </form>
    </div>
    
    <?php if ($query): ?>
    
    <!-- Resultados -->
    <h1 style="font-size:var(--text-2xl);margin-bottom:var(--space-6);">
        Resultados para "<?= e($query) ?>"
        <span style="font-size:var(--text-base);font-weight:normal;color:var(--color-gray-500);">
            (<?= count($posts) ?> encontrados)
        </span>
    </h1>
    
    <?php if (empty($posts)): ?>
    <div style="text-align:center;padding:var(--space-12);background:var(--color-gray-50);border-radius:var(--radius-xl);">
        <i class="lucide-search-x" style="font-size:64px;color:var(--color-gray-400);margin-bottom:var(--space-4);display:block;"></i>
        <h3 style="margin-bottom:var(--space-2);">Nenhum resultado encontrado</h3>
        <p style="color:var(--color-gray-500);">Tente buscar com outras palavras-chave.</p>
    </div>
    <?php else: ?>
    
    <div class="news-grid">
        <?php foreach ($posts as $post): ?>
        <article class="news-card">
            <div class="news-card-image-wrapper">
                <?php if (!empty($post['imagem_destaque'])): ?>
                <img src="<?= upload($post['imagem_destaque']) ?>" alt="<?= e($post['titulo']) ?>" class="news-card-image" loading="lazy">
                <?php else: ?>
                <div class="news-card-image" style="background:var(--color-gray-200);"></div>
                <?php endif; ?>
            </div>
            <div class="news-card-content">
                <div style="margin-bottom:var(--space-2);">
                    <span class="badge badge-<?= $post['tipo'] ?? 'noticia' ?>"><?= ucfirst($post['tipo'] ?? 'Notícia') ?></span>
                </div>
                <h3 class="news-card-title">
                    <a href="<?= url(($post['tipo'] ?? 'noticia') . '/' . $post['slug']) ?>">
                        <?= e($post['titulo']) ?>
                    </a>
                </h3>
                <p class="news-card-excerpt">
                    <?= e(mb_substr(strip_tags($post['conteudo']), 0, 120)) ?>...
                </p>
                <div class="news-card-footer">
                    <span class="news-card-meta"><?= timeAgo($post['publicado_em'] ?? $post['created_at']) ?></span>
                </div>
            </div>
        </article>
        <?php endforeach; ?>
    </div>
    
    <?php endif; ?>
    
    <?php else: ?>
    
    <div style="text-align:center;padding:var(--space-12);">
        <i class="lucide-search" style="font-size:64px;color:var(--color-gray-300);margin-bottom:var(--space-4);display:block;"></i>
        <h2 style="margin-bottom:var(--space-2);">Buscar Notícias</h2>
        <p style="color:var(--color-gray-500);">Digite pelo menos 3 caracteres para buscar.</p>
    </div>
    
    <?php endif; ?>
    
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../partials/layout.php';
?>
