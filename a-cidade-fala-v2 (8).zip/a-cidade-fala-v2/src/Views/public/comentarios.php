<?php
/**
 * A Cidade Fala v2.0 - Componente de Comentários
 * Incluir em post.php: <?php include __DIR__ . '/comentarios.php'; ?>
 */

$postId = $post['id'] ?? 0;
$comentarios = $comentarios ?? [];
$totalComentarios = count($comentarios);
?>

<style>
.comments-section {
    margin-top: var(--space-10);
    padding-top: var(--space-8);
    border-top: 2px solid var(--color-gray-200);
}

.comments-title {
    font-size: var(--text-2xl);
    font-weight: var(--font-bold);
    margin-bottom: var(--space-6);
    display: flex;
    align-items: center;
    gap: var(--space-3);
}

.comments-count {
    background: var(--color-primary);
    color: white;
    padding: var(--space-1) var(--space-3);
    border-radius: var(--radius-full);
    font-size: var(--text-sm);
}

/* Form */
.comment-form {
    background: var(--color-gray-50);
    border-radius: var(--radius-xl);
    padding: var(--space-6);
    margin-bottom: var(--space-8);
}

.comment-form-title {
    font-size: var(--text-lg);
    font-weight: var(--font-semibold);
    margin-bottom: var(--space-4);
}

.comment-form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: var(--space-4);
    margin-bottom: var(--space-4);
}

@media (max-width: 640px) {
    .comment-form-grid { grid-template-columns: 1fr; }
}

.comment-form .form-input,
.comment-form .form-textarea {
    width: 100%;
    padding: var(--space-3) var(--space-4);
    border: 1px solid var(--color-gray-300);
    border-radius: var(--radius-lg);
    font-size: var(--text-base);
    transition: all var(--transition-fast);
}

.comment-form .form-input:focus,
.comment-form .form-textarea:focus {
    outline: none;
    border-color: var(--color-primary);
    box-shadow: 0 0 0 3px rgba(30, 64, 175, 0.1);
}

.comment-form .form-textarea {
    min-height: 120px;
    resize: vertical;
}

.comment-form-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: var(--space-4);
}

.comment-form-note {
    font-size: var(--text-sm);
    color: var(--color-gray-500);
}

.btn-comment {
    padding: var(--space-3) var(--space-6);
    background: var(--color-primary);
    color: white;
    border: none;
    border-radius: var(--radius-lg);
    font-size: var(--text-base);
    font-weight: var(--font-semibold);
    cursor: pointer;
    transition: all var(--transition-fast);
}

.btn-comment:hover {
    background: var(--color-primary-dark);
}

.btn-comment:disabled {
    background: var(--color-gray-400);
    cursor: not-allowed;
}

/* Comments List */
.comments-list {
    display: flex;
    flex-direction: column;
    gap: var(--space-6);
}

.comment-item {
    display: flex;
    gap: var(--space-4);
}

.comment-avatar {
    width: 48px;
    height: 48px;
    border-radius: var(--radius-full);
    background: var(--color-primary-100);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: var(--font-bold);
    color: var(--color-primary);
    flex-shrink: 0;
}

.comment-content {
    flex: 1;
}

.comment-header {
    display: flex;
    align-items: center;
    gap: var(--space-3);
    margin-bottom: var(--space-2);
}

.comment-author {
    font-weight: var(--font-semibold);
    color: var(--color-gray-900);
}

.comment-date {
    font-size: var(--text-sm);
    color: var(--color-gray-500);
}

.comment-body {
    color: var(--color-gray-700);
    line-height: 1.6;
}

.comment-actions {
    margin-top: var(--space-2);
    display: flex;
    gap: var(--space-4);
}

.comment-action {
    font-size: var(--text-sm);
    color: var(--color-gray-500);
    background: none;
    border: none;
    cursor: pointer;
    padding: 0;
}

.comment-action:hover {
    color: var(--color-primary);
}

/* Empty state */
.comments-empty {
    text-align: center;
    padding: var(--space-10);
    color: var(--color-gray-500);
}

.comments-empty-icon {
    font-size: 48px;
    opacity: 0.3;
    margin-bottom: var(--space-3);
}

/* Success message */
.comment-success {
    background: #dcfce7;
    color: #166534;
    padding: var(--space-4);
    border-radius: var(--radius-lg);
    margin-bottom: var(--space-6);
    display: none;
}

.comment-success.show { display: block; }

/* Login prompt */
.comment-login-prompt {
    background: var(--color-gray-50);
    border-radius: var(--radius-xl);
    padding: var(--space-8);
    text-align: center;
    margin-bottom: var(--space-8);
}

.comment-login-prompt p {
    margin-bottom: var(--space-4);
    color: var(--color-gray-600);
}
</style>

<section class="comments-section" id="comentarios">
    <h2 class="comments-title">
        💬 Comentários
        <span class="comments-count"><?= $totalComentarios ?></span>
    </h2>
    
    <!-- Mensagem de sucesso -->
    <div class="comment-success" id="commentSuccess">
        ✓ Comentário enviado! Aguardando aprovação da moderação.
    </div>
    
    <!-- Formulário de Comentário -->
    <?php if (isset($_SESSION['user_id'])): ?>
    <div class="comment-form">
        <h3 class="comment-form-title">Deixe seu comentário</h3>
        <form id="commentForm">
            <input type="hidden" name="post_id" value="<?= $postId ?>">
            
            <div class="comment-form-grid">
                <input type="text" name="nome" class="form-input" placeholder="Seu nome" 
                       value="<?= e($_SESSION['user_nome'] ?? '') ?>" required>
                <input type="email" name="email" class="form-input" placeholder="Seu email (não será exibido)" 
                       value="<?= e($_SESSION['user_email'] ?? '') ?>" required>
            </div>
            
            <textarea name="conteudo" class="form-textarea" placeholder="Escreva seu comentário..." required minlength="10"></textarea>
            
            <div class="comment-form-footer">
                <span class="comment-form-note">
                    🔒 Seu email não será exibido publicamente
                </span>
                <button type="submit" class="btn-comment" id="btnComment">
                    Enviar Comentário
                </button>
            </div>
        </form>
    </div>
    <?php else: ?>
    <div class="comment-login-prompt">
        <p>Faça login para comentar nesta publicação</p>
        <a href="<?= url('login?redirect=' . urlencode($_SERVER['REQUEST_URI'])) ?>" class="btn-comment">
            Entrar
        </a>
        <span style="margin:0 var(--space-2);color:var(--color-gray-400);">ou</span>
        <a href="<?= url('registro') ?>" style="color:var(--color-primary);font-weight:var(--font-semibold);">
            Criar conta grátis
        </a>
    </div>
    <?php endif; ?>
    
    <!-- Lista de Comentários -->
    <?php if (!empty($comentarios)): ?>
    <div class="comments-list" id="commentsList">
        <?php foreach ($comentarios as $comentario): ?>
        <article class="comment-item">
            <div class="comment-avatar">
                <?= strtoupper(substr($comentario['nome'], 0, 1)) ?>
            </div>
            <div class="comment-content">
                <div class="comment-header">
                    <span class="comment-author"><?= e($comentario['nome']) ?></span>
                    <span class="comment-date"><?= timeAgo($comentario['created_at']) ?></span>
                </div>
                <div class="comment-body">
                    <?= nl2br(e($comentario['conteudo'])) ?>
                </div>
                <div class="comment-actions">
                    <button class="comment-action" onclick="denunciarComentario(<?= $comentario['id'] ?>)">
                        🚩 Denunciar
                    </button>
                </div>
            </div>
        </article>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="comments-empty">
        <div class="comments-empty-icon">💬</div>
        <p>Seja o primeiro a comentar!</p>
    </div>
    <?php endif; ?>
</section>

<script>
document.getElementById('commentForm')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const btn = document.getElementById('btnComment');
    btn.disabled = true;
    btn.textContent = 'Enviando...';
    
    const formData = new FormData(this);
    
    try {
        const res = await fetch('<?= url('api/comentario') ?>', {
            method: 'POST',
            body: formData
        });
        const data = await res.json();
        
        if (data.success) {
            document.getElementById('commentSuccess').classList.add('show');
            this.reset();
            
            // Preencher nome e email novamente se logado
            const nome = '<?= e($_SESSION['user_nome'] ?? '') ?>';
            const email = '<?= e($_SESSION['user_email'] ?? '') ?>';
            if (nome) this.querySelector('input[name="nome"]').value = nome;
            if (email) this.querySelector('input[name="email"]').value = email;
            
            // Scroll para mensagem
            document.getElementById('commentSuccess').scrollIntoView({ behavior: 'smooth' });
        } else {
            alert(data.error || 'Erro ao enviar comentário');
        }
    } catch (e) {
        alert('Erro de conexão');
    } finally {
        btn.disabled = false;
        btn.textContent = 'Enviar Comentário';
    }
});

function denunciarComentario(id) {
    const motivo = prompt('Informe o motivo da denúncia:');
    if (!motivo) return;
    
    fetch('<?= url('api/denuncia') ?>', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ comentario_id: id, motivo })
    }).then(r => r.json()).then(data => {
        alert(data.success ? 'Denúncia enviada. Obrigado!' : 'Erro ao enviar');
    });
}
</script>
