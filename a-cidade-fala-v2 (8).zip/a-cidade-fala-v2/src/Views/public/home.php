<?php
/**
 * A Cidade Fala v2.0 - Página Inicial
 */

use ACidadeFala\Config\Config;

$pageTitle = "Notícias de " . ($cidade['nome'] ?? 'sua cidade');

ob_start();
?>

<!-- Banner Topo -->
<div class="ad-container">
    <div class="ad-label">Publicidade</div>
    <div class="ad-block ad-block-topo">
        <span class="ad-placeholder">Anuncie aqui - 970x90</span>
    </div>
</div>

<!-- Hero Section - Destaques Principais -->
<?php if (!empty($featured)): ?>
<section class="hero-section">
    <div class="container">
        <div class="hero-grid">
            <!-- Post Principal -->
            <?php $mainPost = $featured[0]; ?>
            <a href="<?= url(($mainPost['tipo'] ?? 'noticia') . '/' . $mainPost['slug']) ?>" class="hero-card hero-card-main hero-main">
                <?php if (!empty($mainPost['imagem_destaque'])): ?>
                <img src="<?= upload($mainPost['imagem_destaque']) ?>" alt="<?= e($mainPost['titulo']) ?>" class="hero-card-image">
                <?php else: ?>
                <div class="hero-card-image" style="background:linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-dark) 100%);"></div>
                <?php endif; ?>
                <div class="hero-card-content">
                    <div class="hero-card-badges">
                        <span class="badge badge-<?= $mainPost['tipo'] ?? 'noticia' ?>"><?= ucfirst($mainPost['tipo'] ?? 'Notícia') ?></span>
                        <?php if (($mainPost['views'] ?? 0) > 100): ?>
                        <span class="badge badge-destaque">🔥 Em alta</span>
                        <?php endif; ?>
                    </div>
                    <h2 class="hero-card-title"><?= e($mainPost['titulo']) ?></h2>
                    <p class="hero-card-excerpt"><?= e(mb_substr(strip_tags($mainPost['conteudo']), 0, 200)) ?>...</p>
                    <div class="hero-card-meta">
                        <span><i class="lucide-clock"></i> <?= timeAgo($mainPost['publicado_em'] ?? $mainPost['created_at']) ?></span>
                        <span><i class="lucide-eye"></i> <?= number_format($mainPost['views'] ?? 0) ?> visualizações</span>
                    </div>
                </div>
            </a>
            
            <!-- Posts Secundários -->
            <div class="hero-secondary">
                <?php 
                $secondaryPosts = array_slice($featured, 1, 2);
                foreach ($secondaryPosts as $post): 
                ?>
                <a href="<?= url(($post['tipo'] ?? 'noticia') . '/' . $post['slug']) ?>" class="hero-card hero-card-small">
                    <?php if (!empty($post['imagem_destaque'])): ?>
                    <img src="<?= upload($post['imagem_destaque']) ?>" alt="<?= e($post['titulo']) ?>" class="hero-card-image">
                    <?php else: ?>
                    <div class="hero-card-image" style="background:linear-gradient(135deg, var(--color-secondary) 0%, var(--color-secondary-dark) 100%);"></div>
                    <?php endif; ?>
                    <div class="hero-card-content">
                        <div class="hero-card-badges">
                            <span class="badge badge-<?= $post['tipo'] ?? 'noticia' ?>"><?= ucfirst($post['tipo'] ?? 'Notícia') ?></span>
                        </div>
                        <h3 class="hero-card-title"><?= e($post['titulo']) ?></h3>
                        <div class="hero-card-meta">
                            <span><?= timeAgo($post['publicado_em'] ?? $post['created_at']) ?></span>
                        </div>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Conteúdo Principal com Sidebar -->
<div class="container">
    <div class="content-layout">
        
        <!-- Coluna Principal -->
        <div class="content-main">
            
            <!-- Últimas Notícias -->
            <section class="section">
                <div class="section-header">
                    <h2 class="section-title">
                        <i class="lucide-clock section-title-icon"></i>
                        Últimas Notícias
                    </h2>
                    <a href="<?= url('noticias') ?>" class="section-link">
                        Ver todas <i class="lucide-arrow-right"></i>
                    </a>
                </div>
                
                <?php if (empty($posts)): ?>
                <div style="text-align:center;padding:var(--space-12);background:var(--color-gray-50);border-radius:var(--radius-xl);">
                    <i class="lucide-newspaper" style="font-size:48px;color:var(--color-gray-400);margin-bottom:var(--space-4);display:block;"></i>
                    <h3 style="margin-bottom:var(--space-2);">Nenhuma notícia ainda</h3>
                    <p style="color:var(--color-gray-500);margin-bottom:var(--space-6);">Seja o primeiro a publicar conteúdo na sua cidade!</p>
                    <?php if (isset($currentUser)): ?>
                    <a href="<?= url('autor/publicar') ?>" class="btn btn-primary">
                        <i class="lucide-edit-3"></i> Publicar Agora
                    </a>
                    <?php else: ?>
                    <a href="<?= url('registro') ?>" class="btn btn-primary">
                        <i class="lucide-user-plus"></i> Cadastre-se para Publicar
                    </a>
                    <?php endif; ?>
                </div>
                <?php else: ?>
                
                <div class="news-grid">
                    <?php foreach (array_slice($posts, 0, 6) as $post): ?>
                    <article class="news-card">
                        <div class="news-card-image-wrapper">
                            <?php if (!empty($post['imagem_destaque'])): ?>
                            <img src="<?= upload($post['imagem_destaque']) ?>" alt="<?= e($post['titulo']) ?>" class="news-card-image" loading="lazy">
                            <?php else: ?>
                            <div class="news-card-image" style="background:linear-gradient(135deg, var(--color-gray-300) 0%, var(--color-gray-400) 100%);display:flex;align-items:center;justify-content:center;">
                                <i class="lucide-image" style="font-size:48px;color:var(--color-gray-500);"></i>
                            </div>
                            <?php endif; ?>
                            <span class="news-card-category">
                                <span class="badge badge-<?= $post['tipo'] ?? 'noticia' ?>"><?= ucfirst($post['tipo'] ?? 'Notícia') ?></span>
                            </span>
                        </div>
                        <div class="news-card-content">
                            <h3 class="news-card-title">
                                <a href="<?= url(($post['tipo'] ?? 'noticia') . '/' . $post['slug']) ?>">
                                    <?= e($post['titulo']) ?>
                                </a>
                            </h3>
                            <p class="news-card-excerpt">
                                <?= e(mb_substr(strip_tags($post['conteudo']), 0, 120)) ?>...
                            </p>
                            <div class="news-card-footer">
                                <span class="news-card-meta">
                                    <?= timeAgo($post['publicado_em'] ?? $post['created_at']) ?>
                                </span>
                                <div class="news-card-stats">
                                    <span><i class="lucide-eye"></i> <?= $post['views'] ?? 0 ?></span>
                                </div>
                            </div>
                        </div>
                    </article>
                    <?php endforeach; ?>
                </div>
                
                <?php endif; ?>
            </section>
            
            <!-- Banner Inline -->
            <div class="ad-container">
                <div class="ad-label">Publicidade</div>
                <div class="ad-block ad-block-inline">
                    <span class="ad-placeholder">Anuncie aqui - 728x90</span>
                </div>
            </div>
            
            <!-- Mais Notícias -->
            <?php if (count($posts) > 6): ?>
            <section class="section">
                <div class="section-header">
                    <h2 class="section-title">
                        <i class="lucide-layers section-title-icon"></i>
                        Mais Notícias
                    </h2>
                </div>
                
                <div class="news-grid">
                    <?php foreach (array_slice($posts, 6) as $post): ?>
                    <article class="news-card">
                        <div class="news-card-image-wrapper">
                            <?php if (!empty($post['imagem_destaque'])): ?>
                            <img src="<?= upload($post['imagem_destaque']) ?>" alt="<?= e($post['titulo']) ?>" class="news-card-image" loading="lazy">
                            <?php else: ?>
                            <div class="news-card-image" style="background:linear-gradient(135deg, var(--color-gray-300) 0%, var(--color-gray-400) 100%);"></div>
                            <?php endif; ?>
                        </div>
                        <div class="news-card-content">
                            <div class="news-card-badges">
                                <span class="badge badge-<?= $post['tipo'] ?? 'noticia' ?>"><?= ucfirst($post['tipo'] ?? 'Notícia') ?></span>
                            </div>
                            <h3 class="news-card-title">
                                <a href="<?= url(($post['tipo'] ?? 'noticia') . '/' . $post['slug']) ?>">
                                    <?= e($post['titulo']) ?>
                                </a>
                            </h3>
                            <p class="news-card-excerpt">
                                <?= e(mb_substr(strip_tags($post['conteudo']), 0, 100)) ?>...
                            </p>
                            <div class="news-card-footer">
                                <span class="news-card-meta"><?= timeAgo($post['publicado_em'] ?? $post['created_at']) ?></span>
                            </div>
                        </div>
                    </article>
                    <?php endforeach; ?>
                </div>
            </section>
            <?php endif; ?>
            
        </div>
        
        <!-- Sidebar -->
        <aside class="sidebar">
            
            <!-- Widget: Mais Lidas -->
            <div class="sidebar-widget">
                <h3 class="sidebar-widget-title">
                    <i class="lucide-trending-up"></i> Mais Lidas
                </h3>
                <?php if (!empty($featured)): ?>
                <div class="news-list news-list-numbered">
                    <?php foreach (array_slice($featured, 0, 5) as $post): ?>
                    <div class="news-list-item">
                        <div class="news-list-content">
                            <h4 class="news-list-title">
                                <a href="<?= url(($post['tipo'] ?? 'noticia') . '/' . $post['slug']) ?>">
                                    <?= e($post['titulo']) ?>
                                </a>
                            </h4>
                            <span class="news-list-meta"><?= number_format($post['views'] ?? 0) ?> visualizações</span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <p style="color:var(--color-gray-500);font-size:var(--text-sm);">Nenhuma notícia ainda.</p>
                <?php endif; ?>
            </div>
            
            <!-- Banner Sidebar -->
            <div class="ad-container">
                <div class="ad-label">Publicidade</div>
                <div class="ad-block ad-block-sidebar">
                    <span class="ad-placeholder">Anuncie aqui<br>300x250</span>
                </div>
            </div>
            
            <!-- Widget: Categorias -->
            <div class="sidebar-widget">
                <h3 class="sidebar-widget-title">
                    <i class="lucide-grid"></i> Categorias
                </h3>
                <div style="display:flex;flex-wrap:wrap;gap:var(--space-2);">
                    <?php foreach (Config::CATEGORIES as $id => $cat): ?>
                    <a href="<?= url('categoria/' . $cat['slug']) ?>" 
                       class="badge" 
                       style="background:<?= $cat['color'] ?>20;color:<?= $cat['color'] ?>;text-transform:none;">
                        <?= $cat['icon'] ?> <?= e($cat['nome']) ?>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <!-- Widget: Newsletter -->
            <div class="sidebar-widget" style="background:linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-dark) 100%);color:var(--color-white);">
                <h3 class="sidebar-widget-title" style="color:var(--color-white);border-bottom-color:rgba(255,255,255,0.3);">
                    <i class="lucide-mail"></i> Newsletter
                </h3>
                <p style="font-size:var(--text-sm);margin-bottom:var(--space-4);opacity:0.9;">
                    Receba as principais notícias da cidade direto no seu email.
                </p>
                <form id="newsletterForm">
                    <input type="email" name="email" placeholder="Seu melhor email" required
                           style="width:100%;padding:var(--space-3);border:none;border-radius:var(--radius-lg);margin-bottom:var(--space-3);">
                    <button type="submit" class="btn btn-secondary btn-block">
                        <i class="lucide-send"></i> Inscrever-se
                    </button>
                </form>
            </div>
            
            <!-- Banner Sidebar 2 -->
            <div class="ad-container">
                <div class="ad-label">Publicidade</div>
                <div class="ad-block ad-block-sidebar">
                    <span class="ad-placeholder">Anuncie aqui<br>300x250</span>
                </div>
            </div>
            
        </aside>
        
    </div>
</div>

<!-- Banner Rodapé -->
<div class="container" style="margin-top:var(--space-8);">
    <div class="ad-container">
        <div class="ad-label">Publicidade</div>
        <div class="ad-block ad-block-topo">
            <span class="ad-placeholder">Anuncie aqui - 970x90</span>
        </div>
    </div>
</div>

<script>
document.getElementById('newsletterForm')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    const email = this.querySelector('input[name="email"]').value;
    
    try {
        await apiRequest('/newsletter', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'email=' + encodeURIComponent(email)
        });
        showToast('Inscrição realizada com sucesso!', 'success');
        this.reset();
    } catch (error) {
        showToast(error.message || 'Erro ao inscrever', 'error');
    }
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/../partials/layout.php';
?>
