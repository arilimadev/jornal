<?php
use ACidadeFala\Config\Config;
$pageTitle = "Termos de Uso";
ob_start();
?>

<div class="container" style="padding:var(--space-12) 0;">
    <div style="max-width:800px;margin:0 auto;">
        <h1 style="font-size:var(--text-4xl);margin-bottom:var(--space-6);">Termos de Uso</h1>
        <p style="color:var(--color-gray-500);margin-bottom:var(--space-8);">Última atualização: <?= date('d/m/Y') ?></p>
        
        <div style="font-size:var(--text-base);line-height:var(--leading-relaxed);color:var(--color-gray-700);">
            
            <h2 style="font-size:var(--text-xl);margin:var(--space-8) 0 var(--space-4);">1. Aceitação dos Termos</h2>
            <p style="margin-bottom:var(--space-4);">
                Ao acessar e utilizar o <?= e(Config::SITE_NAME) ?>, você concorda com estes Termos de Uso. 
                Se você não concordar com qualquer parte destes termos, não deve utilizar nossos serviços.
            </p>
            
            <h2 style="font-size:var(--text-xl);margin:var(--space-8) 0 var(--space-4);">2. Uso da Plataforma</h2>
            <p style="margin-bottom:var(--space-4);">
                O <?= e(Config::SITE_NAME) ?> é uma plataforma de jornalismo colaborativo. Os usuários podem:
            </p>
            <ul style="margin-left:var(--space-6);margin-bottom:var(--space-4);">
                <li style="margin-bottom:var(--space-2);">Publicar notícias, opiniões e denúncias</li>
                <li style="margin-bottom:var(--space-2);">Comentar em publicações</li>
                <li style="margin-bottom:var(--space-2);">Anunciar produtos e serviços (para anunciantes)</li>
            </ul>
            
            <h2 style="font-size:var(--text-xl);margin:var(--space-8) 0 var(--space-4);">3. Responsabilidades do Usuário</h2>
            <p style="margin-bottom:var(--space-4);">Ao utilizar a plataforma, você se compromete a:</p>
            <ul style="margin-left:var(--space-6);margin-bottom:var(--space-4);">
                <li style="margin-bottom:var(--space-2);">Fornecer informações verdadeiras e precisas</li>
                <li style="margin-bottom:var(--space-2);">Não publicar conteúdo difamatório, calunioso ou injurioso</li>
                <li style="margin-bottom:var(--space-2);">Não violar direitos autorais ou propriedade intelectual</li>
                <li style="margin-bottom:var(--space-2);">Não publicar conteúdo ilegal ou que incite violência</li>
                <li style="margin-bottom:var(--space-2);">Respeitar outros usuários e a equipe de moderação</li>
            </ul>
            
            <h2 style="font-size:var(--text-xl);margin:var(--space-8) 0 var(--space-4);">4. Moderação de Conteúdo</h2>
            <p style="margin-bottom:var(--space-4);">
                Todas as publicações passam por moderação antes de serem publicadas. Reservamo-nos o direito de:
            </p>
            <ul style="margin-left:var(--space-6);margin-bottom:var(--space-4);">
                <li style="margin-bottom:var(--space-2);">Aprovar, rejeitar ou editar qualquer conteúdo</li>
                <li style="margin-bottom:var(--space-2);">Remover conteúdo que viole estes termos</li>
                <li style="margin-bottom:var(--space-2);">Suspender ou banir usuários que violem as regras</li>
            </ul>
            
            <h2 style="font-size:var(--text-xl);margin:var(--space-8) 0 var(--space-4);">5. Propriedade Intelectual</h2>
            <p style="margin-bottom:var(--space-4);">
                O conteúdo publicado pelos usuários permanece de sua propriedade, porém ao publicar na plataforma, 
                você nos concede uma licença não exclusiva para exibir, distribuir e promover seu conteúdo.
            </p>
            
            <h2 style="font-size:var(--text-xl);margin:var(--space-8) 0 var(--space-4);">6. Limitação de Responsabilidade</h2>
            <p style="margin-bottom:var(--space-4);">
                O <?= e(Config::SITE_NAME) ?> não se responsabiliza pelo conteúdo publicado pelos usuários. 
                A responsabilidade pelo conteúdo é exclusivamente do autor da publicação.
            </p>
            
            <h2 style="font-size:var(--text-xl);margin:var(--space-8) 0 var(--space-4);">7. Alterações nos Termos</h2>
            <p style="margin-bottom:var(--space-4);">
                Podemos atualizar estes termos a qualquer momento. Alterações significativas serão comunicadas 
                através da plataforma ou por email.
            </p>
            
            <h2 style="font-size:var(--text-xl);margin:var(--space-8) 0 var(--space-4);">8. Contato</h2>
            <p>
                Para dúvidas sobre estes termos, entre em contato através da nossa <a href="<?= url('contato') ?>">página de contato</a>.
            </p>
            
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../partials/layout.php';
?>
