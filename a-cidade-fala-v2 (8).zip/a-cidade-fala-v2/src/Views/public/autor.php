<?php
/**
 * A Cidade Fala v2.0 - Perfil do Autor
 */

use ACidadeFala\Config\Config;

$autor = $autor ?? [];
$posts = $posts ?? [];

$pageTitle = ($autor['nome'] ?? 'Autor') . ' - Perfil';
$pageDescription = "Veja as publicações de " . ($autor['nome'] ?? 'autor') . " no " . Config::SITE_NAME;

ob_start();
?>

<style>
.author-profile {
    max-width: 1200px;
    margin: 0 auto;
    padding: var(--space-8) var(--space-4);
}

.author-header {
    background: white;
    border-radius: var(--radius-2xl);
    padding: var(--space-8);
    box-shadow: var(--shadow-sm);
    margin-bottom: var(--space-8);
}

.author-header-content {
    display: flex;
    gap: var(--space-8);
    align-items: flex-start;
}

@media (max-width: 768px) {
    .author-header-content {
        flex-direction: column;
        align-items: center;
        text-align: center;
    }
}

.author-avatar {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-dark) 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 64px;
    color: white;
    font-weight: bold;
    flex-shrink: 0;
}

.author-avatar img {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    object-fit: cover;
}

.author-info { flex: 1; }

.author-name {
    font-size: var(--text-3xl);
    font-weight: var(--font-bold);
    margin-bottom: var(--space-2);
}

.author-location {
    color: var(--color-gray-500);
    font-size: var(--text-lg);
    margin-bottom: var(--space-4);
    display: flex;
    align-items: center;
    gap: var(--space-2);
}

.author-bio {
    color: var(--color-gray-600);
    line-height: 1.7;
    margin-bottom: var(--space-6);
}

.author-stats {
    display: flex;
    gap: var(--space-8);
}

.author-stat {
    text-align: center;
}

.author-stat-value {
    font-size: var(--text-2xl);
    font-weight: var(--font-bold);
    color: var(--color-primary);
}

.author-stat-label {
    font-size: var(--text-sm);
    color: var(--color-gray-500);
}

.author-badges {
    display: flex;
    gap: var(--space-2);
    margin-top: var(--space-4);
    flex-wrap: wrap;
}

.author-badge {
    display: inline-flex;
    align-items: center;
    gap: var(--space-1);
    padding: var(--space-2) var(--space-3);
    background: var(--color-gray-100);
    border-radius: var(--radius-full);
    font-size: var(--text-sm);
    color: var(--color-gray-700);
}

.author-badge.gold { background: #fef3c7; color: #b45309; }

/* Posts */
.author-section-title {
    font-size: var(--text-xl);
    font-weight: var(--font-bold);
    margin-bottom: var(--space-6);
    display: flex;
    align-items: center;
    gap: var(--space-2);
}

.posts-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: var(--space-6);
}

.post-card {
    background: var(--color-white);
    border-radius: var(--radius-xl);
    overflow: hidden;
    box-shadow: var(--shadow-sm);
    transition: all var(--transition-normal);
}

.post-card:hover {
    transform: translateY(-4px);
    box-shadow: var(--shadow-lg);
}

.post-card-image {
    width: 100%;
    height: 180px;
    object-fit: cover;
    background: var(--color-gray-100);
}

.post-card-body {
    padding: var(--space-5);
}

.post-card-category {
    display: inline-block;
    padding: var(--space-1) var(--space-3);
    background: var(--color-primary-50);
    color: var(--color-primary);
    font-size: var(--text-xs);
    font-weight: var(--font-semibold);
    border-radius: var(--radius-full);
    margin-bottom: var(--space-3);
}

.post-card-title {
    font-size: var(--text-lg);
    font-weight: var(--font-bold);
    margin-bottom: var(--space-2);
    line-height: 1.3;
}

.post-card-title a {
    color: var(--color-gray-900);
    text-decoration: none;
}

.post-card-title a:hover {
    color: var(--color-primary);
}

.post-card-meta {
    display: flex;
    gap: var(--space-4);
    font-size: var(--text-sm);
    color: var(--color-gray-500);
}

.empty-state {
    text-align: center;
    padding: var(--space-16);
    background: white;
    border-radius: var(--radius-xl);
    color: var(--color-gray-500);
}

.pagination {
    display: flex;
    justify-content: center;
    gap: var(--space-2);
    margin-top: var(--space-8);
}

.pagination a {
    padding: var(--space-2) var(--space-4);
    border: 1px solid var(--color-gray-200);
    border-radius: var(--radius-md);
    text-decoration: none;
    color: var(--color-gray-600);
}

.pagination .active {
    background: var(--color-primary);
    color: white;
    border-color: var(--color-primary);
}
</style>

<div class="author-profile">
    <!-- Header do Autor -->
    <div class="author-header">
        <div class="author-header-content">
            <div class="author-avatar">
                <?php if (!empty($autor['avatar'])): ?>
                    <img src="<?= upload($autor['avatar']) ?>" alt="<?= e($autor['nome']) ?>">
                <?php else: ?>
                    <?= strtoupper(substr($autor['nome'] ?? 'A', 0, 1)) ?>
                <?php endif; ?>
            </div>
            
            <div class="author-info">
                <h1 class="author-name"><?= e($autor['nome'] ?? 'Autor') ?></h1>
                
                <?php if (!empty($autor['cidade_nome'])): ?>
                <div class="author-location">
                    📍 <?= e($autor['cidade_nome']) ?>, <?= e($autor['estado_uf'] ?? '') ?>
                </div>
                <?php endif; ?>
                
                <?php if (!empty($autor['bio'])): ?>
                <p class="author-bio"><?= nl2br(e($autor['bio'])) ?></p>
                <?php endif; ?>
                
                <div class="author-stats">
                    <div class="author-stat">
                        <div class="author-stat-value"><?= number_format($stats['total_posts'] ?? 0) ?></div>
                        <div class="author-stat-label">Publicações</div>
                    </div>
                    <div class="author-stat">
                        <div class="author-stat-value"><?= number_format($stats['total_views'] ?? 0) ?></div>
                        <div class="author-stat-label">Visualizações</div>
                    </div>
                    <div class="author-stat">
                        <div class="author-stat-value"><?= number_format($stats['total_comentarios'] ?? 0) ?></div>
                        <div class="author-stat-label">Comentários</div>
                    </div>
                </div>
                
                <div class="author-badges">
                    <?php if ($autor['identidade_verificada'] ?? false): ?>
                        <span class="author-badge">✓ Verificado</span>
                    <?php endif; ?>
                    
                    <?php if (($stats['total_posts'] ?? 0) >= 10): ?>
                        <span class="author-badge gold">🏆 Autor Ativo</span>
                    <?php endif; ?>
                    
                    <?php if (($stats['total_views'] ?? 0) >= 1000): ?>
                        <span class="author-badge gold">🔥 Popular</span>
                    <?php endif; ?>
                    
                    <span class="author-badge">📅 Desde <?= formatDate($autor['created_at'] ?? '', 'M/Y') ?></span>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Posts do Autor -->
    <h2 class="author-section-title">📰 Publicações</h2>
    
    <?php if (!empty($posts)): ?>
        <div class="posts-grid">
            <?php foreach ($posts as $post): ?>
                <article class="post-card">
                    <?php if ($post['imagem_capa']): ?>
                        <img src="<?= upload($post['imagem_capa']) ?>" class="post-card-image" alt="<?= e($post['titulo']) ?>">
                    <?php else: ?>
                        <div class="post-card-image" style="display:flex;align-items:center;justify-content:center;font-size:48px;color:#d1d5db;">📰</div>
                    <?php endif; ?>
                    
                    <div class="post-card-body">
                        <?php if (!empty($post['categoria_nome'])): ?>
                            <span class="post-card-category"><?= e($post['categoria_icone'] ?? '') ?> <?= e($post['categoria_nome']) ?></span>
                        <?php endif; ?>
                        
                        <h3 class="post-card-title">
                            <a href="<?= url($post['estado_uf'] . '/' . $post['cidade_slug'] . '/' . $post['slug']) ?>">
                                <?= e($post['titulo']) ?>
                            </a>
                        </h3>
                        
                        <div class="post-card-meta">
                            <span>📍 <?= e($post['cidade_nome'] ?? '') ?></span>
                            <span>📅 <?= timeAgo($post['publicado_em'] ?? $post['created_at']) ?></span>
                            <span>👁️ <?= number_format($post['visualizacoes'] ?? 0) ?></span>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
        
        <!-- Paginação -->
        <?php if (($totalPages ?? 1) > 1): ?>
        <div class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?page=<?= $i ?>" class="<?= ($page ?? 1) == $i ? 'active' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>
        </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="empty-state">
            <div style="font-size:64px;opacity:0.3;margin-bottom:16px;">📝</div>
            <h3>Nenhuma publicação ainda</h3>
            <p>Este autor ainda não publicou nenhum conteúdo</p>
        </div>
    <?php endif; ?>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../partials/layout.php';
?>
