<?php
/**
 * A Cidade Fala v2.0 - Layout Principal
 */

use ACidadeFala\Config\Config;

// Funções helper (definir apenas se não existirem)
if (!function_exists('asset')) {
    function asset($path) {
        return Config::getBaseUrl() . '/assets/' . ltrim($path, '/');
    }
}

if (!function_exists('url')) {
    function url($path = '') {
        return Config::getBaseUrl() . '/' . ltrim($path, '/');
    }
}

if (!function_exists('upload')) {
    function upload($path) {
        return Config::getBaseUrl() . '/uploads/' . ltrim($path, '/');
    }
}

if (!function_exists('e')) {
    function e($string) {
        return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('timeAgo')) {
    function timeAgo($datetime) {
        return Config::timeAgo($datetime);
    }
}

if (!function_exists('formatDate')) {
    function formatDate($date, $format = 'd/m/Y') {
        return Config::formatDate($date, $format);
    }
}

// Dados padrão
$pageTitle = $pageTitle ?? 'Portal de Notícias';
$pageDescription = $pageDescription ?? Config::SITE_DESCRIPTION;
$bodyClass = $bodyClass ?? '';
?>
<!DOCTYPE html>
<html lang="pt-BR" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= e($pageDescription) ?>">
    <meta name="keywords" content="<?= e(Config::SITE_KEYWORDS) ?>">
    
    <title><?= e($pageTitle) ?> - <?= e(Config::SITE_NAME) ?></title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="<?= asset('images/favicon.svg') ?>">
    
    <!-- Preconnect -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Montserrat:wght@500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/lucide-static@0.263.1/font/lucide.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="<?= asset('css/variables.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/components.css') ?>">
    
    <!-- Open Graph -->
    <meta property="og:title" content="<?= e($pageTitle) ?> - <?= e(Config::SITE_NAME) ?>">
    <meta property="og:description" content="<?= e($pageDescription) ?>">
    <meta property="og:type" content="website">
    <meta property="og:locale" content="pt_BR">
    
    <?php if (isset($extraHead)) echo $extraHead; ?>
</head>
<body class="<?= e($bodyClass) ?>">
    <div class="page-wrapper">
        
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="container">
                <div class="top-bar-content">
                    <div class="top-bar-date">
                        <i class="lucide-calendar"></i>
                        <span><?= dataExtenso() ?></span>
                    </div>
                    <div class="top-bar-links">
                        <a href="<?= url('sobre') ?>">Sobre</a>
                        <a href="<?= url('contato') ?>">Contato</a>
                        <button class="theme-toggle" onclick="toggleTheme()" title="Alternar tema">
                            <i class="lucide-moon"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Header Principal -->
        <header class="site-header">
            <div class="header-main">
                <div class="container">
                    <div class="header-content">
                        
                        <!-- Logo -->
                        <a href="<?= url('/') ?>" class="site-logo">
                            <svg class="logo-icon" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect width="48" height="48" rx="12" fill="#1a365d"/>
                                <path d="M12 14h24v4H12zM12 22h20v3H12zM12 29h24v3H12zM12 36h16v3H12z" fill="#fff"/>
                                <circle cx="38" cy="38" r="8" fill="#dc2626"/>
                                <path d="M35 38l2 2 4-4" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <div class="logo-text">
                                <span class="logo-name"><?= e(Config::SITE_NAME) ?></span>
                                <span class="logo-tagline"><?= e(Config::SITE_TAGLINE) ?></span>
                            </div>
                        </a>
                        
                        <!-- Seletor de Cidade -->
                        <?php if (isset($currentCity) && $currentCity): ?>
                        <a href="<?= url('selecionar-cidade') ?>" class="city-selector">
                            <i class="lucide-map-pin city-selector-icon"></i>
                            <div class="city-selector-text">
                                <span class="city-selector-label">Você está em</span>
                                <span class="city-selector-name"><?= e($currentCity['nome']) ?>, <?= e($currentCity['estado_uf']) ?></span>
                            </div>
                            <i class="lucide-chevron-down"></i>
                        </a>
                        <?php endif; ?>
                        
                        <!-- Busca (Desktop) -->
                        <div class="header-search">
                            <form action="<?= url('busca') ?>" method="GET">
                                <i class="lucide-search search-icon"></i>
                                <input type="text" name="q" class="search-input" placeholder="Buscar notícias..." autocomplete="off">
                            </form>
                        </div>
                        
                        <!-- Ações -->
                        <div class="header-actions">
                            <button class="btn-search-mobile" onclick="toggleMobileSearch()">
                                <i class="lucide-search"></i>
                            </button>
                            
                            <?php if (isset($currentUser) && $currentUser): ?>
                                <a href="<?= url('autor/publicar') ?>" class="btn-publish">
                                    <i class="lucide-edit-3"></i>
                                    <span>Publicar</span>
                                </a>
                                
                                <div class="user-menu">
                                    <div class="user-avatar" onclick="toggleUserMenu()">
                                        <?= strtoupper(substr($currentUser['nome'], 0, 1)) ?>
                                    </div>
                                    <div class="user-dropdown" id="userDropdown">
                                        <div class="user-dropdown-header">
                                            <div class="user-dropdown-name"><?= e($currentUser['nome']) ?></div>
                                            <div class="user-dropdown-email"><?= e($currentUser['email']) ?></div>
                                        </div>
                                        <div class="user-dropdown-menu">
                                            <?php if ($currentUser['tipo'] === 'admin'): ?>
                                                <a href="<?= url('admin') ?>" class="user-dropdown-item">
                                                    <i class="lucide-shield"></i>
                                                    Painel Admin
                                                </a>
                                            <?php elseif ($currentUser['tipo'] === 'anunciante'): ?>
                                                <a href="<?= url('anunciante') ?>" class="user-dropdown-item">
                                                    <i class="lucide-bar-chart-2"></i>
                                                    Meus Anúncios
                                                </a>
                                            <?php else: ?>
                                                <a href="<?= url('autor') ?>" class="user-dropdown-item">
                                                    <i class="lucide-layout-dashboard"></i>
                                                    Meu Painel
                                                </a>
                                                <a href="<?= url('autor/posts') ?>" class="user-dropdown-item">
                                                    <i class="lucide-file-text"></i>
                                                    Meus Posts
                                                </a>
                                            <?php endif; ?>
                                            <a href="<?= url('autor/perfil') ?>" class="user-dropdown-item">
                                                <i class="lucide-user"></i>
                                                Meu Perfil
                                            </a>
                                            <div class="user-dropdown-divider"></div>
                                            <a href="<?= url('logout') ?>" class="user-dropdown-item danger">
                                                <i class="lucide-log-out"></i>
                                                Sair
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <a href="<?= url('login') ?>" class="btn btn-outline btn-sm">Entrar</a>
                                <a href="<?= url('registro') ?>" class="btn btn-primary btn-sm" style="display:none;">Cadastrar</a>
                            <?php endif; ?>
                            
                            <button class="mobile-menu-toggle" onclick="toggleMobileMenu()">
                                <i class="lucide-menu"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Navegação Principal (Desktop) -->
            <nav class="main-nav">
                <div class="container">
                    <div class="nav-container">
                        <ul class="nav-menu">
                            <li class="nav-item">
                                <a href="<?= url('/') ?>" class="nav-link <?= ($_SERVER['REQUEST_URI'] == '/' ? 'active' : '') ?>">
                                    <i class="lucide-home"></i>
                                    Início
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?= url('noticias') ?>" class="nav-link">
                                    <i class="lucide-newspaper"></i>
                                    Notícias
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?= url('opinioes') ?>" class="nav-link">
                                    <i class="lucide-message-square"></i>
                                    Opinião
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?= url('denuncias') ?>" class="nav-link">
                                    <i class="lucide-alert-triangle"></i>
                                    Denúncias
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link">
                                    <i class="lucide-grid"></i>
                                    Categorias
                                    <i class="lucide-chevron-down" style="margin-left:4px;"></i>
                                </a>
                                <div class="nav-dropdown">
                                    <?php foreach (Config::CATEGORIES as $id => $cat): ?>
                                    <a href="<?= url('categoria/' . $cat['slug']) ?>" class="nav-dropdown-item">
                                        <?= $cat['icon'] ?> <?= e($cat['nome']) ?>
                                    </a>
                                    <?php endforeach; ?>
                                </div>
                            </li>
                        </ul>
                        
                        <div class="nav-categories">
                            <?php 
                            $topCategories = array_slice(Config::CATEGORIES, 0, 5, true);
                            foreach ($topCategories as $id => $cat): 
                            ?>
                            <a href="<?= url('categoria/' . $cat['slug']) ?>" class="nav-category"><?= $cat['icon'] ?> <?= e($cat['nome']) ?></a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </nav>
        </header>
        
        <!-- Menu Mobile -->
        <div class="mobile-menu" id="mobileMenu">
            <div class="mobile-menu-header">
                <span class="logo-name" style="color:var(--color-primary);font-weight:800;"><?= e(Config::SITE_NAME) ?></span>
                <button class="mobile-menu-close" onclick="toggleMobileMenu()">
                    <i class="lucide-x"></i>
                </button>
            </div>
            <div class="mobile-menu-search">
                <form action="<?= url('busca') ?>" method="GET">
                    <input type="text" name="q" placeholder="Buscar notícias...">
                </form>
            </div>
            <ul class="mobile-nav-menu">
                <li class="mobile-nav-item">
                    <a href="<?= url('/') ?>" class="mobile-nav-link">
                        <span><i class="lucide-home"></i> Início</span>
                    </a>
                </li>
                <li class="mobile-nav-item">
                    <a href="<?= url('noticias') ?>" class="mobile-nav-link">
                        <span><i class="lucide-newspaper"></i> Notícias</span>
                    </a>
                </li>
                <li class="mobile-nav-item">
                    <a href="<?= url('opinioes') ?>" class="mobile-nav-link">
                        <span><i class="lucide-message-square"></i> Opinião</span>
                    </a>
                </li>
                <li class="mobile-nav-item">
                    <a href="<?= url('denuncias') ?>" class="mobile-nav-link">
                        <span><i class="lucide-alert-triangle"></i> Denúncias</span>
                    </a>
                </li>
            </ul>
            <div class="mobile-menu-footer">
                <?php if (isset($currentUser) && $currentUser): ?>
                    <a href="<?= url('autor') ?>" class="btn btn-primary btn-block">Meu Painel</a>
                <?php else: ?>
                    <a href="<?= url('login') ?>" class="btn btn-primary btn-block">Entrar</a>
                    <a href="<?= url('registro') ?>" class="btn btn-outline btn-block mt-4">Cadastrar</a>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Conteúdo Principal -->
        <main class="main-content">
            <?php if (isset($content)) echo $content; ?>
        </main>
        
        <!-- Footer -->
        <footer class="site-footer">
            <div class="container">
                <div class="footer-grid">
                    <div class="footer-brand">
                        <div class="footer-logo"><?= e(Config::SITE_NAME) ?></div>
                        <p class="footer-description">
                            <?= e(Config::SITE_TAGLINE) ?>. 
                            Plataforma colaborativa de jornalismo cidadão, dando voz à sua comunidade.
                        </p>
                        <div class="footer-social">
                            <?php if (Config::SOCIAL_FACEBOOK): ?>
                            <a href="<?= e(Config::SOCIAL_FACEBOOK) ?>" target="_blank" title="Facebook">
                                <i class="lucide-facebook"></i>
                            </a>
                            <?php endif; ?>
                            <?php if (Config::SOCIAL_INSTAGRAM): ?>
                            <a href="<?= e(Config::SOCIAL_INSTAGRAM) ?>" target="_blank" title="Instagram">
                                <i class="lucide-instagram"></i>
                            </a>
                            <?php endif; ?>
                            <?php if (Config::SOCIAL_TWITTER): ?>
                            <a href="<?= e(Config::SOCIAL_TWITTER) ?>" target="_blank" title="Twitter">
                                <i class="lucide-twitter"></i>
                            </a>
                            <?php endif; ?>
                            <?php if (Config::SOCIAL_YOUTUBE): ?>
                            <a href="<?= e(Config::SOCIAL_YOUTUBE) ?>" target="_blank" title="YouTube">
                                <i class="lucide-youtube"></i>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="footer-section">
                        <h4 class="footer-section-title">Navegação</h4>
                        <ul class="footer-links">
                            <li><a href="<?= url('/') ?>">Início</a></li>
                            <li><a href="<?= url('noticias') ?>">Notícias</a></li>
                            <li><a href="<?= url('opinioes') ?>">Opinião</a></li>
                            <li><a href="<?= url('denuncias') ?>">Denúncias</a></li>
                        </ul>
                    </div>
                    
                    <div class="footer-section">
                        <h4 class="footer-section-title">Institucional</h4>
                        <ul class="footer-links">
                            <li><a href="<?= url('sobre') ?>">Sobre Nós</a></li>
                            <li><a href="<?= url('contato') ?>">Contato</a></li>
                            <li><a href="<?= url('termos') ?>">Termos de Uso</a></li>
                            <li><a href="<?= url('privacidade') ?>">Privacidade</a></li>
                        </ul>
                    </div>
                    
                    <div class="footer-section">
                        <h4 class="footer-section-title">Participe</h4>
                        <ul class="footer-links">
                            <li><a href="<?= url('registro') ?>">Cadastre-se</a></li>
                            <li><a href="<?= url('autor/publicar') ?>">Publicar Notícia</a></li>
                            <li><a href="<?= url('anunciante') ?>">Anuncie Aqui</a></li>
                        </ul>
                    </div>
                </div>
                
                <div class="footer-bottom">
                    <p>&copy; <?= date('Y') ?> <?= e(Config::SITE_NAME) ?>. Todos os direitos reservados.</p>
                    <p style="margin-top:var(--space-2);">Desenvolvido por <strong>CTRL ADS</strong></p>
                </div>
            </div>
        </footer>
        
    </div>
    
    <!-- Toast Container -->
    <div class="toast-container" id="toastContainer"></div>
    
    <!-- Scripts -->
    <script>
        // Configuração global
        window.ACF = {
            baseUrl: '<?= Config::getBaseUrl() ?>',
            apiUrl: '<?= Config::getBaseUrl() ?>/api'
        };
        
        // Toggle do menu de usuário
        function toggleUserMenu() {
            document.getElementById('userDropdown')?.classList.toggle('active');
        }
        
        // Toggle do menu mobile
        function toggleMobileMenu() {
            document.getElementById('mobileMenu')?.classList.toggle('active');
        }
        
        // Toggle de tema
        function toggleTheme() {
            const html = document.documentElement;
            const currentTheme = html.getAttribute('data-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            html.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
        }
        
        // Aplicar tema salvo
        const savedTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', savedTheme);
        
        // Fechar dropdowns ao clicar fora
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.user-menu')) {
                document.getElementById('userDropdown')?.classList.remove('active');
            }
        });
        
        // Toast notification
        function showToast(message, type = 'info', duration = 5000) {
            const container = document.getElementById('toastContainer');
            const toast = document.createElement('div');
            toast.className = 'toast';
            
            const icons = {
                success: 'check-circle',
                error: 'x-circle',
                warning: 'alert-triangle',
                info: 'info'
            };
            
            const colors = {
                success: 'var(--color-success)',
                error: 'var(--color-error)',
                warning: 'var(--color-warning)',
                info: 'var(--color-info)'
            };
            
            toast.innerHTML = `
                <i class="lucide-${icons[type]} toast-icon" style="color:${colors[type]}"></i>
                <div class="toast-content">
                    <div class="toast-message">${message}</div>
                </div>
                <button class="toast-close" onclick="this.parentElement.remove()">
                    <i class="lucide-x"></i>
                </button>
            `;
            
            container.appendChild(toast);
            
            setTimeout(() => {
                toast.style.animation = 'slideOut 0.3s ease forwards';
                setTimeout(() => toast.remove(), 300);
            }, duration);
        }
        
        // API Request helper
        async function apiRequest(endpoint, options = {}) {
            const url = window.ACF.apiUrl + endpoint;
            const defaultOptions = {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            };
            
            const response = await fetch(url, { ...defaultOptions, ...options });
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'Erro na requisição');
            }
            
            return data;
        }
    </script>
    
    <script src="<?= asset('js/main.js') ?>"></script>
    
    <?php if (isset($extraScripts)) echo $extraScripts; ?>
</body>
</html>
