<?php
/**
 * A Cidade Fala v2.0 - Configurações do Site
 */

use ACidadeFala\Config\Config;

$pageTitle = "Configurações";
$activeMenu = "configuracoes";

// Agrupar configurações
$gruposConfig = [
    'geral' => ['titulo' => '🏠 Informações Gerais', 'configs' => []],
    'aparencia' => ['titulo' => '🎨 Aparência', 'configs' => []],
    'contato' => ['titulo' => '📞 Contato', 'configs' => []],
    'redes' => ['titulo' => '🌐 Redes Sociais', 'configs' => []],
    'seo' => ['titulo' => '🔍 SEO', 'configs' => []],
    'moderacao' => ['titulo' => '⚙️ Moderação', 'configs' => []],
    'posts' => ['titulo' => '📰 Posts', 'configs' => []],
];

foreach ($configuracoes ?? [] as $config) {
    $grupo = $config['grupo'] ?? 'geral';
    if (isset($gruposConfig[$grupo])) {
        $gruposConfig[$grupo]['configs'][] = $config;
    }
}

ob_start();
?>

<div class="tabs" style="margin-bottom:24px;">
    <?php foreach ($gruposConfig as $key => $grupo): ?>
        <?php if (!empty($grupo['configs'])): ?>
            <a href="#<?= $key ?>" class="tab" onclick="showTab('<?= $key ?>')"><?= $grupo['titulo'] ?></a>
        <?php endif; ?>
    <?php endforeach; ?>
</div>

<form id="configForm">
    <?php foreach ($gruposConfig as $key => $grupo): ?>
        <?php if (!empty($grupo['configs'])): ?>
        <div class="config-section card" id="tab-<?= $key ?>" style="<?= $key !== 'geral' ? 'display:none;' : '' ?>">
            <div class="card-header">
                <h3 class="card-title"><?= $grupo['titulo'] ?></h3>
            </div>
            <div class="card-body">
                <?php foreach ($grupo['configs'] as $config): ?>
                    <div class="form-group">
                        <label class="form-label">
                            <?= e($config['descricao'] ?? $config['chave']) ?>
                            <small style="color:#94a3b8;font-weight:normal;margin-left:8px;">(<?= e($config['chave']) ?>)</small>
                        </label>
                        
                        <?php if ($config['tipo'] === 'boolean'): ?>
                            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                                <input type="checkbox" name="config[<?= e($config['chave']) ?>]" value="true" <?= $config['valor'] === 'true' ? 'checked' : '' ?>>
                                Ativado
                            </label>
                        
                        <?php elseif ($config['tipo'] === 'color'): ?>
                            <div style="display:flex;align-items:center;gap:12px;">
                                <input type="color" name="config[<?= e($config['chave']) ?>]" value="<?= e($config['valor']) ?>" style="width:60px;height:40px;border:none;cursor:pointer;">
                                <input type="text" value="<?= e($config['valor']) ?>" class="form-input" style="width:120px;" onchange="this.previousElementSibling.value = this.value">
                            </div>
                        
                        <?php elseif ($config['tipo'] === 'image'): ?>
                            <div style="display:flex;align-items:center;gap:16px;">
                                <?php if ($config['valor']): ?>
                                    <img src="<?= e($config['valor']) ?>" style="max-width:150px;max-height:80px;border:1px solid #e2e8f0;border-radius:8px;">
                                <?php endif; ?>
                                <div>
                                    <input type="file" name="config_file[<?= e($config['chave']) ?>]" class="form-input" accept="image/*">
                                    <input type="hidden" name="config[<?= e($config['chave']) ?>]" value="<?= e($config['valor']) ?>">
                                </div>
                            </div>
                        
                        <?php elseif ($config['tipo'] === 'html'): ?>
                            <textarea name="config[<?= e($config['chave']) ?>]" class="form-textarea" rows="6"><?= e($config['valor']) ?></textarea>
                        
                        <?php elseif ($config['tipo'] === 'number'): ?>
                            <input type="number" name="config[<?= e($config['chave']) ?>]" class="form-input" value="<?= e($config['valor']) ?>" style="max-width:200px;">
                        
                        <?php else: ?>
                            <input type="text" name="config[<?= e($config['chave']) ?>]" class="form-input" value="<?= e($config['valor']) ?>">
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    <?php endforeach; ?>
    
    <div style="position:sticky;bottom:0;background:white;padding:20px;border-top:1px solid #e2e8f0;margin:0 -24px -24px;display:flex;gap:12px;justify-content:flex-end;">
        <button type="button" class="btn btn-outline" onclick="location.reload()">Cancelar</button>
        <button type="submit" class="btn btn-primary btn-lg">💾 Salvar Configurações</button>
    </div>
</form>

<!-- Preview de cores -->
<div class="card" style="margin-top:24px;">
    <div class="card-header">
        <h3 class="card-title">👁️ Preview do Tema</h3>
    </div>
    <div class="card-body">
        <div id="themePreview" style="padding:20px;border-radius:8px;border:1px solid #e2e8f0;">
            <div style="padding:16px;border-radius:8px;margin-bottom:16px;color:white;" id="previewPrimary">
                Cor Primária
            </div>
            <div style="padding:16px;border-radius:8px;color:white;" id="previewSecondary">
                Cor Secundária
            </div>
        </div>
    </div>
</div>

<style>
.config-section { margin-bottom: 24px; }
</style>

<script>
let activeTab = 'geral';

function showTab(tab) {
    document.querySelectorAll('.config-section').forEach(s => s.style.display = 'none');
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.getElementById('tab-' + tab).style.display = 'block';
    document.querySelector(`.tab[onclick="showTab('${tab}')"]`)?.classList.add('active');
    activeTab = tab;
}

// Inicializar primeiro tab
document.querySelector('.tab')?.classList.add('active');

// Preview de cores
function updateColorPreview() {
    const primary = document.querySelector('input[name="config[cor_primaria]"]')?.value || '#1e40af';
    const secondary = document.querySelector('input[name="config[cor_secundaria]"]')?.value || '#dc2626';
    
    document.getElementById('previewPrimary').style.background = primary;
    document.getElementById('previewSecondary').style.background = secondary;
}

document.querySelectorAll('input[type="color"]').forEach(input => {
    input.addEventListener('input', updateColorPreview);
});
updateColorPreview();

// Submit
document.getElementById('configForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    try {
        const res = await fetch('<?= url('api/admin/configuracoes') ?>', {
            method: 'POST',
            body: formData
        });
        const data = await res.json();
        
        if (data.success) {
            alert('Configurações salvas!');
            location.reload();
        } else {
            alert(data.error || 'Erro ao salvar');
        }
    } catch (e) {
        alert('Erro de conexão');
    }
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
