<?php
/**
 * A Cidade Fala v2.0 - Gerenciar Cidades
 */

use ACidadeFala\Config\Config;

$pageTitle = "Gerenciar Cidades";
$activeMenu = "cidades";

ob_start();
?>

<div class="quick-actions">
    <button class="btn btn-primary" onclick="abrirModalCidade()">➕ Nova Cidade</button>
    <a href="<?= url('admin/estados') ?>" class="btn btn-outline">🗺️ Estados</a>
    <a href="<?= url('admin/bairros') ?>" class="btn btn-outline">📍 Bairros</a>
</div>

<!-- Filtros -->
<div class="card" style="margin-bottom:20px;">
    <div class="card-body" style="padding:16px 24px;">
        <form class="search-box" method="GET">
            <select name="estado_id" class="form-select" style="width:200px;">
                <option value="">Todos os estados</option>
                <?php foreach ($estados ?? [] as $estado): ?>
                    <option value="<?= $estado['id'] ?>" <?= ($_GET['estado_id'] ?? '') == $estado['id'] ? 'selected' : '' ?>>
                        <?= e($estado['nome']) ?> (<?= e($estado['uf']) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
            <input type="text" name="busca" class="search-input" placeholder="Buscar cidade..." value="<?= e($_GET['busca'] ?? '') ?>">
            <button type="submit" class="btn btn-primary">🔍 Filtrar</button>
        </form>
    </div>
</div>

<!-- Lista -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">🏙️ Cidades Cadastradas (<?= count($cidades ?? []) ?>)</h3>
    </div>
    
    <?php if (!empty($cidades)): ?>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Cidade</th>
                    <th>Estado</th>
                    <th>Slug</th>
                    <th>Posts</th>
                    <th>Bairros</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cidades as $cidade): ?>
                <tr id="cidade-row-<?= $cidade['id'] ?>">
                    <td><strong><?= e($cidade['nome']) ?></strong></td>
                    <td>
                        <span class="badge badge-info"><?= e($cidade['estado_uf'] ?? $cidade['uf'] ?? '') ?></span>
                    </td>
                    <td><code style="font-size:12px;background:#f1f5f9;padding:2px 8px;border-radius:4px;"><?= e($cidade['slug']) ?></code></td>
                    <td><?= $cidade['total_posts'] ?? 0 ?></td>
                    <td><?= $cidade['total_bairros'] ?? 0 ?></td>
                    <td>
                        <?php if ($cidade['ativo']): ?>
                            <span class="badge badge-success">Ativa</span>
                        <?php else: ?>
                            <span class="badge badge-danger">Inativa</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="actions">
                            <button class="btn btn-sm btn-outline" onclick="editarCidade(<?= htmlspecialchars(json_encode($cidade)) ?>)" title="Editar">✏️</button>
                            <a href="<?= url('admin/bairros?cidade_id=' . $cidade['id']) ?>" class="btn btn-sm btn-outline" title="Bairros">📍</a>
                            <button class="btn btn-sm btn-danger" onclick="excluirCidade(<?= $cidade['id'] ?>)" title="Excluir">🗑️</button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="card-body">
        <div class="empty-state">
            <div class="empty-state-icon">🏙️</div>
            <div class="empty-state-title">Nenhuma cidade encontrada</div>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Modal Cidade -->
<div class="modal" id="modalCidade">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalCidadeTitle">➕ Nova Cidade</h3>
            <button class="modal-close" onclick="fecharModal('modalCidade')">✕</button>
        </div>
        <form id="cidadeForm">
            <div class="modal-body">
                <input type="hidden" name="id" id="cidadeId">
                
                <div class="form-group">
                    <label class="form-label">Estado *</label>
                    <select name="estado_id" id="cidadeEstado" class="form-select" required>
                        <option value="">Selecione...</option>
                        <?php foreach ($estados ?? [] as $estado): ?>
                            <option value="<?= $estado['id'] ?>"><?= e($estado['nome']) ?> (<?= e($estado['uf']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Nome da Cidade *</label>
                    <input type="text" name="nome" id="cidadeNome" class="form-input" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Slug (URL)</label>
                    <input type="text" name="slug" id="cidadeSlug" class="form-input" placeholder="gerado-automaticamente">
                    <small style="color:#64748b;">Deixe em branco para gerar automaticamente</small>
                </div>
                
                <div class="form-group">
                    <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                        <input type="checkbox" name="ativo" id="cidadeAtivo" value="1" checked>
                        Cidade ativa
                    </label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="fecharModal('modalCidade')">Cancelar</button>
                <button type="submit" class="btn btn-primary">💾 Salvar</button>
            </div>
        </form>
    </div>
</div>

<style>
.modal {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.6);
    z-index: 1000;
    align-items: center;
    justify-content: center;
    padding: 20px;
}
.modal.show { display: flex; }
.modal-content {
    background: white;
    border-radius: 12px;
    max-width: 500px;
    width: 100%;
}
.modal-header {
    padding: 20px 24px;
    border-bottom: 1px solid #e2e8f0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.modal-header h3 { margin: 0; }
.modal-close { background: none; border: none; font-size: 20px; cursor: pointer; color: #64748b; }
.modal-body { padding: 24px; }
.modal-footer {
    padding: 16px 24px;
    border-top: 1px solid #e2e8f0;
    display: flex;
    gap: 12px;
    justify-content: flex-end;
}
</style>

<script>
function abrirModalCidade() {
    document.getElementById('modalCidadeTitle').textContent = '➕ Nova Cidade';
    document.getElementById('cidadeForm').reset();
    document.getElementById('cidadeId').value = '';
    document.getElementById('modalCidade').classList.add('show');
}

function editarCidade(cidade) {
    document.getElementById('modalCidadeTitle').textContent = '✏️ Editar Cidade';
    document.getElementById('cidadeId').value = cidade.id;
    document.getElementById('cidadeEstado').value = cidade.estado_id;
    document.getElementById('cidadeNome').value = cidade.nome;
    document.getElementById('cidadeSlug').value = cidade.slug;
    document.getElementById('cidadeAtivo').checked = cidade.ativo;
    document.getElementById('modalCidade').classList.add('show');
}

function fecharModal(id) {
    document.getElementById(id).classList.remove('show');
}

document.getElementById('cidadeForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const id = formData.get('id');
    const isEdit = id ? true : false;
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/cidade${isEdit ? '/' + id : ''}`, {
            method: isEdit ? 'PUT' : 'POST',
            body: formData
        });
        const data = await res.json();
        
        if (data.success) {
            location.reload();
        } else {
            alert(data.error || 'Erro ao salvar');
        }
    } catch (e) {
        alert('Erro de conexão');
    }
});

async function excluirCidade(id) {
    if (!confirm('Excluir esta cidade? Posts e bairros associados também serão afetados.')) return;
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/cidade/${id}`, { method: 'DELETE' });
        const data = await res.json();
        
        if (data.success) {
            document.getElementById(`cidade-row-${id}`)?.remove();
        } else {
            alert(data.error || 'Erro ao excluir');
        }
    } catch (e) {
        alert('Erro de conexão');
    }
}

// Fechar modal clicando fora
document.getElementById('modalCidade').addEventListener('click', e => {
    if (e.target.id === 'modalCidade') fecharModal('modalCidade');
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
