<?php
/**
 * A Cidade Fala v2.0 - Layout Admin
 */

use ACidadeFala\Config\Config;

$pageTitle = $pageTitle ?? 'Painel Admin';
$activeMenu = $activeMenu ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> - Admin | <?= e(Config::SITE_NAME) ?></title>
    <link rel="icon" type="image/svg+xml" href="<?= asset('images/favicon.svg') ?>">
    <link rel="stylesheet" href="<?= asset('css/variables.css') ?>">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f1f5f9; min-height: 100vh; }
        
        /* Layout */
        .admin-layout { display: flex; min-height: 100vh; }
        
        /* Sidebar */
        .admin-sidebar {
            width: 260px;
            background: linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
            color: white;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 100;
        }
        
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            text-align: center;
        }
        
        .sidebar-logo {
            font-size: 20px;
            font-weight: 700;
            color: white;
            text-decoration: none;
        }
        
        .sidebar-subtitle {
            font-size: 12px;
            color: #94a3b8;
            margin-top: 4px;
        }
        
        .sidebar-menu { padding: 16px 0; }
        
        .menu-section {
            padding: 8px 20px;
            font-size: 11px;
            font-weight: 600;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-top: 8px;
        }
        
        .menu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: #cbd5e1;
            text-decoration: none;
            transition: all 0.2s;
            border-left: 3px solid transparent;
        }
        
        .menu-item:hover {
            background: rgba(255,255,255,0.05);
            color: white;
        }
        
        .menu-item.active {
            background: rgba(59, 130, 246, 0.2);
            color: #60a5fa;
            border-left-color: #3b82f6;
        }
        
        .menu-item .icon { font-size: 18px; width: 24px; text-align: center; }
        .menu-item .badge {
            margin-left: auto;
            background: #ef4444;
            color: white;
            font-size: 11px;
            padding: 2px 8px;
            border-radius: 10px;
        }
        
        /* Main Content */
        .admin-main {
            flex: 1;
            margin-left: 260px;
            min-height: 100vh;
        }
        
        /* Top Bar */
        .admin-topbar {
            background: white;
            padding: 16px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 50;
        }
        
        .topbar-title { font-size: 20px; font-weight: 600; color: #1e293b; }
        
        .topbar-actions { display: flex; align-items: center; gap: 16px; }
        
        .topbar-user {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 12px;
            background: #f1f5f9;
            border-radius: 8px;
        }
        
        .topbar-user-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: #3b82f6;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }
        
        .topbar-user-info { font-size: 14px; }
        .topbar-user-name { font-weight: 600; color: #1e293b; }
        .topbar-user-role { font-size: 12px; color: #64748b; }
        
        .btn-logout {
            padding: 8px 16px;
            background: #fee2e2;
            color: #dc2626;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            cursor: pointer;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        
        .btn-logout:hover { background: #fecaca; }
        
        /* Content */
        .admin-content { padding: 24px; }
        
        /* Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 24px;
        }
        
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        
        .stat-card-header { display: flex; justify-content: space-between; align-items: flex-start; }
        .stat-card-icon {
            width: 48px;
            height: 48px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }
        
        .stat-card-icon.blue { background: #dbeafe; color: #2563eb; }
        .stat-card-icon.green { background: #dcfce7; color: #16a34a; }
        .stat-card-icon.yellow { background: #fef3c7; color: #d97706; }
        .stat-card-icon.red { background: #fee2e2; color: #dc2626; }
        .stat-card-icon.purple { background: #f3e8ff; color: #7c3aed; }
        
        .stat-card-value { font-size: 32px; font-weight: 700; color: #1e293b; margin: 12px 0 4px; }
        .stat-card-label { font-size: 14px; color: #64748b; }
        .stat-card-change { font-size: 12px; margin-top: 8px; }
        .stat-card-change.up { color: #16a34a; }
        .stat-card-change.down { color: #dc2626; }
        
        /* Card/Panel */
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            margin-bottom: 24px;
        }
        
        .card-header {
            padding: 20px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-title { font-size: 18px; font-weight: 600; color: #1e293b; }
        .card-body { padding: 24px; }
        .card-footer { padding: 16px 24px; border-top: 1px solid #e2e8f0; background: #f8fafc; }
        
        /* Tables */
        .table-responsive { overflow-x: auto; }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 12px 16px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }
        
        th {
            background: #f8fafc;
            font-weight: 600;
            font-size: 13px;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        td { font-size: 14px; color: #334155; }
        
        tr:hover { background: #f8fafc; }
        
        /* Badges */
        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .badge-success { background: #dcfce7; color: #166534; }
        .badge-warning { background: #fef3c7; color: #92400e; }
        .badge-danger { background: #fee2e2; color: #991b1b; }
        .badge-info { background: #dbeafe; color: #1e40af; }
        .badge-gray { background: #f1f5f9; color: #475569; }
        
        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            border: none;
            text-decoration: none;
            transition: all 0.2s;
        }
        
        .btn-primary { background: #3b82f6; color: white; }
        .btn-primary:hover { background: #2563eb; }
        
        .btn-success { background: #16a34a; color: white; }
        .btn-success:hover { background: #15803d; }
        
        .btn-danger { background: #dc2626; color: white; }
        .btn-danger:hover { background: #b91c1c; }
        
        .btn-outline { background: white; border: 1px solid #e2e8f0; color: #475569; }
        .btn-outline:hover { background: #f8fafc; }
        
        .btn-sm { padding: 6px 12px; font-size: 13px; }
        
        /* Forms */
        .form-group { margin-bottom: 20px; }
        .form-label { display: block; font-size: 14px; font-weight: 500; color: #374151; margin-bottom: 6px; }
        .form-input, .form-select, .form-textarea {
            width: 100%;
            padding: 10px 14px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-size: 14px;
        }
        
        .form-input:focus, .form-select:focus, .form-textarea:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        /* Grid */
        .grid-2 { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; }
        .grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
        
        /* Actions */
        .actions { display: flex; gap: 8px; }
        
        /* Alert */
        .alert {
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .alert-success { background: #dcfce7; color: #166534; border: 1px solid #86efac; }
        .alert-warning { background: #fef3c7; color: #92400e; border: 1px solid #fde68a; }
        .alert-danger { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
        .alert-info { background: #dbeafe; color: #1e40af; border: 1px solid #93c5fd; }
        
        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 48px;
            color: #64748b;
        }
        
        .empty-state-icon { font-size: 48px; margin-bottom: 16px; opacity: 0.5; }
        .empty-state-title { font-size: 18px; font-weight: 600; color: #475569; margin-bottom: 8px; }
        
        /* Quick actions */
        .quick-actions { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 24px; }
        
        /* Mobile */
        @media (max-width: 1024px) {
            .admin-sidebar { transform: translateX(-100%); transition: transform 0.3s; }
            .admin-sidebar.open { transform: translateX(0); }
            .admin-main { margin-left: 0; }
            .grid-2, .grid-3 { grid-template-columns: 1fr; }
        }
        
        /* Pagination */
        .pagination { display: flex; gap: 4px; justify-content: center; padding: 20px 0; }
        .pagination a, .pagination span {
            padding: 8px 14px;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            font-size: 14px;
            text-decoration: none;
            color: #475569;
        }
        .pagination a:hover { background: #f1f5f9; }
        .pagination .active { background: #3b82f6; color: white; border-color: #3b82f6; }
        
        /* Search */
        .search-box {
            display: flex;
            gap: 12px;
            margin-bottom: 20px;
        }
        
        .search-input {
            flex: 1;
            padding: 10px 14px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-size: 14px;
        }
        
        /* Tab navigation */
        .tabs { display: flex; gap: 4px; border-bottom: 1px solid #e2e8f0; margin-bottom: 20px; }
        .tab {
            padding: 12px 20px;
            font-size: 14px;
            font-weight: 500;
            color: #64748b;
            text-decoration: none;
            border-bottom: 2px solid transparent;
            margin-bottom: -1px;
        }
        .tab:hover { color: #1e293b; }
        .tab.active { color: #3b82f6; border-bottom-color: #3b82f6; }
        
        /* Avatar */
        .avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #e2e8f0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: #64748b;
            font-size: 14px;
        }
        
        /* Link back to site */
        .back-to-site {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 12px 20px;
            color: #94a3b8;
            text-decoration: none;
            font-size: 13px;
            border-top: 1px solid rgba(255,255,255,0.1);
            margin-top: auto;
        }
        .back-to-site:hover { color: white; background: rgba(255,255,255,0.05); }
    </style>
</head>
<body>
    <div class="admin-layout">
        <!-- Sidebar -->
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <a href="<?= url('admin') ?>" class="sidebar-logo"><?= e(Config::SITE_NAME) ?></a>
                <div class="sidebar-subtitle">Painel Administrativo</div>
            </div>
            
            <nav class="sidebar-menu">
                <div class="menu-section">Principal</div>
                <a href="<?= url('admin') ?>" class="menu-item <?= $activeMenu === 'dashboard' ? 'active' : '' ?>">
                    <span class="icon">📊</span> Dashboard
                </a>
                
                <div class="menu-section">Conteúdo</div>
                <a href="<?= url('admin/moderacao') ?>" class="menu-item <?= $activeMenu === 'moderacao' ? 'active' : '' ?>">
                    <span class="icon">⏳</span> Moderação
                    <?php if (isset($pendingPosts) && $pendingPosts > 0): ?>
                        <span class="badge"><?= $pendingPosts ?></span>
                    <?php endif; ?>
                </a>
                <a href="<?= url('admin/posts') ?>" class="menu-item <?= $activeMenu === 'posts' ? 'active' : '' ?>">
                    <span class="icon">📰</span> Posts
                </a>
                <a href="<?= url('admin/comentarios') ?>" class="menu-item <?= $activeMenu === 'comentarios' ? 'active' : '' ?>">
                    <span class="icon">💬</span> Comentários
                </a>
                <a href="<?= url('admin/categorias') ?>" class="menu-item <?= $activeMenu === 'categorias' ? 'active' : '' ?>">
                    <span class="icon">🏷️</span> Categorias
                </a>
                
                <div class="menu-section">Usuários</div>
                <a href="<?= url('admin/usuarios') ?>" class="menu-item <?= $activeMenu === 'usuarios' ? 'active' : '' ?>">
                    <span class="icon">👥</span> Usuários
                </a>
                <a href="<?= url('admin/autores') ?>" class="menu-item <?= $activeMenu === 'autores' ? 'active' : '' ?>">
                    <span class="icon">✍️</span> Autores
                </a>
                <a href="<?= url('admin/moderadores') ?>" class="menu-item <?= $activeMenu === 'moderadores' ? 'active' : '' ?>">
                    <span class="icon">🛡️</span> Moderadores
                </a>
                <a href="<?= url('admin/anunciantes') ?>" class="menu-item <?= $activeMenu === 'anunciantes' ? 'active' : '' ?>">
                    <span class="icon">📢</span> Anunciantes
                </a>
                
                <div class="menu-section">Localização</div>
                <a href="<?= url('admin/estados') ?>" class="menu-item <?= $activeMenu === 'estados' ? 'active' : '' ?>">
                    <span class="icon">🗺️</span> Estados
                </a>
                <a href="<?= url('admin/cidades') ?>" class="menu-item <?= $activeMenu === 'cidades' ? 'active' : '' ?>">
                    <span class="icon">🏙️</span> Cidades
                </a>
                <a href="<?= url('admin/bairros') ?>" class="menu-item <?= $activeMenu === 'bairros' ? 'active' : '' ?>">
                    <span class="icon">📍</span> Bairros
                </a>
                
                <div class="menu-section">Monetização</div>
                <a href="<?= url('admin/banners') ?>" class="menu-item <?= $activeMenu === 'banners' ? 'active' : '' ?>">
                    <span class="icon">🖼️</span> Banners
                </a>
                <a href="<?= url('admin/destaques') ?>" class="menu-item <?= $activeMenu === 'destaques' ? 'active' : '' ?>">
                    <span class="icon">⭐</span> Destaques
                </a>
                <a href="<?= url('admin/precos') ?>" class="menu-item <?= $activeMenu === 'precos' ? 'active' : '' ?>">
                    <span class="icon">💰</span> Preços
                </a>
                
                <div class="menu-section">Sistema</div>
                <a href="<?= url('admin/paginas') ?>" class="menu-item <?= $activeMenu === 'paginas' ? 'active' : '' ?>">
                    <span class="icon">📄</span> Páginas
                </a>
                <a href="<?= url('admin/configuracoes') ?>" class="menu-item <?= $activeMenu === 'configuracoes' ? 'active' : '' ?>">
                    <span class="icon">⚙️</span> Configurações
                </a>
                <a href="<?= url('admin/relatorios') ?>" class="menu-item <?= $activeMenu === 'relatorios' ? 'active' : '' ?>">
                    <span class="icon">📈</span> Relatórios
                </a>
            </nav>
            
            <a href="<?= url('/') ?>" class="back-to-site">
                <span>←</span> Voltar ao site
            </a>
        </aside>
        
        <!-- Main -->
        <main class="admin-main">
            <header class="admin-topbar">
                <h1 class="topbar-title"><?= e($pageTitle) ?></h1>
                
                <div class="topbar-actions">
                    <div class="topbar-user">
                        <div class="topbar-user-avatar">
                            <?= strtoupper(substr($_SESSION['user_nome'] ?? 'A', 0, 1)) ?>
                        </div>
                        <div class="topbar-user-info">
                            <div class="topbar-user-name"><?= e($_SESSION['user_nome'] ?? 'Admin') ?></div>
                            <div class="topbar-user-role">Administrador</div>
                        </div>
                    </div>
                    <a href="<?= url('logout') ?>" class="btn-logout">
                        🚪 Sair
                    </a>
                </div>
            </header>
            
            <div class="admin-content">
                <?= $content ?? '' ?>
            </div>
        </main>
    </div>
    
    <script>
        // Base URL para AJAX
        window.ACF = {
            baseUrl: '<?= Config::getBaseUrl() ?>',
            apiUrl: '<?= Config::getBaseUrl() ?>/api'
        };
    </script>
</body>
</html>
