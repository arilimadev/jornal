<?php
/**
 * A Cidade Fala v2.0 - Editor de Páginas Institucionais
 */

use ACidadeFala\Config\Config;

$pageTitle = "Páginas Institucionais";
$activeMenu = "paginas";

ob_start();
?>

<div class="quick-actions">
    <button class="btn btn-primary" onclick="abrirModalPagina()">➕ Nova Página</button>
</div>

<div class="grid-2" style="gap:24px;">
    <!-- Lista de Páginas -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">📄 Páginas</h3>
        </div>
        <div class="card-body" style="padding:0;">
            <div class="page-list">
                <?php foreach ($paginas ?? [] as $pagina): ?>
                <div class="page-item <?= ($paginaAtual['id'] ?? 0) == $pagina['id'] ? 'active' : '' ?>" onclick="selecionarPagina(<?= htmlspecialchars(json_encode($pagina)) ?>)">
                    <div class="page-item-icon">📄</div>
                    <div class="page-item-info">
                        <div class="page-item-title"><?= e($pagina['titulo']) ?></div>
                        <div class="page-item-slug">/<?= e($pagina['slug']) ?></div>
                    </div>
                    <div class="page-item-status">
                        <?php if ($pagina['ativo']): ?>
                            <span class="badge badge-success">Ativo</span>
                        <?php else: ?>
                            <span class="badge badge-gray">Inativo</span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    
    <!-- Editor -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title" id="editorTitle">✏️ Editor</h3>
            <div id="editorActions" style="display:none;">
                <button class="btn btn-sm btn-outline" onclick="previewPagina()">👁️ Preview</button>
                <button class="btn btn-sm btn-primary" onclick="salvarPagina()">💾 Salvar</button>
            </div>
        </div>
        <div class="card-body" id="editorArea">
            <div class="empty-state">
                <div class="empty-state-icon">📄</div>
                <div class="empty-state-title">Selecione uma página</div>
                <p>Clique em uma página para editar seu conteúdo</p>
            </div>
        </div>
    </div>
</div>

<!-- Modal Nova Página -->
<div class="modal" id="modalPagina">
    <div class="modal-content">
        <div class="modal-header">
            <h3>➕ Nova Página</h3>
            <button class="modal-close" onclick="fecharModal('modalPagina')">✕</button>
        </div>
        <form id="novaPaginaForm">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Título *</label>
                    <input type="text" name="titulo" class="form-input" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Slug (URL) *</label>
                    <input type="text" name="slug" class="form-input" required placeholder="ex: sobre-nos">
                    <small style="color:#64748b;">Apenas letras minúsculas, números e hífens</small>
                </div>
                <div class="form-group">
                    <label class="form-label">Meta Description</label>
                    <input type="text" name="meta_description" class="form-input" maxlength="160" placeholder="Descrição para SEO">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="fecharModal('modalPagina')">Cancelar</button>
                <button type="submit" class="btn btn-primary">Criar Página</button>
            </div>
        </form>
    </div>
</div>

<!-- Quill CSS -->
<link href="https://cdn.quilljs.com/1.3.7/quill.snow.css" rel="stylesheet">

<style>
.page-list { max-height: 500px; overflow-y: auto; }

.page-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 16px 20px;
    border-bottom: 1px solid #e2e8f0;
    cursor: pointer;
    transition: all 0.2s;
}

.page-item:hover { background: #f8fafc; }
.page-item.active { background: #eff6ff; border-left: 3px solid #3b82f6; }

.page-item-icon { font-size: 24px; }
.page-item-info { flex: 1; }
.page-item-title { font-weight: 600; margin-bottom: 2px; }
.page-item-slug { font-size: 12px; color: #64748b; }

.editor-form { display: flex; flex-direction: column; gap: 16px; }

#quillEditor { height: 350px; border: 1px solid #d1d5db; border-radius: 8px; }

.ql-toolbar.ql-snow { border: none; border-bottom: 1px solid #e2e8f0; background: #f8fafc; border-radius: 8px 8px 0 0; }
.ql-container.ql-snow { border: none; border-radius: 0 0 8px 8px; }

.modal { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.6); z-index: 1000; align-items: center; justify-content: center; padding: 20px; }
.modal.show { display: flex; }
.modal-content { background: white; border-radius: 12px; max-width: 500px; width: 100%; }
.modal-header { padding: 20px 24px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; }
.modal-header h3 { margin: 0; }
.modal-close { background: none; border: none; font-size: 20px; cursor: pointer; }
.modal-body { padding: 24px; }
.modal-footer { padding: 16px 24px; border-top: 1px solid #e2e8f0; display: flex; gap: 12px; justify-content: flex-end; }
</style>

<!-- Quill JS -->
<script src="https://cdn.quilljs.com/1.3.7/quill.min.js"></script>

<script>
let quill = null;
let paginaAtual = null;

function selecionarPagina(pagina) {
    paginaAtual = pagina;
    
    // Atualizar lista
    document.querySelectorAll('.page-item').forEach(item => item.classList.remove('active'));
    event.currentTarget.classList.add('active');
    
    // Mostrar editor
    document.getElementById('editorTitle').textContent = '✏️ ' + pagina.titulo;
    document.getElementById('editorActions').style.display = 'flex';
    
    document.getElementById('editorArea').innerHTML = `
        <div class="editor-form">
            <input type="hidden" id="paginaId" value="${pagina.id}">
            
            <div class="form-group">
                <label class="form-label">Título</label>
                <input type="text" id="paginaTitulo" class="form-input" value="${pagina.titulo}">
            </div>
            
            <div class="form-group">
                <label class="form-label">Slug</label>
                <input type="text" id="paginaSlug" class="form-input" value="${pagina.slug}" readonly style="background:#f1f5f9;">
            </div>
            
            <div class="form-group">
                <label class="form-label">Meta Description</label>
                <input type="text" id="paginaMeta" class="form-input" value="${pagina.meta_description || ''}" maxlength="160">
            </div>
            
            <div class="form-group">
                <label class="form-label">Conteúdo</label>
                <div id="quillEditor"></div>
            </div>
            
            <div class="form-group">
                <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                    <input type="checkbox" id="paginaAtiva" ${pagina.ativo ? 'checked' : ''}>
                    Página ativa
                </label>
            </div>
        </div>
    `;
    
    // Inicializar Quill
    quill = new Quill('#quillEditor', {
        theme: 'snow',
        modules: {
            toolbar: [
                [{ 'header': [1, 2, 3, false] }],
                ['bold', 'italic', 'underline'],
                [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                ['link', 'image'],
                ['clean']
            ]
        }
    });
    
    quill.root.innerHTML = pagina.conteudo || '';
}

async function salvarPagina() {
    if (!paginaAtual) return;
    
    const dados = {
        id: paginaAtual.id,
        titulo: document.getElementById('paginaTitulo').value,
        meta_description: document.getElementById('paginaMeta').value,
        conteudo: quill.root.innerHTML,
        ativo: document.getElementById('paginaAtiva').checked
    };
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/pagina/${paginaAtual.id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(dados)
        });
        const data = await res.json();
        
        if (data.success) {
            alert('✅ Página salva!');
            location.reload();
        } else {
            alert(data.error || 'Erro ao salvar');
        }
    } catch (e) {
        alert('Erro de conexão');
    }
}

function previewPagina() {
    if (!paginaAtual) return;
    window.open(`<?= url('/') ?>${paginaAtual.slug}`, '_blank');
}

function abrirModalPagina() {
    document.getElementById('modalPagina').classList.add('show');
}

function fecharModal(id) {
    document.getElementById(id).classList.remove('show');
}

document.getElementById('novaPaginaForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/pagina`, {
            method: 'POST',
            body: formData
        });
        const data = await res.json();
        
        if (data.success) {
            location.reload();
        } else {
            alert(data.error || 'Erro ao criar página');
        }
    } catch (e) {
        alert('Erro de conexão');
    }
});

document.getElementById('modalPagina').addEventListener('click', e => {
    if (e.target.id === 'modalPagina') fecharModal('modalPagina');
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
