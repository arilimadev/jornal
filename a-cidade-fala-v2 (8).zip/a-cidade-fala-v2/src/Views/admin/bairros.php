<?php
/**
 * A Cidade Fala v2.0 - Gerenciar Bairros
 */

use ACidadeFala\Config\Config;

$pageTitle = "Gerenciar Bairros";
$activeMenu = "bairros";

$cidadeIdFiltro = $_GET['cidade_id'] ?? '';

ob_start();
?>

<div class="quick-actions">
    <button class="btn btn-primary" onclick="abrirModalBairro()">➕ Novo Bairro</button>
    <a href="<?= url('admin/estados') ?>" class="btn btn-outline">🗺️ Estados</a>
    <a href="<?= url('admin/cidades') ?>" class="btn btn-outline">🏙️ Cidades</a>
</div>

<!-- Filtros -->
<div class="card" style="margin-bottom:20px;">
    <div class="card-body" style="padding:16px 24px;">
        <form class="search-box" method="GET">
            <select name="estado_id" class="form-select" style="width:200px;" onchange="carregarCidadesFiltro(this.value)">
                <option value="">Todos os estados</option>
                <?php foreach ($estados ?? [] as $estado): ?>
                    <option value="<?= $estado['id'] ?>" <?= ($_GET['estado_id'] ?? '') == $estado['id'] ? 'selected' : '' ?>>
                        <?= e($estado['nome']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <select name="cidade_id" id="cidadeFiltro" class="form-select" style="width:200px;">
                <option value="">Todas as cidades</option>
                <?php foreach ($cidades ?? [] as $cidade): ?>
                    <option value="<?= $cidade['id'] ?>" <?= $cidadeIdFiltro == $cidade['id'] ? 'selected' : '' ?>>
                        <?= e($cidade['nome']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <input type="text" name="busca" class="search-input" placeholder="Buscar bairro..." value="<?= e($_GET['busca'] ?? '') ?>">
            <button type="submit" class="btn btn-primary">🔍 Filtrar</button>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">📍 Bairros Cadastrados (<?= count($bairros ?? []) ?>)</h3>
    </div>
    
    <?php if (!empty($bairros)): ?>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Bairro</th>
                    <th>Cidade</th>
                    <th>Estado</th>
                    <th>Slug</th>
                    <th>Posts</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($bairros as $bairro): ?>
                <tr id="bairro-row-<?= $bairro['id'] ?>">
                    <td><strong><?= e($bairro['nome']) ?></strong></td>
                    <td><?= e($bairro['cidade_nome'] ?? 'N/A') ?></td>
                    <td><span class="badge badge-info"><?= e($bairro['estado_uf'] ?? '') ?></span></td>
                    <td><code style="font-size:12px;background:#f1f5f9;padding:2px 8px;border-radius:4px;"><?= e($bairro['slug']) ?></code></td>
                    <td><?= $bairro['total_posts'] ?? 0 ?></td>
                    <td>
                        <?php if ($bairro['ativo']): ?>
                            <span class="badge badge-success">Ativo</span>
                        <?php else: ?>
                            <span class="badge badge-danger">Inativo</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="actions">
                            <button class="btn btn-sm btn-outline" onclick="editarBairro(<?= htmlspecialchars(json_encode($bairro)) ?>)">✏️</button>
                            <button class="btn btn-sm btn-danger" onclick="excluirBairro(<?= $bairro['id'] ?>)">🗑️</button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="card-body">
        <div class="empty-state">
            <div class="empty-state-icon">📍</div>
            <div class="empty-state-title">Nenhum bairro encontrado</div>
            <p>Cadastre o primeiro bairro</p>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Modal Bairro -->
<div class="modal" id="modalBairro">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalBairroTitle">➕ Novo Bairro</h3>
            <button class="modal-close" onclick="fecharModal('modalBairro')">✕</button>
        </div>
        <form id="bairroForm">
            <div class="modal-body">
                <input type="hidden" name="id" id="bairroId">
                
                <div class="form-group">
                    <label class="form-label">Estado *</label>
                    <select name="estado_id" id="bairroEstado" class="form-select" required onchange="carregarCidadesBairro(this.value)">
                        <option value="">Selecione...</option>
                        <?php foreach ($estados ?? [] as $estado): ?>
                            <option value="<?= $estado['id'] ?>"><?= e($estado['nome']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Cidade *</label>
                    <select name="cidade_id" id="bairroCidade" class="form-select" required>
                        <option value="">Selecione o estado primeiro</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Nome do Bairro *</label>
                    <input type="text" name="nome" id="bairroNome" class="form-input" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Slug (URL)</label>
                    <input type="text" name="slug" id="bairroSlug" class="form-input" placeholder="gerado-automaticamente">
                </div>
                
                <div class="form-group">
                    <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                        <input type="checkbox" name="ativo" id="bairroAtivo" value="1" checked>
                        Bairro ativo
                    </label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="fecharModal('modalBairro')">Cancelar</button>
                <button type="submit" class="btn btn-primary">💾 Salvar</button>
            </div>
        </form>
    </div>
</div>

<style>
.modal { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.6); z-index: 1000; align-items: center; justify-content: center; padding: 20px; }
.modal.show { display: flex; }
.modal-content { background: white; border-radius: 12px; max-width: 500px; width: 100%; }
.modal-header { padding: 20px 24px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; }
.modal-header h3 { margin: 0; }
.modal-close { background: none; border: none; font-size: 20px; cursor: pointer; }
.modal-body { padding: 24px; }
.modal-footer { padding: 16px 24px; border-top: 1px solid #e2e8f0; display: flex; gap: 12px; justify-content: flex-end; }
</style>

<script>
function abrirModalBairro() {
    document.getElementById('modalBairroTitle').textContent = '➕ Novo Bairro';
    document.getElementById('bairroForm').reset();
    document.getElementById('bairroId').value = '';
    document.getElementById('bairroCidade').innerHTML = '<option value="">Selecione o estado primeiro</option>';
    document.getElementById('modalBairro').classList.add('show');
}

function editarBairro(bairro) {
    document.getElementById('modalBairroTitle').textContent = '✏️ Editar Bairro';
    document.getElementById('bairroId').value = bairro.id;
    document.getElementById('bairroEstado').value = bairro.estado_id || '';
    document.getElementById('bairroNome').value = bairro.nome;
    document.getElementById('bairroSlug').value = bairro.slug;
    document.getElementById('bairroAtivo').checked = bairro.ativo;
    
    if (bairro.estado_id) {
        carregarCidadesBairro(bairro.estado_id, bairro.cidade_id);
    }
    
    document.getElementById('modalBairro').classList.add('show');
}

function fecharModal(id) {
    document.getElementById(id).classList.remove('show');
}

async function carregarCidadesBairro(estadoId, cidadeSelecionada = null) {
    const select = document.getElementById('bairroCidade');
    select.innerHTML = '<option value="">Carregando...</option>';
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/cidades?estado_id=${estadoId}`);
        const data = await res.json();
        
        select.innerHTML = '<option value="">Selecione a cidade</option>';
        if (data.success && data.cidades) {
            data.cidades.forEach(c => {
                const selected = cidadeSelecionada == c.id ? 'selected' : '';
                select.innerHTML += `<option value="${c.id}" ${selected}>${c.nome}</option>`;
            });
        }
    } catch (e) {
        select.innerHTML = '<option value="">Erro ao carregar</option>';
    }
}

async function carregarCidadesFiltro(estadoId) {
    const select = document.getElementById('cidadeFiltro');
    if (!estadoId) {
        select.innerHTML = '<option value="">Todas as cidades</option>';
        return;
    }
    
    select.innerHTML = '<option value="">Carregando...</option>';
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/cidades?estado_id=${estadoId}`);
        const data = await res.json();
        
        select.innerHTML = '<option value="">Todas as cidades</option>';
        if (data.success && data.cidades) {
            data.cidades.forEach(c => {
                select.innerHTML += `<option value="${c.id}">${c.nome}</option>`;
            });
        }
    } catch (e) {}
}

document.getElementById('bairroForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    const id = formData.get('id');
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/bairro${id ? '/' + id : ''}`, {
            method: id ? 'PUT' : 'POST',
            body: formData
        });
        const data = await res.json();
        if (data.success) location.reload();
        else alert(data.error || 'Erro ao salvar');
    } catch (e) { alert('Erro de conexão'); }
});

async function excluirBairro(id) {
    if (!confirm('Excluir este bairro?')) return;
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/bairro/${id}`, { method: 'DELETE' });
        const data = await res.json();
        if (data.success) document.getElementById(`bairro-row-${id}`)?.remove();
        else alert(data.error || 'Erro ao excluir');
    } catch (e) { alert('Erro de conexão'); }
}

document.getElementById('modalBairro').addEventListener('click', e => {
    if (e.target.id === 'modalBairro') fecharModal('modalBairro');
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
