<?php
/**
 * A Cidade Fala v2.0 - Gerenciar Estados
 */

use ACidadeFala\Config\Config;

$pageTitle = "Gerenciar Estados";
$activeMenu = "estados";

ob_start();
?>

<div class="quick-actions">
    <button class="btn btn-primary" onclick="abrirModalEstado()">➕ Novo Estado</button>
    <a href="<?= url('admin/cidades') ?>" class="btn btn-outline">🏙️ Cidades</a>
    <a href="<?= url('admin/bairros') ?>" class="btn btn-outline">📍 Bairros</a>
</div>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">🗺️ Estados do Brasil</h3>
    </div>
    
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Estado</th>
                    <th>UF</th>
                    <th>Cidades</th>
                    <th>Posts</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($estados ?? [] as $estado): ?>
                <tr id="estado-row-<?= $estado['id'] ?>">
                    <td><strong><?= e($estado['nome']) ?></strong></td>
                    <td><span class="badge badge-info"><?= e($estado['uf']) ?></span></td>
                    <td><?= $estado['total_cidades'] ?? 0 ?></td>
                    <td><?= $estado['total_posts'] ?? 0 ?></td>
                    <td>
                        <?php if ($estado['ativo']): ?>
                            <span class="badge badge-success">Ativo</span>
                        <?php else: ?>
                            <span class="badge badge-danger">Inativo</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="actions">
                            <button class="btn btn-sm btn-outline" onclick="editarEstado(<?= htmlspecialchars(json_encode($estado)) ?>)">✏️</button>
                            <a href="<?= url('admin/cidades?estado_id=' . $estado['id']) ?>" class="btn btn-sm btn-outline" title="Ver Cidades">🏙️</a>
                            <?php if ($estado['ativo']): ?>
                                <button class="btn btn-sm btn-danger" onclick="toggleEstado(<?= $estado['id'] ?>, false)">🚫</button>
                            <?php else: ?>
                                <button class="btn btn-sm btn-success" onclick="toggleEstado(<?= $estado['id'] ?>, true)">✓</button>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Estado -->
<div class="modal" id="modalEstado">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalEstadoTitle">➕ Novo Estado</h3>
            <button class="modal-close" onclick="fecharModal('modalEstado')">✕</button>
        </div>
        <form id="estadoForm">
            <div class="modal-body">
                <input type="hidden" name="id" id="estadoId">
                
                <div class="form-group">
                    <label class="form-label">Nome do Estado *</label>
                    <input type="text" name="nome" id="estadoNome" class="form-input" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">UF (Sigla) *</label>
                    <input type="text" name="uf" id="estadoUf" class="form-input" required maxlength="2" style="text-transform:uppercase;width:100px;">
                </div>
                
                <div class="form-group">
                    <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                        <input type="checkbox" name="ativo" id="estadoAtivo" value="1" checked>
                        Estado ativo
                    </label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="fecharModal('modalEstado')">Cancelar</button>
                <button type="submit" class="btn btn-primary">💾 Salvar</button>
            </div>
        </form>
    </div>
</div>

<style>
.modal { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.6); z-index: 1000; align-items: center; justify-content: center; padding: 20px; }
.modal.show { display: flex; }
.modal-content { background: white; border-radius: 12px; max-width: 500px; width: 100%; }
.modal-header { padding: 20px 24px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; }
.modal-header h3 { margin: 0; }
.modal-close { background: none; border: none; font-size: 20px; cursor: pointer; color: #64748b; }
.modal-body { padding: 24px; }
.modal-footer { padding: 16px 24px; border-top: 1px solid #e2e8f0; display: flex; gap: 12px; justify-content: flex-end; }
</style>

<script>
function abrirModalEstado() {
    document.getElementById('modalEstadoTitle').textContent = '➕ Novo Estado';
    document.getElementById('estadoForm').reset();
    document.getElementById('estadoId').value = '';
    document.getElementById('modalEstado').classList.add('show');
}

function editarEstado(estado) {
    document.getElementById('modalEstadoTitle').textContent = '✏️ Editar Estado';
    document.getElementById('estadoId').value = estado.id;
    document.getElementById('estadoNome').value = estado.nome;
    document.getElementById('estadoUf').value = estado.uf;
    document.getElementById('estadoAtivo').checked = estado.ativo;
    document.getElementById('modalEstado').classList.add('show');
}

function fecharModal(id) {
    document.getElementById(id).classList.remove('show');
}

document.getElementById('estadoForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    const id = formData.get('id');
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/estado${id ? '/' + id : ''}`, {
            method: id ? 'PUT' : 'POST',
            body: formData
        });
        const data = await res.json();
        if (data.success) location.reload();
        else alert(data.error || 'Erro ao salvar');
    } catch (e) { alert('Erro de conexão'); }
});

async function toggleEstado(id, ativar) {
    if (!confirm(`${ativar ? 'Ativar' : 'Desativar'} este estado?`)) return;
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/estado/${id}/${ativar ? 'ativar' : 'desativar'}`, { method: 'POST' });
        const data = await res.json();
        if (data.success) location.reload();
        else alert(data.error || 'Erro');
    } catch (e) { alert('Erro de conexão'); }
}

document.getElementById('modalEstado').addEventListener('click', e => {
    if (e.target.id === 'modalEstado') fecharModal('modalEstado');
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
