<?php
/**
 * A Cidade Fala v2.0 - Relatórios
 */

use ACidadeFala\Config\Config;

$pageTitle = "Relatórios";
$activeMenu = "relatorios";

ob_start();
?>

<style>
.report-filters {
    display: flex;
    gap: 16px;
    flex-wrap: wrap;
    margin-bottom: 24px;
    padding: 20px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.report-card {
    background: white;
    border-radius: 12px;
    padding: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    margin-bottom: 24px;
}

.report-card-title {
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.chart-container {
    height: 300px;
    position: relative;
}

.metric-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}

.metric-item {
    background: white;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    text-align: center;
}

.metric-value {
    font-size: 32px;
    font-weight: 700;
    margin-bottom: 4px;
}

.metric-value.green { color: #16a34a; }
.metric-value.blue { color: #2563eb; }
.metric-value.purple { color: #7c3aed; }
.metric-value.orange { color: #ea580c; }

.metric-label {
    font-size: 14px;
    color: #64748b;
}

.metric-change {
    font-size: 12px;
    margin-top: 8px;
}

.metric-change.up { color: #16a34a; }
.metric-change.down { color: #dc2626; }

.top-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.top-list-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 0;
    border-bottom: 1px solid #e2e8f0;
}

.top-list-item:last-child { border-bottom: none; }

.top-list-rank {
    width: 28px;
    height: 28px;
    background: #f1f5f9;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    font-size: 12px;
}

.top-list-rank.gold { background: #fef3c7; color: #b45309; }
.top-list-rank.silver { background: #e2e8f0; color: #475569; }
.top-list-rank.bronze { background: #fed7aa; color: #c2410c; }

.top-list-info { flex: 1; }
.top-list-title { font-weight: 600; font-size: 14px; }
.top-list-subtitle { font-size: 12px; color: #64748b; }
.top-list-value { font-weight: 600; color: #3b82f6; }

.export-buttons {
    display: flex;
    gap: 8px;
    justify-content: flex-end;
    margin-bottom: 16px;
}
</style>

<!-- Filtros -->
<div class="report-filters">
    <div class="form-group" style="margin:0;">
        <label class="form-label">Período</label>
        <select id="periodo" class="form-select" onchange="atualizarRelatorios()">
            <option value="7">Últimos 7 dias</option>
            <option value="30" selected>Últimos 30 dias</option>
            <option value="90">Últimos 90 dias</option>
            <option value="365">Último ano</option>
        </select>
    </div>
    <div class="form-group" style="margin:0;">
        <label class="form-label">Cidade</label>
        <select id="cidadeFiltro" class="form-select">
            <option value="">Todas</option>
            <?php foreach ($cidades ?? [] as $cidade): ?>
                <option value="<?= $cidade['id'] ?>"><?= e($cidade['nome']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div style="display:flex;align-items:flex-end;">
        <button class="btn btn-primary" onclick="atualizarRelatorios()">🔄 Atualizar</button>
    </div>
</div>

<!-- Métricas Principais -->
<div class="metric-grid">
    <div class="metric-item">
        <div class="metric-value blue"><?= number_format($stats['posts_periodo'] ?? 0) ?></div>
        <div class="metric-label">Posts Publicados</div>
        <div class="metric-change up">↑ <?= $stats['posts_variacao'] ?? 0 ?>% vs período anterior</div>
    </div>
    <div class="metric-item">
        <div class="metric-value green"><?= number_format($stats['visualizacoes_periodo'] ?? 0) ?></div>
        <div class="metric-label">Visualizações</div>
        <div class="metric-change up">↑ <?= $stats['views_variacao'] ?? 0 ?>%</div>
    </div>
    <div class="metric-item">
        <div class="metric-value purple"><?= number_format($stats['usuarios_novos'] ?? 0) ?></div>
        <div class="metric-label">Novos Usuários</div>
        <div class="metric-change up">↑ <?= $stats['usuarios_variacao'] ?? 0 ?>%</div>
    </div>
    <div class="metric-item">
        <div class="metric-value orange">R$ <?= number_format($stats['receita_periodo'] ?? 0, 2, ',', '.') ?></div>
        <div class="metric-label">Receita</div>
        <div class="metric-change up">↑ <?= $stats['receita_variacao'] ?? 0 ?>%</div>
    </div>
</div>

<div class="grid-2" style="gap:24px;">
    <!-- Posts por Categoria -->
    <div class="report-card">
        <h3 class="report-card-title">📊 Posts por Categoria</h3>
        <div class="chart-container">
            <canvas id="chartCategorias"></canvas>
        </div>
    </div>
    
    <!-- Posts por Dia -->
    <div class="report-card">
        <h3 class="report-card-title">📈 Publicações por Dia</h3>
        <div class="chart-container">
            <canvas id="chartDias"></canvas>
        </div>
    </div>
</div>

<div class="grid-2" style="gap:24px;">
    <!-- Top Posts -->
    <div class="report-card">
        <h3 class="report-card-title">🔥 Posts Mais Lidos</h3>
        <ul class="top-list">
            <?php foreach (array_slice($topPosts ?? [], 0, 10) as $i => $post): ?>
            <li class="top-list-item">
                <div class="top-list-rank <?= $i === 0 ? 'gold' : ($i === 1 ? 'silver' : ($i === 2 ? 'bronze' : '')) ?>">
                    <?= $i + 1 ?>
                </div>
                <div class="top-list-info">
                    <div class="top-list-title"><?= e(substr($post['titulo'], 0, 50)) ?></div>
                    <div class="top-list-subtitle"><?= e($post['cidade_nome'] ?? '') ?></div>
                </div>
                <div class="top-list-value"><?= number_format($post['visualizacoes']) ?></div>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
    
    <!-- Top Autores -->
    <div class="report-card">
        <h3 class="report-card-title">🏆 Top Autores</h3>
        <ul class="top-list">
            <?php foreach (array_slice($topAutores ?? [], 0, 10) as $i => $autor): ?>
            <li class="top-list-item">
                <div class="top-list-rank <?= $i === 0 ? 'gold' : ($i === 1 ? 'silver' : ($i === 2 ? 'bronze' : '')) ?>">
                    <?= $i + 1 ?>
                </div>
                <div class="top-list-info">
                    <div class="top-list-title"><?= e($autor['nome']) ?></div>
                    <div class="top-list-subtitle"><?= $autor['total_posts'] ?> posts</div>
                </div>
                <div class="top-list-value"><?= number_format($autor['total_visualizacoes']) ?> views</div>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
</div>

<div class="grid-2" style="gap:24px;">
    <!-- Top Cidades -->
    <div class="report-card">
        <h3 class="report-card-title">🏙️ Cidades Mais Ativas</h3>
        <ul class="top-list">
            <?php foreach (array_slice($topCidades ?? [], 0, 10) as $i => $cidade): ?>
            <li class="top-list-item">
                <div class="top-list-rank <?= $i === 0 ? 'gold' : ($i === 1 ? 'silver' : ($i === 2 ? 'bronze' : '')) ?>">
                    <?= $i + 1 ?>
                </div>
                <div class="top-list-info">
                    <div class="top-list-title"><?= e($cidade['nome']) ?></div>
                    <div class="top-list-subtitle"><?= e($cidade['estado_uf'] ?? '') ?></div>
                </div>
                <div class="top-list-value"><?= $cidade['total_posts'] ?> posts</div>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
    
    <!-- Receita por Mês -->
    <div class="report-card">
        <h3 class="report-card-title">💰 Receita Mensal</h3>
        <div class="chart-container">
            <canvas id="chartReceita"></canvas>
        </div>
    </div>
</div>

<!-- Export -->
<div class="export-buttons">
    <button class="btn btn-outline" onclick="exportarCSV()">📊 Exportar CSV</button>
    <button class="btn btn-outline" onclick="exportarPDF()">📄 Exportar PDF</button>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
// Dados para gráficos (viriam do backend)
const dadosCategorias = <?= json_encode($dadosCategorias ?? [
    ['Política', 45],
    ['Segurança', 38],
    ['Saúde', 25],
    ['Economia', 20],
    ['Cultura', 15]
]) ?>;

const dadosDias = <?= json_encode($dadosDias ?? [
    ['01/01', 5], ['02/01', 8], ['03/01', 12], ['04/01', 7], ['05/01', 15],
    ['06/01', 10], ['07/01', 9], ['08/01', 11], ['09/01', 14], ['10/01', 8]
]) ?>;

const dadosReceita = <?= json_encode($dadosReceita ?? [
    ['Jan', 1200], ['Fev', 1500], ['Mar', 1800], ['Abr', 2100],
    ['Mai', 1900], ['Jun', 2400]
]) ?>;

// Gráfico de Categorias
new Chart(document.getElementById('chartCategorias'), {
    type: 'doughnut',
    data: {
        labels: dadosCategorias.map(d => d[0]),
        datasets: [{
            data: dadosCategorias.map(d => d[1]),
            backgroundColor: ['#3b82f6', '#16a34a', '#f59e0b', '#8b5cf6', '#ec4899']
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { position: 'right' } }
    }
});

// Gráfico de Posts por Dia
new Chart(document.getElementById('chartDias'), {
    type: 'line',
    data: {
        labels: dadosDias.map(d => d[0]),
        datasets: [{
            label: 'Posts',
            data: dadosDias.map(d => d[1]),
            borderColor: '#3b82f6',
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            fill: true,
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } }
    }
});

// Gráfico de Receita
new Chart(document.getElementById('chartReceita'), {
    type: 'bar',
    data: {
        labels: dadosReceita.map(d => d[0]),
        datasets: [{
            label: 'Receita (R$)',
            data: dadosReceita.map(d => d[1]),
            backgroundColor: '#16a34a'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } }
    }
});

function atualizarRelatorios() {
    const periodo = document.getElementById('periodo').value;
    const cidade = document.getElementById('cidadeFiltro').value;
    window.location.href = `?periodo=${periodo}&cidade_id=${cidade}`;
}

function exportarCSV() {
    window.location.href = `${window.ACF.apiUrl}/admin/relatorios/csv?periodo=${document.getElementById('periodo').value}`;
}

function exportarPDF() {
    alert('Exportação PDF em desenvolvimento');
}
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
