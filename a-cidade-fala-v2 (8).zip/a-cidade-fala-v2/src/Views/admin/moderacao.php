<?php
/**
 * A Cidade Fala v2.0 - Moderação de Posts
 */

use ACidadeFala\Config\Config;

$pageTitle = "Moderação de Posts";
$activeMenu = "moderacao";

$pendingPosts = $pendingPosts ?? [];
$totalPending = count($pendingPosts);

ob_start();
?>

<!-- Filtros -->
<div class="card" style="margin-bottom:20px;">
    <div class="card-body" style="padding:16px 24px;">
        <form class="search-box" method="GET">
            <select name="tipo" class="form-select" style="width:150px;">
                <option value="">Todos os tipos</option>
                <option value="noticia" <?= ($_GET['tipo'] ?? '') === 'noticia' ? 'selected' : '' ?>>Notícias</option>
                <option value="opiniao" <?= ($_GET['tipo'] ?? '') === 'opiniao' ? 'selected' : '' ?>>Opiniões</option>
                <option value="denuncia" <?= ($_GET['tipo'] ?? '') === 'denuncia' ? 'selected' : '' ?>>Denúncias</option>
            </select>
            <select name="cidade_id" class="form-select" style="width:200px;">
                <option value="">Todas as cidades</option>
                <?php foreach ($cidades ?? [] as $cidade): ?>
                    <option value="<?= $cidade['id'] ?>" <?= ($_GET['cidade_id'] ?? '') == $cidade['id'] ? 'selected' : '' ?>>
                        <?= e($cidade['nome']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <input type="text" name="busca" class="search-input" placeholder="Buscar por título ou autor..." value="<?= e($_GET['busca'] ?? '') ?>">
            <button type="submit" class="btn btn-primary">🔍 Filtrar</button>
        </form>
    </div>
</div>

<!-- Stats -->
<div class="stats-grid" style="margin-bottom:24px;">
    <div class="stat-card">
        <div class="stat-card-header">
            <div>
                <div class="stat-card-value"><?= $totalPending ?></div>
                <div class="stat-card-label">Aguardando Moderação</div>
            </div>
            <div class="stat-card-icon yellow">⏳</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-card-header">
            <div>
                <div class="stat-card-value"><?= $stats['noticias_pendentes'] ?? 0 ?></div>
                <div class="stat-card-label">Notícias</div>
            </div>
            <div class="stat-card-icon blue">📰</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-card-header">
            <div>
                <div class="stat-card-value"><?= $stats['denuncias_pendentes'] ?? 0 ?></div>
                <div class="stat-card-label">Denúncias</div>
            </div>
            <div class="stat-card-icon red">🚨</div>
        </div>
    </div>
</div>

<!-- Lista de Posts -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">📋 Posts Pendentes</h3>
        <div style="display:flex;gap:8px;">
            <button class="btn btn-sm btn-success" onclick="aprovarSelecionados()">✓ Aprovar Selecionados</button>
            <button class="btn btn-sm btn-danger" onclick="rejeitarSelecionados()">✕ Rejeitar Selecionados</button>
        </div>
    </div>
    
    <?php if (!empty($pendingPosts)): ?>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th style="width:40px;"><input type="checkbox" id="selectAll" onchange="toggleSelectAll()"></th>
                    <th>Post</th>
                    <th>Tipo</th>
                    <th>Autor</th>
                    <th>Cidade</th>
                    <th>Data</th>
                    <th style="width:200px;">Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pendingPosts as $post): ?>
                <tr id="post-row-<?= $post['id'] ?>">
                    <td><input type="checkbox" class="post-checkbox" value="<?= $post['id'] ?>"></td>
                    <td>
                        <div style="display:flex;gap:12px;align-items:center;">
                            <?php if ($post['imagem_capa']): ?>
                                <img src="<?= upload($post['imagem_capa']) ?>" style="width:60px;height:45px;object-fit:cover;border-radius:6px;">
                            <?php else: ?>
                                <div style="width:60px;height:45px;background:#f1f5f9;border-radius:6px;display:flex;align-items:center;justify-content:center;color:#94a3b8;">📷</div>
                            <?php endif; ?>
                            <div>
                                <strong style="display:block;margin-bottom:2px;"><?= e($post['titulo']) ?></strong>
                                <small style="color:#64748b;"><?= e(substr($post['subtitulo'] ?? '', 0, 60)) ?></small>
                            </div>
                        </div>
                    </td>
                    <td>
                        <span class="badge badge-<?= $post['tipo'] === 'denuncia' ? 'danger' : ($post['tipo'] === 'opiniao' ? 'info' : 'gray') ?>">
                            <?= $post['tipo'] === 'noticia' ? '📰' : ($post['tipo'] === 'opiniao' ? '💭' : '🚨') ?>
                            <?= ucfirst($post['tipo']) ?>
                        </span>
                    </td>
                    <td>
                        <?php if ($post['anonimo']): ?>
                            <span style="color:#64748b;">🔒 Anônimo</span>
                        <?php else: ?>
                            <?= e($post['autor_nome'] ?? 'N/A') ?>
                        <?php endif; ?>
                    </td>
                    <td>
                        <small><?= e($post['cidade_nome'] ?? 'N/A') ?></small>
                        <br><small style="color:#94a3b8;"><?= e($post['estado_uf'] ?? '') ?></small>
                    </td>
                    <td>
                        <small><?= timeAgo($post['created_at']) ?></small>
                    </td>
                    <td>
                        <div class="actions">
                            <button class="btn btn-sm btn-outline" onclick="visualizarPost(<?= $post['id'] ?>)" title="Visualizar">👁️</button>
                            <button class="btn btn-sm btn-success" onclick="aprovarPost(<?= $post['id'] ?>)" title="Aprovar">✓</button>
                            <button class="btn btn-sm btn-danger" onclick="abrirModalRejeitar(<?= $post['id'] ?>)" title="Rejeitar">✕</button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="card-body">
        <div class="empty-state">
            <div class="empty-state-icon">✅</div>
            <div class="empty-state-title">Tudo em dia!</div>
            <p>Não há posts aguardando moderação</p>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Modal Visualizar Post -->
<div class="modal" id="modalVisualizarPost">
    <div class="modal-content modal-lg">
        <div class="modal-header">
            <h3>👁️ Visualizar Post</h3>
            <button class="modal-close" onclick="fecharModal('modalVisualizarPost')">✕</button>
        </div>
        <div class="modal-body" id="postPreviewContent">
            Carregando...
        </div>
        <div class="modal-footer">
            <button class="btn btn-outline" onclick="fecharModal('modalVisualizarPost')">Fechar</button>
            <button class="btn btn-danger" onclick="abrirModalRejeitar(postAtual)">Rejeitar</button>
            <button class="btn btn-success" onclick="aprovarPost(postAtual)">Aprovar</button>
        </div>
    </div>
</div>

<!-- Modal Rejeitar -->
<div class="modal" id="modalRejeitar">
    <div class="modal-content">
        <div class="modal-header">
            <h3>❌ Rejeitar Post</h3>
            <button class="modal-close" onclick="fecharModal('modalRejeitar')">✕</button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">Motivo da Rejeição</label>
                <select id="motivoRejeicao" class="form-select">
                    <option value="">Selecione um motivo...</option>
                    <option value="conteudo_inadequado">Conteúdo inadequado</option>
                    <option value="fake_news">Suspeita de fake news</option>
                    <option value="informacoes_insuficientes">Informações insuficientes</option>
                    <option value="duplicado">Conteúdo duplicado</option>
                    <option value="fora_escopo">Fora do escopo da cidade</option>
                    <option value="qualidade">Baixa qualidade de redação</option>
                    <option value="outro">Outro</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Observações (opcional)</label>
                <textarea id="observacoesRejeicao" class="form-textarea" rows="4" placeholder="Explique o motivo da rejeição para o autor..."></textarea>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-outline" onclick="fecharModal('modalRejeitar')">Cancelar</button>
            <button class="btn btn-danger" onclick="confirmarRejeicao()">Confirmar Rejeição</button>
        </div>
    </div>
</div>

<style>
.modal {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.6);
    z-index: 1000;
    align-items: center;
    justify-content: center;
    padding: 20px;
}
.modal.show { display: flex; }
.modal-content {
    background: white;
    border-radius: 12px;
    max-width: 500px;
    width: 100%;
    max-height: 90vh;
    display: flex;
    flex-direction: column;
}
.modal-lg { max-width: 800px; }
.modal-header {
    padding: 20px 24px;
    border-bottom: 1px solid #e2e8f0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.modal-header h3 { margin: 0; font-size: 18px; }
.modal-close {
    background: none;
    border: none;
    font-size: 20px;
    cursor: pointer;
    color: #64748b;
}
.modal-body {
    padding: 24px;
    overflow-y: auto;
    flex: 1;
}
.modal-footer {
    padding: 16px 24px;
    border-top: 1px solid #e2e8f0;
    display: flex;
    gap: 12px;
    justify-content: flex-end;
}
.post-preview-image {
    width: 100%;
    height: 200px;
    object-fit: cover;
    border-radius: 8px;
    margin-bottom: 16px;
}
.post-preview-content {
    line-height: 1.7;
    color: #374151;
}
</style>

<script>
let postAtual = null;
let postRejeitarId = null;

function toggleSelectAll() {
    const checked = document.getElementById('selectAll').checked;
    document.querySelectorAll('.post-checkbox').forEach(cb => cb.checked = checked);
}

async function visualizarPost(id) {
    postAtual = id;
    document.getElementById('modalVisualizarPost').classList.add('show');
    document.getElementById('postPreviewContent').innerHTML = '<div style="text-align:center;padding:40px;">Carregando...</div>';
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/post/${id}`);
        const data = await res.json();
        
        if (data.success && data.post) {
            const post = data.post;
            document.getElementById('postPreviewContent').innerHTML = `
                ${post.imagem_capa ? `<img src="${post.imagem_capa}" class="post-preview-image">` : ''}
                <span class="badge badge-info" style="margin-bottom:12px;">${post.tipo}</span>
                <h2 style="margin-bottom:8px;">${post.titulo}</h2>
                ${post.subtitulo ? `<p style="color:#64748b;margin-bottom:16px;">${post.subtitulo}</p>` : ''}
                <div style="display:flex;gap:16px;font-size:13px;color:#64748b;margin-bottom:20px;padding-bottom:16px;border-bottom:1px solid #e2e8f0;">
                    <span>👤 ${post.anonimo ? 'Anônimo' : post.autor_nome}</span>
                    <span>📍 ${post.cidade_nome}, ${post.estado_uf}</span>
                    <span>📅 ${post.created_at}</span>
                </div>
                <div class="post-preview-content">${post.conteudo}</div>
            `;
        }
    } catch (e) {
        document.getElementById('postPreviewContent').innerHTML = '<div style="color:red;">Erro ao carregar post</div>';
    }
}

function abrirModalRejeitar(id) {
    postRejeitarId = id;
    fecharModal('modalVisualizarPost');
    document.getElementById('modalRejeitar').classList.add('show');
}

function fecharModal(id) {
    document.getElementById(id).classList.remove('show');
}

async function aprovarPost(id) {
    if (!confirm('Aprovar este post?')) return;
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/post/${id}/aprovar`, { method: 'POST' });
        const data = await res.json();
        
        if (data.success) {
            document.getElementById(`post-row-${id}`)?.remove();
            fecharModal('modalVisualizarPost');
            showToast('Post aprovado com sucesso!', 'success');
        } else {
            alert(data.error || 'Erro ao aprovar');
        }
    } catch (e) {
        alert('Erro de conexão');
    }
}

async function confirmarRejeicao() {
    const motivo = document.getElementById('motivoRejeicao').value;
    const observacoes = document.getElementById('observacoesRejeicao').value;
    
    if (!motivo) {
        alert('Selecione um motivo para a rejeição');
        return;
    }
    
    try {
        const res = await fetch(`${window.ACF.apiUrl}/admin/post/${postRejeitarId}/rejeitar`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ motivo, observacoes })
        });
        const data = await res.json();
        
        if (data.success) {
            document.getElementById(`post-row-${postRejeitarId}`)?.remove();
            fecharModal('modalRejeitar');
            showToast('Post rejeitado', 'warning');
        } else {
            alert(data.error || 'Erro ao rejeitar');
        }
    } catch (e) {
        alert('Erro de conexão');
    }
}

async function aprovarSelecionados() {
    const ids = Array.from(document.querySelectorAll('.post-checkbox:checked')).map(cb => cb.value);
    if (ids.length === 0) {
        alert('Selecione pelo menos um post');
        return;
    }
    
    if (!confirm(`Aprovar ${ids.length} post(s)?`)) return;
    
    for (const id of ids) {
        await aprovarPost(id);
    }
}

async function rejeitarSelecionados() {
    const ids = Array.from(document.querySelectorAll('.post-checkbox:checked')).map(cb => cb.value);
    if (ids.length === 0) {
        alert('Selecione pelo menos um post');
        return;
    }
    alert('Para rejeitar múltiplos posts, use o botão individual para informar o motivo de cada um.');
}

function showToast(message, type) {
    const toast = document.createElement('div');
    toast.style.cssText = `position:fixed;bottom:20px;right:20px;padding:16px 24px;background:${type === 'success' ? '#16a34a' : '#d97706'};color:white;border-radius:8px;z-index:9999;`;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

// Fechar modal clicando fora
document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', e => {
        if (e.target === modal) fecharModal(modal.id);
    });
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/layout.php';
?>
