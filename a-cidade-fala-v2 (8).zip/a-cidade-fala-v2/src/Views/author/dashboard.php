<?php
/**
 * A Cidade Fala v2.0 - Dashboard do Autor
 */

use ACidadeFala\Config\Config;

$pageTitle = "Meu Painel";

ob_start();
?>

<style>
.dashboard-header {
    background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-dark) 100%);
    color: var(--color-white);
    padding: var(--space-8) 0;
    margin-bottom: var(--space-8);
}

.dashboard-header-content {
    display: flex;
    align-items: center;
    gap: var(--space-6);
}

.dashboard-avatar {
    width: 80px;
    height: 80px;
    border-radius: var(--radius-full);
    background: rgba(255,255,255,0.2);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: var(--text-3xl);
    font-weight: var(--font-bold);
}

.dashboard-welcome h1 {
    font-size: var(--text-2xl);
    margin-bottom: var(--space-2);
}

.dashboard-welcome p {
    opacity: 0.9;
}

.dashboard-actions {
    margin-left: auto;
}
</style>

<!-- Header do Dashboard -->
<div class="dashboard-header">
    <div class="container">
        <div class="dashboard-header-content">
            <div class="dashboard-avatar">
                <?= strtoupper(substr($user['nome'], 0, 1)) ?>
            </div>
            <div class="dashboard-welcome">
                <h1>Olá, <?= e(explode(' ', $user['nome'])[0]) ?>!</h1>
                <p>Bem-vindo ao seu painel de controle</p>
            </div>
            <div class="dashboard-actions">
                <a href="<?= url('autor/publicar') ?>" class="btn btn-secondary">
                    <i class="lucide-edit-3"></i> Nova Publicação
                </a>
            </div>
        </div>
    </div>
</div>

<div class="container">
    
    <!-- Estatísticas -->
    <div class="stats-grid" style="margin-bottom:var(--space-8);">
        <div class="stat-card">
            <div class="stat-card-icon blue">
                <i class="lucide-file-text"></i>
            </div>
            <div class="stat-card-value"><?= $stats['total_posts'] ?></div>
            <div class="stat-card-label">Total de Posts</div>
        </div>
        
        <div class="stat-card">
            <div class="stat-card-icon green">
                <i class="lucide-check-circle"></i>
            </div>
            <div class="stat-card-value"><?= $stats['posts_aprovados'] ?></div>
            <div class="stat-card-label">Aprovados</div>
        </div>
        
        <div class="stat-card">
            <div class="stat-card-icon orange">
                <i class="lucide-clock"></i>
            </div>
            <div class="stat-card-value"><?= $stats['posts_pendentes'] ?></div>
            <div class="stat-card-label">Pendentes</div>
        </div>
        
        <div class="stat-card">
            <div class="stat-card-icon red">
                <i class="lucide-eye"></i>
            </div>
            <div class="stat-card-value"><?= number_format($stats['total_views']) ?></div>
            <div class="stat-card-label">Visualizações</div>
        </div>
    </div>
    
    <!-- Grid de Conteúdo -->
    <div class="content-layout">
        
        <div class="content-main">
            <!-- Posts Recentes -->
            <div class="sidebar-widget" style="max-width:none;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--space-4);">
                    <h3 class="sidebar-widget-title" style="margin:0;border:none;padding:0;">
                        <i class="lucide-file-text"></i> Meus Posts Recentes
                    </h3>
                    <a href="<?= url('autor/posts') ?>" class="section-link">Ver todos <i class="lucide-arrow-right"></i></a>
                </div>
                
                <?php if (empty($recentPosts)): ?>
                <div style="text-align:center;padding:var(--space-8);background:var(--color-gray-50);border-radius:var(--radius-lg);">
                    <i class="lucide-file-plus" style="font-size:48px;color:var(--color-gray-400);margin-bottom:var(--space-4);display:block;"></i>
                    <h4 style="margin-bottom:var(--space-2);">Nenhum post ainda</h4>
                    <p style="color:var(--color-gray-500);margin-bottom:var(--space-4);">Comece a publicar conteúdo agora!</p>
                    <a href="<?= url('autor/publicar') ?>" class="btn btn-primary">
                        <i class="lucide-edit-3"></i> Criar Primeiro Post
                    </a>
                </div>
                <?php else: ?>
                <div class="table-container">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Título</th>
                                <th>Tipo</th>
                                <th>Status</th>
                                <th>Data</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentPosts as $post): ?>
                            <tr>
                                <td>
                                    <strong><?= e(mb_substr($post['titulo'], 0, 50)) ?><?= strlen($post['titulo']) > 50 ? '...' : '' ?></strong>
                                </td>
                                <td>
                                    <span class="badge badge-<?= $post['tipo'] ?>"><?= ucfirst($post['tipo']) ?></span>
                                </td>
                                <td>
                                    <?php
                                    $statusColors = [
                                        'pending' => 'warning',
                                        'approved' => 'success',
                                        'rejected' => 'error'
                                    ];
                                    $statusLabels = [
                                        'pending' => 'Pendente',
                                        'approved' => 'Aprovado',
                                        'rejected' => 'Rejeitado'
                                    ];
                                    ?>
                                    <span class="badge" style="background:var(--color-<?= $statusColors[$post['status']] ?>-bg);color:var(--color-<?= $statusColors[$post['status']] ?>);">
                                        <?= $statusLabels[$post['status']] ?>
                                    </span>
                                </td>
                                <td><?= formatDate($post['created_at'], 'd/m/Y') ?></td>
                                <td>
                                    <?php if ($post['status'] === 'approved'): ?>
                                    <a href="<?= url(($post['tipo'] ?? 'noticia') . '/' . $post['slug']) ?>" class="btn btn-ghost btn-sm" target="_blank">
                                        <i class="lucide-external-link"></i>
                                    </a>
                                    <?php elseif (in_array($post['status'], ['pending', 'rejected'])): ?>
                                    <a href="<?= url('autor/post/' . $post['id'] . '/editar') ?>" class="btn btn-ghost btn-sm">
                                        <i class="lucide-edit"></i>
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <aside class="sidebar">
            <!-- Ações Rápidas -->
            <div class="sidebar-widget">
                <h3 class="sidebar-widget-title">
                    <i class="lucide-zap"></i> Ações Rápidas
                </h3>
                <div style="display:flex;flex-direction:column;gap:var(--space-3);">
                    <a href="<?= url('autor/publicar') ?>" class="btn btn-primary btn-block">
                        <i class="lucide-plus"></i> Nova Notícia
                    </a>
                    <a href="<?= url('autor/posts?status=pending') ?>" class="btn btn-outline btn-block">
                        <i class="lucide-clock"></i> Posts Pendentes
                    </a>
                    <a href="<?= url('autor/perfil') ?>" class="btn btn-ghost btn-block">
                        <i class="lucide-user"></i> Meu Perfil
                    </a>
                </div>
            </div>
            
            <!-- Menu Lateral -->
            <div class="sidebar-widget">
                <h3 class="sidebar-widget-title">
                    <i class="lucide-menu"></i> Menu
                </h3>
                <nav style="display:flex;flex-direction:column;gap:var(--space-1);">
                    <a href="<?= url('autor/dashboard') ?>" style="padding:var(--space-3);border-radius:var(--radius-lg);background:var(--color-primary-50);color:var(--color-primary);font-weight:var(--font-medium);">
                        <i class="lucide-layout-dashboard"></i> Dashboard
                    </a>
                    <a href="<?= url('autor/posts') ?>" style="padding:var(--space-3);border-radius:var(--radius-lg);color:var(--color-gray-700);">
                        <i class="lucide-file-text"></i> Meus Posts
                    </a>
                    <a href="<?= url('autor/publicar') ?>" style="padding:var(--space-3);border-radius:var(--radius-lg);color:var(--color-gray-700);">
                        <i class="lucide-plus"></i> Publicar
                    </a>
                    <a href="<?= url('autor/comentarios') ?>" style="padding:var(--space-3);border-radius:var(--radius-lg);color:var(--color-gray-700);">
                        <i class="lucide-message-circle"></i> Comentários
                    </a>
                    <a href="<?= url('autor/destaques') ?>" style="padding:var(--space-3);border-radius:var(--radius-lg);color:var(--color-gray-700);">
                        <i class="lucide-star"></i> Destaques
                    </a>
                    <a href="<?= url('autor/perfil') ?>" style="padding:var(--space-3);border-radius:var(--radius-lg);color:var(--color-gray-700);">
                        <i class="lucide-user"></i> Meu Perfil
                    </a>
                </nav>
            </div>
            
            <!-- Dicas -->
            <div class="sidebar-widget" style="background:var(--color-info-bg);border-color:var(--color-info);">
                <h3 class="sidebar-widget-title" style="color:var(--color-info);border-bottom-color:var(--color-info);">
                    <i class="lucide-lightbulb"></i> Dica
                </h3>
                <p style="font-size:var(--text-sm);color:var(--color-info);">
                    Adicione imagens às suas publicações para aumentar o engajamento e torná-las mais atrativas!
                </p>
            </div>
        </aside>
        
    </div>
    
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../partials/layout.php';
?>
