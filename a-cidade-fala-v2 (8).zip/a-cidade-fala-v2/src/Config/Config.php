<?php
/**
 * A Cidade Fala v2.0 - Configurações Gerais
 * Portal de Jornalismo Colaborativo
 */

namespace ACidadeFala\Config;

class Config {
    // ========================================
    // CONFIGURAÇÃO DO SUBDIRETÓRIO
    // ========================================
    public const SUBDIR = '/jornal/a-cidade-fala'; // Caminho da subpasta
    
    // Configurações do Site
    public const SITE_NAME = 'A Cidade Fala';
    public const SITE_TAGLINE = 'O jornalismo independente da sua cidade';
    public const SITE_DESCRIPTION = 'Portal de notícias colaborativo e independente, focado em jornalismo local e cidadão.';
    public const SITE_KEYWORDS = 'notícias locais, jornalismo cidadão, denúncias, opinião, cidade';
    
    // Versão do Sistema
    public const VERSION = '2.0.0';
    
    // URL Base (será definida no init())
    public static $BASE_URL = '';
    
    // Alias para URL base
    public const BASE_URL = ''; // Usar self::$BASE_URL
    
    // Diretórios
    public const BASE_PATH = __DIR__ . '/../..';
    public const ASSETS_PATH = self::BASE_PATH . '/assets';
    public const UPLOAD_PATH = self::BASE_PATH . '/uploads';
    public const VIEWS_PATH = self::BASE_PATH . '/src/Views';
    
    // Uploads
    public const MAX_UPLOAD_SIZE = 10485760; // 10MB
    public const MAX_BANNER_SIZE = 5242880; // 5MB
    public const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    public const THUMB_WIDTH = 400;
    public const THUMB_HEIGHT = 300;
    
    // Sessão
    public const SESSION_LIFETIME = 86400; // 24 horas
    public const SESSION_NAME = 'acf_session';
    
    // Paginação
    public const POSTS_PER_PAGE = 12;
    public const POSTS_HOME_FEATURED = 5;
    public const POSTS_HOME_RECENT = 12;
    public const ADMIN_ITEMS_PER_PAGE = 20;
    public const COMMENTS_PER_PAGE = 10;
    
    // Cache
    public const CACHE_ENABLED = true;
    public const CACHE_LIFETIME = 3600; // 1 hora
    
    // Email (configurar em produção)
    public const SMTP_HOST = '';
    public const SMTP_PORT = 587;
    public const SMTP_USER = '';
    public const SMTP_PASS = '';
    public const SMTP_FROM = 'noreply@acidadefala.com.br';
    public const SMTP_FROM_NAME = 'A Cidade Fala';
    
    // Moderação
    public const AUTO_APPROVE_POSTS = false;
    public const AUTO_APPROVE_COMMENTS = false;
    public const AUTO_APPROVE_ADS = false;
    public const MIN_CONTENT_LENGTH = 100;
    public const MAX_TITLE_LENGTH = 200;
    
    // Monetização (valores em R$)
    public const DESTAQUE_VALOR_DIA = 15.00;
    public const DESTAQUE_VALOR_SEMANA = 80.00;
    public const DESTAQUE_VALOR_MES = 250.00;
    
    public const ANUNCIO_TOPO_DIA = 50.00;
    public const ANUNCIO_TOPO_SEMANA = 280.00;
    public const ANUNCIO_TOPO_MES = 900.00;
    
    public const ANUNCIO_SIDEBAR_DIA = 30.00;
    public const ANUNCIO_SIDEBAR_SEMANA = 170.00;
    public const ANUNCIO_SIDEBAR_MES = 550.00;
    
    public const ANUNCIO_INLINE_DIA = 20.00;
    public const ANUNCIO_INLINE_SEMANA = 110.00;
    public const ANUNCIO_INLINE_MES = 350.00;
    
    public const ANUNCIO_RODAPE_DIA = 15.00;
    public const ANUNCIO_RODAPE_SEMANA = 85.00;
    public const ANUNCIO_RODAPE_MES = 270.00;
    
    // Dimensões de Banners (em pixels)
    public const BANNER_TOPO_WIDTH = 970;
    public const BANNER_TOPO_HEIGHT = 90;
    public const BANNER_SIDEBAR_WIDTH = 300;
    public const BANNER_SIDEBAR_HEIGHT = 250;
    public const BANNER_INLINE_WIDTH = 728;
    public const BANNER_INLINE_HEIGHT = 90;
    public const BANNER_RODAPE_WIDTH = 970;
    public const BANNER_RODAPE_HEIGHT = 90;
    
    // Gateway de Pagamento
    public const PAYMENT_GATEWAY = 'manual'; // manual, mercadopago, pagseguro, stripe
    public const PAYMENT_SANDBOX = true;
    
    // Cookies
    public const COOKIE_CITY = 'acf_city';
    public const COOKIE_THEME = 'acf_theme';
    public const COOKIE_LIFETIME = 2592000; // 30 dias
    
    // Timezone
    public const TIMEZONE = 'America/Sao_Paulo';
    
    // Debug (DESATIVAR EM PRODUÇÃO)
    public const DEBUG_MODE = true;
    public const ERROR_REPORTING = E_ALL;
    
    // Redes Sociais
    public const SOCIAL_FACEBOOK = '';
    public const SOCIAL_INSTAGRAM = '';
    public const SOCIAL_TWITTER = '';
    public const SOCIAL_YOUTUBE = '';
    public const SOCIAL_WHATSAPP = '';
    
    // Categorias Padrão
    public const CATEGORIES = [
        1 => ['nome' => 'Política', 'slug' => 'politica', 'icon' => '🏛️', 'color' => '#1e40af'],
        2 => ['nome' => 'Saúde', 'slug' => 'saude', 'icon' => '🏥', 'color' => '#059669'],
        3 => ['nome' => 'Educação', 'slug' => 'educacao', 'icon' => '📚', 'color' => '#7c3aed'],
        4 => ['nome' => 'Segurança', 'slug' => 'seguranca', 'icon' => '🚔', 'color' => '#dc2626'],
        5 => ['nome' => 'Infraestrutura', 'slug' => 'infraestrutura', 'icon' => '🏗️', 'color' => '#d97706'],
        6 => ['nome' => 'Meio Ambiente', 'slug' => 'meio-ambiente', 'icon' => '🌳', 'color' => '#16a34a'],
        7 => ['nome' => 'Cultura', 'slug' => 'cultura', 'icon' => '🎭', 'color' => '#db2777'],
        8 => ['nome' => 'Esportes', 'slug' => 'esportes', 'icon' => '⚽', 'color' => '#0891b2'],
        9 => ['nome' => 'Economia', 'slug' => 'economia', 'icon' => '💰', 'color' => '#65a30d'],
        10 => ['nome' => 'Tecnologia', 'slug' => 'tecnologia', 'icon' => '💻', 'color' => '#6366f1'],
        11 => ['nome' => 'Entretenimento', 'slug' => 'entretenimento', 'icon' => '🎬', 'color' => '#f43f5e'],
        12 => ['nome' => 'Comunidade', 'slug' => 'comunidade', 'icon' => '👥', 'color' => '#8b5cf6'],
    ];
    
    /**
     * Obtém URL base do site
     */
    public static function getSiteUrl(): string {
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        return $protocol . $host . self::SUBDIR;
    }
    
    /**
     * Alias para getSiteUrl
     */
    public static function getBaseUrl(): string {
        return self::getSiteUrl();
    }
    
    /**
     * Obtém URL de asset
     */
    public static function asset(string $path): string {
        return self::getBaseUrl() . '/assets/' . ltrim($path, '/');
    }
    
    /**
     * Obtém URL de upload
     */
    public static function upload(string $path): string {
        return self::getBaseUrl() . '/uploads/' . ltrim($path, '/');
    }
    
    /**
     * Gera URL para uma rota
     */
    public static function url(string $path = ''): string {
        return self::getBaseUrl() . '/' . ltrim($path, '/');
    }
    
    /**
     * Obtém categoria por ID
     */
    public static function getCategory(int $id): ?array {
        return self::CATEGORIES[$id] ?? null;
    }
    
    /**
     * Obtém todas as categorias
     */
    public static function getCategories(): array {
        return self::CATEGORIES;
    }
    
    /**
     * Formata valor monetário
     */
    public static function formatMoney(float $value): string {
        return 'R$ ' . number_format($value, 2, ',', '.');
    }
    
    /**
     * Formata data para exibição
     */
    public static function formatDate(string $date, string $format = 'd/m/Y'): string {
        return date($format, strtotime($date));
    }
    
    /**
     * Formata data relativa (há X minutos, há X horas, etc)
     */
    public static function timeAgo(string $datetime): string {
        $time = strtotime($datetime);
        $diff = time() - $time;
        
        if ($diff < 60) {
            return 'agora mesmo';
        } elseif ($diff < 3600) {
            $mins = floor($diff / 60);
            return "há {$mins} " . ($mins == 1 ? 'minuto' : 'minutos');
        } elseif ($diff < 86400) {
            $hours = floor($diff / 3600);
            return "há {$hours} " . ($hours == 1 ? 'hora' : 'horas');
        } elseif ($diff < 604800) {
            $days = floor($diff / 86400);
            return "há {$days} " . ($days == 1 ? 'dia' : 'dias');
        } elseif ($diff < 2592000) {
            $weeks = floor($diff / 604800);
            return "há {$weeks} " . ($weeks == 1 ? 'semana' : 'semanas');
        } else {
            return self::formatDate($datetime, 'd/m/Y');
        }
    }
    
    /**
     * Inicializa configurações da aplicação
     */
    public static function init(): void {
        // Define BASE_URL dinamicamente
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        self::$BASE_URL = $protocol . $host;
        
        // Timezone
        date_default_timezone_set(self::TIMEZONE);
        
        // Error Reporting
        if (self::DEBUG_MODE) {
            error_reporting(self::ERROR_REPORTING);
            ini_set('display_errors', '1');
        } else {
            error_reporting(0);
            ini_set('display_errors', '0');
        }
        
        // Sessão
        if (session_status() === PHP_SESSION_NONE) {
            ini_set('session.cookie_httponly', '1');
            ini_set('session.use_strict_mode', '1');
            ini_set('session.cookie_samesite', 'Lax');
            ini_set('session.cookie_path', self::SUBDIR ?: '/');
            ini_set('session.gc_maxlifetime', (string)self::SESSION_LIFETIME);
            session_name(self::SESSION_NAME);
            session_start();
        }
        
        // Cria diretórios de upload se não existirem
        $dirs = [
            self::UPLOAD_PATH,
            self::UPLOAD_PATH . '/images',
            self::UPLOAD_PATH . '/images/thumbs',
            self::UPLOAD_PATH . '/banners',
        ];
        
        foreach ($dirs as $dir) {
            if (!file_exists($dir)) {
                @mkdir($dir, 0755, true);
            }
        }
    }
}
