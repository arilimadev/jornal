<?php
/**
 * A Cidade Fala v2.0 - Router Principal
 * Usa apenas API REST do Supabase
 */

namespace ACidadeFala;

use ACidadeFala\Config\Config;
use ACidadeFala\Config\Database;

class Router
{
    private $db;
    private $uri;
    private $method;
    private $segments;
    
    public function __construct()
    {
        $this->db = Database::getInstance();
        $this->method = $_SERVER['REQUEST_METHOD'];
        
        $this->uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $subdir = Config::SUBDIR;
        if ($subdir && strpos($this->uri, $subdir) === 0) {
            $this->uri = substr($this->uri, strlen($subdir));
        }
        $this->uri = '/' . trim($this->uri, '/');
        $this->segments = array_values(array_filter(explode('/', $this->uri)));
    }
    
    public function handle()
    {
        if (str_starts_with($this->uri, '/api/')) return $this->handleApi();
        if (str_starts_with($this->uri, '/admin')) return $this->handleAdmin();
        if (str_starts_with($this->uri, '/autor')) return $this->handleAuthor();
        return $this->handlePublic();
    }
    
    private function handlePublic()
    {
        // Home
        if ($this->uri === '/' || $this->uri === '') return $this->renderHome();
        
        // Auth
        if ($this->uri === '/login') return $this->renderLogin();
        if ($this->uri === '/registro') return $this->renderRegister();
        if ($this->uri === '/logout') return $this->logout();
        
        // Listagens por tipo
        if ($this->uri === '/noticias') return $this->renderListByType('noticia', 'Notícias');
        if ($this->uri === '/opinioes') return $this->renderListByType('opiniao', 'Opiniões');
        if ($this->uri === '/denuncias') return $this->renderListByType('denuncia', 'Denúncias');
        
        // Páginas
        if ($this->uri === '/sobre') return $this->renderAbout();
        if ($this->uri === '/contato') return $this->renderContact();
        if ($this->uri === '/termos') return $this->renderTerms();
        if ($this->uri === '/privacidade') return $this->renderPrivacy();
        if ($this->uri === '/anunciar') return $this->renderAnunciar();
        if ($this->uri === '/planos') return $this->renderAnunciar();
        
        // Cidade
        if ($this->uri === '/selecionar-cidade') return $this->renderSelectCity();
        if ($this->uri === '/definir-cidade') return $this->setCity();
        
        // Busca
        if ($this->uri === '/busca') return $this->renderSearch();
        
        // Banner click
        if (preg_match('#^/banner/click/(\d+)$#', $this->uri, $m)) return $this->handleBannerClick($m[1]);
        
        // Categoria
        if (preg_match('#^/categoria/([a-z0-9\-]+)$#', $this->uri, $m)) return $this->renderCategoria($m[1]);
        
        // Perfil
        if (preg_match('#^/perfil/(\d+)$#', $this->uri, $m)) return $this->renderAutorPublico($m[1]);
        
        $segments = $this->segments;
        
        // /UF (Estado)
        if (count($segments) === 1 && strlen($segments[0]) === 2 && ctype_alpha($segments[0])) {
            return $this->renderEstado(strtoupper($segments[0]));
        }
        
        // /UF/cidade
        if (count($segments) === 2 && strlen($segments[0]) === 2 && ctype_alpha($segments[0])) {
            return $this->renderCidade(strtoupper($segments[0]), $segments[1]);
        }
        
        // /UF/cidade/post
        if (count($segments) === 3 && strlen($segments[0]) === 2 && ctype_alpha($segments[0])) {
            return $this->renderPost(strtoupper($segments[0]), $segments[1], $segments[2]);
        }
        
        return $this->error404();
    }
    
    private function handleAdmin()
    {
        if (!$this->isAdmin()) {
            return $this->redirect(url('login?redirect=' . urlencode($_SERVER['REQUEST_URI'])));
        }
        
        $path = substr($this->uri, 6);
        $path = '/' . trim($path, '/');
        
        switch ($path) {
            case '/': case '': return $this->renderAdminDashboard();
            case '/moderacao': return $this->renderAdminModeracao();
            case '/usuarios': return $this->renderAdminUsuarios();
            case '/cidades': return $this->renderAdminCidades();
            case '/estados': return $this->renderAdminEstados();
            case '/bairros': return $this->renderAdminBairros();
            case '/banners': return $this->renderAdminBanners();
            case '/comentarios': return $this->renderAdminComentarios();
            case '/precos': return $this->renderAdminPrecos();
            case '/configuracoes': return $this->renderAdminConfiguracoes();
            case '/paginas': return $this->renderAdminPaginas();
            case '/relatorios': return $this->renderAdminRelatorios();
        }
        
        if (preg_match('#^/usuarios/(\d+|novo)$#', $path, $m)) {
            return $this->renderAdminUsuarioForm($m[1] === 'novo' ? null : $m[1]);
        }
        
        return $this->error404();
    }
    
    private function handleAuthor()
    {
        if (!$this->isLoggedIn()) {
            return $this->redirect(url('login?redirect=' . urlencode($_SERVER['REQUEST_URI'])));
        }
        
        $path = substr($this->uri, 6);
        $path = '/' . trim($path, '/');
        
        switch ($path) {
            case '/': case '': return $this->renderAuthorDashboard();
            case '/publicar': return $this->renderAuthorPostCreate();
            case '/posts': return $this->renderAuthorPosts();
            case '/verificacao': return $this->renderAuthorVerificacao();
            case '/anunciar': return $this->renderAuthorAnunciar();
            case '/perfil': return $this->renderAuthorPerfil();
        }
        
        if (preg_match('#^/editar/(\d+)$#', $path, $m)) {
            return $this->renderAuthorPostEdit($m[1]);
        }
        
        return $this->error404();
    }
    
    private function handleApi()
    {
        header('Content-Type: application/json');
        
        $path = substr($this->uri, 4);
        $path = '/' . trim($path, '/');
        
        try {
            if ($path === '/login' && $this->method === 'POST') return $this->apiLogin();
            if ($path === '/register' && $this->method === 'POST') return $this->apiRegister();
            if ($path === '/estados') return $this->apiGetEstados();
            if ($path === '/cidades') return $this->apiGetCidades();
            if ($path === '/bairros') return $this->apiGetBairros();
            if ($path === '/categorias') return $this->apiGetCategorias();
            if ($path === '/posts' && $this->method === 'POST') return $this->apiCreatePost();
            if ($path === '/comentario' && $this->method === 'POST') return $this->apiCreateComentario();
            if ($path === '/denuncia' && $this->method === 'POST') return $this->apiCreateDenuncia();
            if ($path === '/newsletter' && $this->method === 'POST') return $this->apiNewsletter();
            if ($path === '/contato' && $this->method === 'POST') return $this->apiContato();
            
            if (str_starts_with($path, '/admin/')) {
                if (!$this->isAdmin()) return $this->json(['success' => false, 'error' => 'Não autorizado'], 403);
                return $this->handleAdminApi($path);
            }
            
            return $this->json(['success' => false, 'error' => 'Rota não encontrada'], 404);
        } catch (\Exception $e) {
            return $this->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }
    
    private function handleAdminApi($path)
    {
        if (preg_match('#^/admin/post/(\d+)/aprovar$#', $path, $m)) return $this->apiAdminAprovarPost($m[1]);
        if (preg_match('#^/admin/post/(\d+)/rejeitar$#', $path, $m)) return $this->apiAdminRejeitarPost($m[1]);
        if (preg_match('#^/admin/post/(\d+)$#', $path, $m) && $this->method === 'GET') return $this->apiAdminGetPost($m[1]);
        if (preg_match('#^/admin/comentario/(\d+)/aprovar$#', $path, $m)) return $this->apiAdminAprovarComentario($m[1]);
        if (preg_match('#^/admin/comentario/(\d+)$#', $path, $m) && $this->method === 'DELETE') return $this->apiAdminDeleteComentario($m[1]);
        if ($path === '/admin/usuario' && $this->method === 'POST') return $this->apiAdminCreateUsuario();
        if (preg_match('#^/admin/usuario/(\d+)$#', $path, $m) && $this->method === 'PUT') return $this->apiAdminUpdateUsuario($m[1]);
        if (preg_match('#^/admin/usuario/(\d+)/(ativar|desativar)$#', $path, $m)) return $this->apiAdminToggleUsuario($m[1], $m[2] === 'ativar');
        if ($path === '/admin/cidade' && $this->method === 'POST') return $this->apiAdminCreateCidade();
        if (preg_match('#^/admin/cidade/(\d+)$#', $path, $m) && $this->method === 'PUT') return $this->apiAdminUpdateCidade($m[1]);
        if (preg_match('#^/admin/cidade/(\d+)$#', $path, $m) && $this->method === 'DELETE') return $this->apiAdminDeleteCidade($m[1]);
        if ($path === '/admin/bairro' && $this->method === 'POST') return $this->apiAdminCreateBairro();
        if (preg_match('#^/admin/bairro/(\d+)$#', $path, $m) && $this->method === 'PUT') return $this->apiAdminUpdateBairro($m[1]);
        if (preg_match('#^/admin/bairro/(\d+)$#', $path, $m) && $this->method === 'DELETE') return $this->apiAdminDeleteBairro($m[1]);
        if ($path === '/admin/configuracoes' && $this->method === 'POST') return $this->apiAdminSaveConfig();
        return $this->json(['success' => false, 'error' => 'Rota não encontrada'], 404);
    }
    
    // ==================== RENDERS ====================
    
    private function renderHome()
    {
        $posts = $this->db->select('posts', ['status' => 'aprovado'], 20, 0, ['created_at' => 'DESC']);
        $categorias = $this->db->select('categorias', ['ativo' => true], null, 0, ['ordem' => 'ASC']);
        $destaques = $this->db->select('posts', ['status' => 'aprovado', 'destaque' => true], 5, 0, ['created_at' => 'DESC']);
        return $this->view('public/home', ['posts' => $posts, 'categorias' => $categorias, 'destaques' => $destaques]);
    }
    
    private function renderLogin()
    {
        if ($this->isLoggedIn()) return $this->redirect(url('autor'));
        return $this->view('public/login', []);
    }
    
    private function renderRegister()
    {
        if ($this->isLoggedIn()) return $this->redirect(url('autor'));
        $estados = $this->db->select('estados', ['ativo' => true], null, 0, ['nome' => 'ASC']);
        return $this->view('public/register', ['estados' => $estados]);
    }
    
    private function renderListByType($tipo, $titulo)
    {
        $page = max(1, intval($_GET['page'] ?? 1));
        $perPage = 12;
        $offset = ($page - 1) * $perPage;
        $posts = $this->db->select('posts', ['status' => 'aprovado', 'tipo' => $tipo], $perPage, $offset, ['created_at' => 'DESC']);
        $total = $this->db->count('posts', ['status' => 'aprovado', 'tipo' => $tipo]);
        return $this->view('public/list', ['posts' => $posts, 'titulo' => $titulo, 'tipo' => $tipo, 'page' => $page, 'totalPages' => ceil($total / $perPage), 'total' => $total]);
    }
    
    private function renderAbout()
    {
        $pagina = $this->db->select('paginas', ['slug' => 'sobre'], 1);
        $pagina = $pagina[0] ?? ['titulo' => 'Sobre Nós', 'conteudo' => '<p>O <strong>A Cidade Fala</strong> é um portal de jornalismo colaborativo que dá voz aos cidadãos.</p>'];
        return $this->view('public/about', ['pagina' => $pagina]);
    }
    
    private function renderContact() { return $this->view('public/contact', []); }
    
    private function renderTerms()
    {
        $termo = $this->db->select('termos', ['tipo' => 'uso', 'ativo' => true], 1);
        $termo = $termo[0] ?? ['titulo' => 'Termos de Uso', 'conteudo' => '<p>Em construção.</p>'];
        return $this->view('public/terms', ['termo' => $termo]);
    }
    
    private function renderPrivacy()
    {
        $termo = $this->db->select('termos', ['tipo' => 'privacidade', 'ativo' => true], 1);
        $termo = $termo[0] ?? ['titulo' => 'Política de Privacidade', 'conteudo' => '<p>Em construção.</p>'];
        return $this->view('public/privacy', ['termo' => $termo]);
    }
    
    private function renderAnunciar()
    {
        $posicoes = $this->db->select('banner_posicoes', ['ativo' => true]);
        $bannerPrecos = $this->db->select('banner_precos', ['ativo' => true]);
        $destaquePrecos = $this->db->select('destaque_precos', ['ativo' => true]);
        return $this->view('public/anunciar', ['posicoes' => $posicoes, 'bannerPrecos' => $bannerPrecos, 'destaquePrecos' => $destaquePrecos]);
    }
    
    private function renderSelectCity()
    {
        $estados = $this->db->select('estados', ['ativo' => true], null, 0, ['nome' => 'ASC']);
        return $this->view('public/select-city', ['estados' => $estados]);
    }
    
    private function renderSearch()
    {
        $query = trim($_GET['q'] ?? '');
        $posts = [];
        if (strlen($query) >= 3) {
            $posts = $this->db->search('posts', 'titulo', $query, 50, ['created_at' => 'DESC']);
            $posts = array_filter($posts, fn($p) => ($p['status'] ?? '') === 'aprovado');
        }
        return $this->view('public/search', ['query' => $query, 'posts' => array_values($posts)]);
    }
    
    private function renderEstado($uf)
    {
        $estado = $this->db->select('estados', ['uf' => $uf, 'ativo' => true], 1);
        if (empty($estado)) return $this->error404();
        $estado = $estado[0];
        $cidades = $this->db->select('cidades', ['estado_id' => $estado['id'], 'ativo' => true], null, 0, ['nome' => 'ASC']);
        $posts = $this->db->select('posts', ['estado_id' => $estado['id'], 'status' => 'aprovado'], 20, 0, ['created_at' => 'DESC']);
        return $this->view('public/estado', ['estado' => $estado, 'cidades' => $cidades, 'posts' => $posts]);
    }
    
    private function renderCidade($uf, $cidadeSlug)
    {
        $estado = $this->db->select('estados', ['uf' => $uf], 1);
        if (empty($estado)) return $this->error404();
        $estado = $estado[0];
        $cidade = $this->db->select('cidades', ['slug' => $cidadeSlug, 'estado_id' => $estado['id'], 'ativo' => true], 1);
        if (empty($cidade)) return $this->error404();
        $cidade = $cidade[0];
        $tipo = $_GET['tipo'] ?? null;
        $where = ['cidade_id' => $cidade['id'], 'status' => 'aprovado'];
        if ($tipo && in_array($tipo, ['noticia', 'opiniao', 'denuncia'])) $where['tipo'] = $tipo;
        $page = max(1, intval($_GET['page'] ?? 1));
        $perPage = 12;
        $offset = ($page - 1) * $perPage;
        $posts = $this->db->select('posts', $where, $perPage, $offset, ['destaque' => 'DESC', 'created_at' => 'DESC']);
        $total = $this->db->count('posts', $where);
        $categorias = $this->db->select('categorias', ['ativo' => true], null, 0, ['ordem' => 'ASC']);
        return $this->view('public/cidade', ['estado' => $estado, 'cidade' => $cidade, 'posts' => $posts, 'categorias' => $categorias, 'page' => $page, 'totalPages' => ceil($total / $perPage), 'maisLidas' => [], 'rankingAutores' => []]);
    }
    
    private function renderPost($uf, $cidadeSlug, $postSlug)
    {
        $estado = $this->db->select('estados', ['uf' => $uf], 1);
        if (empty($estado)) return $this->error404();
        $estado = $estado[0];
        $cidade = $this->db->select('cidades', ['slug' => $cidadeSlug, 'estado_id' => $estado['id']], 1);
        if (empty($cidade)) return $this->error404();
        $cidade = $cidade[0];
        $post = $this->db->select('posts', ['slug' => $postSlug, 'cidade_id' => $cidade['id'], 'status' => 'aprovado'], 1);
        if (empty($post)) return $this->error404();
        $post = $post[0];
        $this->db->update('posts', ['visualizacoes' => ($post['visualizacoes'] ?? 0) + 1], ['id' => $post['id']]);
        $autor = null;
        if (!empty($post['usuario_id'])) { $autor = $this->db->select('usuarios', ['id' => $post['usuario_id']], 1); $autor = $autor[0] ?? null; }
        $categoria = null;
        if (!empty($post['categoria_id'])) { $categoria = $this->db->select('categorias', ['id' => $post['categoria_id']], 1); $categoria = $categoria[0] ?? null; }
        $comentarios = $this->db->select('comentarios', ['post_id' => $post['id'], 'aprovado' => true], null, 0, ['created_at' => 'DESC']);
        $relacionados = $this->db->select('posts', ['cidade_id' => $cidade['id'], 'status' => 'aprovado'], 5, 0, ['created_at' => 'DESC']);
        $relacionados = array_filter($relacionados, fn($p) => $p['id'] != $post['id']);
        return $this->view('public/post', ['post' => $post, 'autor' => $autor, 'categoria' => $categoria, 'estado' => $estado, 'cidade' => $cidade, 'comentarios' => $comentarios, 'relacionados' => array_values(array_slice($relacionados, 0, 4))]);
    }
    
    private function renderCategoria($slug)
    {
        $categoria = $this->db->select('categorias', ['slug' => $slug, 'ativo' => true], 1);
        if (empty($categoria)) return $this->error404();
        $categoria = $categoria[0];
        $page = max(1, intval($_GET['page'] ?? 1));
        $perPage = 12;
        $offset = ($page - 1) * $perPage;
        $posts = $this->db->select('posts', ['categoria_id' => $categoria['id'], 'status' => 'aprovado'], $perPage, $offset, ['created_at' => 'DESC']);
        $total = $this->db->count('posts', ['categoria_id' => $categoria['id'], 'status' => 'aprovado']);
        return $this->view('public/categoria', ['categoria' => $categoria, 'posts' => $posts, 'page' => $page, 'totalPages' => ceil($total / $perPage)]);
    }
    
    private function renderAutorPublico($id)
    {
        $autor = $this->db->select('usuarios', ['id' => $id, 'ativo' => true], 1);
        if (empty($autor)) return $this->error404();
        $autor = $autor[0];
        $posts = $this->db->select('posts', ['usuario_id' => $id, 'status' => 'aprovado'], 20, 0, ['created_at' => 'DESC']);
        return $this->view('public/autor', ['autor' => $autor, 'posts' => $posts, 'stats' => ['total_posts' => count($posts), 'membro_desde' => date('Y', strtotime($autor['created_at'] ?? 'now'))]]);
    }
    
    // ==================== ADMIN RENDERS ====================
    
    private function renderAdminDashboard()
    {
        $stats = [
            'posts_total' => $this->db->count('posts', ['status' => 'aprovado']),
            'posts_pendentes' => $this->db->count('posts', ['status' => 'pendente']),
            'usuarios_total' => $this->db->count('usuarios', ['ativo' => true]),
            'comentarios_pendentes' => $this->db->count('comentarios', ['aprovado' => false])
        ];
        $pendingPosts = $this->db->select('posts', ['status' => 'pendente'], 10, 0, ['created_at' => 'DESC']);
        $recentUsers = $this->db->select('usuarios', [], 5, 0, ['created_at' => 'DESC']);
        return $this->view('admin/dashboard', ['stats' => $stats, 'pendingPosts' => $pendingPosts, 'pendingPostsList' => $pendingPosts, 'recentUsers' => $recentUsers, 'pendingComments' => []]);
    }
    
    private function renderAdminModeracao()
    {
        $status = $_GET['status'] ?? 'pendente';
        $where = $status !== 'todos' ? ['status' => $status] : [];
        $posts = $this->db->select('posts', $where, 50, 0, ['created_at' => 'DESC']);
        $cidades = $this->db->select('cidades', ['ativo' => true], null, 0, ['nome' => 'ASC']);
        return $this->view('admin/moderacao', ['posts' => $posts, 'pendingPosts' => $posts, 'cidades' => $cidades, 'stats' => ['pendentes' => $this->db->count('posts', ['status' => 'pendente'])]]);
    }
    
    private function renderAdminUsuarios()
    {
        $tipo = $_GET['tipo'] ?? null;
        $where = $tipo ? ['tipo' => $tipo] : [];
        $usuarios = $this->db->select('usuarios', $where, 100, 0, ['created_at' => 'DESC']);
        return $this->view('admin/usuarios', ['usuarios' => $usuarios, 'stats' => ['total' => count($usuarios), 'autores' => $this->db->count('usuarios', ['tipo' => 'autor']), 'moderadores' => $this->db->count('usuarios', ['tipo' => 'moderador']), 'anunciantes' => $this->db->count('usuarios', ['tipo' => 'anunciante'])]]);
    }
    
    private function renderAdminUsuarioForm($id)
    {
        $usuario = $id ? ($this->db->select('usuarios', ['id' => $id], 1)[0] ?? null) : null;
        $cidades = $this->db->select('cidades', ['ativo' => true], null, 0, ['nome' => 'ASC']);
        return $this->view('admin/usuario-form', ['usuario' => $usuario, 'cidades' => $cidades]);
    }
    
    private function renderAdminCidades()
    {
        $estados = $this->db->select('estados', [], null, 0, ['nome' => 'ASC']);
        $cidades = $this->db->select('cidades', [], null, 0, ['nome' => 'ASC']);
        return $this->view('admin/cidades', ['estados' => $estados, 'cidades' => $cidades]);
    }
    
    private function renderAdminEstados() { return $this->view('admin/estados', ['estados' => $this->db->select('estados', [], null, 0, ['nome' => 'ASC'])]); }
    
    private function renderAdminBairros()
    {
        $cidades = $this->db->select('cidades', ['ativo' => true], null, 0, ['nome' => 'ASC']);
        $bairros = $this->db->select('bairros', [], null, 0, ['nome' => 'ASC']);
        return $this->view('admin/bairros', ['cidades' => $cidades, 'bairros' => $bairros]);
    }
    
    private function renderAdminBanners()
    {
        $status = $_GET['status'] ?? 'pendente';
        $where = $status !== 'todos' ? ['status' => $status] : [];
        $banners = $this->db->select('banners', $where, null, 0, ['created_at' => 'DESC']);
        return $this->view('admin/banners', ['banners' => $banners, 'stats' => ['pendentes' => $this->db->count('banners', ['status' => 'pendente']), 'ativos' => $this->db->count('banners', ['status' => 'ativo'])]]);
    }
    
    private function renderAdminComentarios()
    {
        $status = $_GET['status'] ?? 'pendente';
        $where = $status === 'pendente' ? ['aprovado' => false] : ($status === 'aprovado' ? ['aprovado' => true] : []);
        $comentarios = $this->db->select('comentarios', $where, 100, 0, ['created_at' => 'DESC']);
        return $this->view('admin/comentarios', ['comentarios' => $comentarios, 'stats' => ['total' => $this->db->count('comentarios', []), 'pendentes' => $this->db->count('comentarios', ['aprovado' => false]), 'aprovados' => $this->db->count('comentarios', ['aprovado' => true]), 'hoje' => 0]]);
    }
    
    private function renderAdminPrecos()
    {
        return $this->view('admin/precos', ['bannerPrecos' => $this->db->select('banner_precos', []), 'destaquePrecos' => $this->db->select('destaque_precos', []), 'posicoes' => $this->db->select('banner_posicoes', ['ativo' => true])]);
    }
    
    private function renderAdminConfiguracoes() { return $this->view('admin/configuracoes', ['configuracoes' => $this->db->select('configuracoes', [])]); }
    
    private function renderAdminPaginas()
    {
        return $this->view('admin/paginas', ['paginas' => $this->db->select('paginas', []), 'termos' => $this->db->select('termos', ['ativo' => true])]);
    }
    
    private function renderAdminRelatorios() { return $this->view('admin/relatorios', ['stats' => [], 'topCidades' => [], 'topCategorias' => [], 'topAutores' => [], 'topPosts' => []]); }
    
    // ==================== AUTHOR RENDERS ====================
    
    private function renderAuthorDashboard()
    {
        $userId = $_SESSION['user_id'];
        $posts = $this->db->select('posts', ['usuario_id' => $userId], 10, 0, ['created_at' => 'DESC']);
        return $this->view('author/dashboard', ['stats' => ['total_posts' => $this->db->count('posts', ['usuario_id' => $userId]), 'posts_aprovados' => $this->db->count('posts', ['usuario_id' => $userId, 'status' => 'aprovado']), 'posts_pendentes' => $this->db->count('posts', ['usuario_id' => $userId, 'status' => 'pendente']), 'total_views' => 0], 'posts' => $posts]);
    }
    
    private function renderAuthorPostCreate()
    {
        return $this->view('author/post-create', ['estados' => $this->db->select('estados', ['ativo' => true], null, 0, ['nome' => 'ASC']), 'categorias' => $this->db->select('categorias', ['ativo' => true], null, 0, ['ordem' => 'ASC'])]);
    }
    
    private function renderAuthorPosts() { return $this->view('author/posts', ['posts' => $this->db->select('posts', ['usuario_id' => $_SESSION['user_id']], null, 0, ['created_at' => 'DESC'])]); }
    
    private function renderAuthorPostEdit($id)
    {
        $post = $this->db->select('posts', ['id' => $id, 'usuario_id' => $_SESSION['user_id']], 1);
        if (empty($post)) return $this->error404();
        return $this->view('author/post-create', ['post' => $post[0], 'estados' => $this->db->select('estados', ['ativo' => true], null, 0, ['nome' => 'ASC']), 'categorias' => $this->db->select('categorias', ['ativo' => true], null, 0, ['ordem' => 'ASC'])]);
    }
    
    private function renderAuthorVerificacao() { return $this->view('author/verificacao', ['usuario' => ($this->db->select('usuarios', ['id' => $_SESSION['user_id']], 1)[0] ?? [])]); }
    
    private function renderAuthorAnunciar()
    {
        $userId = $_SESSION['user_id'];
        $banners = $this->db->select('banners', ['anunciante_id' => $userId]);
        return $this->view('author/anunciar', ['usuario' => ($this->db->select('usuarios', ['id' => $userId], 1)[0] ?? []), 'banners' => $banners, 'destaques' => $this->db->select('destaques', ['usuario_id' => $userId]), 'meusPosts' => $this->db->select('posts', ['usuario_id' => $userId, 'status' => 'aprovado']), 'posicoes' => $this->db->select('banner_posicoes', ['ativo' => true]), 'cidades' => $this->db->select('cidades', ['ativo' => true], null, 0, ['nome' => 'ASC']), 'stats' => ['banners_ativos' => count(array_filter($banners, fn($b) => $b['status'] === 'ativo')), 'impressoes_total' => 0, 'cliques_total' => 0]]);
    }
    
    private function renderAuthorPerfil() { return $this->view('author/perfil', ['usuario' => ($this->db->select('usuarios', ['id' => $_SESSION['user_id']], 1)[0] ?? [])]); }
    
    // ==================== API METHODS ====================
    
    private function apiLogin()
    {
        $data = $this->getJsonInput();
        $email = trim($data['email'] ?? '');
        $senha = $data['senha'] ?? '';
        if (!$email || !$senha) return $this->json(['success' => false, 'error' => 'Preencha todos os campos']);
        $auth = new \ACidadeFala\Config\SupabaseAuth();
        $result = $auth->signIn($email, $senha);
        if (!$result['success']) return $this->json(['success' => false, 'error' => $result['error'] ?? 'Credenciais inválidas']);
        $users = $this->db->select('usuarios', ['email' => $email], 1);
        if (empty($users)) return $this->json(['success' => false, 'error' => 'Usuário não encontrado']);
        $user = $users[0];
        if (!$user['ativo']) return $this->json(['success' => false, 'error' => 'Conta desativada']);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_nome'] = $user['nome'];
        $_SESSION['user_tipo'] = $user['tipo'];
        return $this->json(['success' => true, 'redirect' => url($user['tipo'] === 'admin' ? 'admin' : 'autor')]);
    }
    
    private function apiRegister()
    {
        $data = $this->getJsonInput();
        $nome = trim($data['nome'] ?? '');
        $email = trim($data['email'] ?? '');
        $senha = $data['senha'] ?? '';
        if (!$nome || !$email || !$senha) return $this->json(['success' => false, 'error' => 'Preencha todos os campos']);
        if (strlen($senha) < 6) return $this->json(['success' => false, 'error' => 'A senha deve ter pelo menos 6 caracteres']);
        $existing = $this->db->select('usuarios', ['email' => $email], 1);
        if (!empty($existing)) return $this->json(['success' => false, 'error' => 'Este email já está cadastrado']);
        $auth = new \ACidadeFala\Config\SupabaseAuth();
        $result = $auth->signUp($email, $senha);
        if (!$result['success']) return $this->json(['success' => false, 'error' => $result['error'] ?? 'Erro ao criar conta']);
        $this->db->insert('usuarios', ['auth_id' => $result['user_id'] ?? null, 'email' => $email, 'nome' => $nome, 'tipo' => 'autor', 'ativo' => true, 'termos_aceitos' => true, 'termos_aceitos_em' => date('c')]);
        return $this->json(['success' => true, 'message' => 'Conta criada! Faça login para continuar.']);
    }
    
    private function apiGetEstados() { return $this->json(['success' => true, 'estados' => $this->db->select('estados', ['ativo' => true], null, 0, ['nome' => 'ASC'])]); }
    private function apiGetCidades() { $estadoId = $_GET['estado_id'] ?? null; $where = ['ativo' => true]; if ($estadoId) $where['estado_id'] = $estadoId; return $this->json(['success' => true, 'cidades' => $this->db->select('cidades', $where, null, 0, ['nome' => 'ASC'])]); }
    private function apiGetBairros() { $cidadeId = $_GET['cidade_id'] ?? null; if (!$cidadeId) return $this->json(['success' => false, 'error' => 'Cidade não informada']); return $this->json(['success' => true, 'bairros' => $this->db->select('bairros', ['cidade_id' => $cidadeId, 'ativo' => true], null, 0, ['nome' => 'ASC'])]); }
    private function apiGetCategorias() { return $this->json(['success' => true, 'categorias' => $this->db->select('categorias', ['ativo' => true], null, 0, ['ordem' => 'ASC'])]); }
    
    private function apiCreatePost()
    {
        if (!$this->isLoggedIn()) return $this->json(['success' => false, 'error' => 'Não autorizado'], 403);
        $titulo = trim($_POST['titulo'] ?? '');
        $conteudo = $_POST['conteudo'] ?? '';
        $cidadeId = intval($_POST['cidade_id'] ?? 0);
        if (!$titulo || !$conteudo || !$cidadeId) return $this->json(['success' => false, 'error' => 'Preencha os campos obrigatórios']);
        $cidade = $this->db->select('cidades', ['id' => $cidadeId], 1);
        if (empty($cidade)) return $this->json(['success' => false, 'error' => 'Cidade inválida']);
        $cidade = $cidade[0];
        $slug = $this->slugify($titulo);
        $slugBase = $slug;
        $i = 1;
        while (!empty($this->db->select('posts', ['cidade_id' => $cidadeId, 'slug' => $slug], 1))) { $slug = $slugBase . '-' . $i++; }
        $imagemCapa = null;
        if (!empty($_FILES['imagem']['tmp_name'])) $imagemCapa = $this->uploadImage($_FILES['imagem']);
        $status = $_POST['status'] ?? 'pendente';
        if (!in_array($status, ['rascunho', 'pendente'])) $status = 'pendente';
        $this->db->insert('posts', ['usuario_id' => $_SESSION['user_id'], 'estado_id' => $cidade['estado_id'], 'cidade_id' => $cidadeId, 'bairro_id' => $_POST['bairro_id'] ?: null, 'categoria_id' => $_POST['categoria_id'] ?: null, 'tipo' => $_POST['tipo'] ?? 'noticia', 'titulo' => $titulo, 'subtitulo' => $_POST['subtitulo'] ?? null, 'slug' => $slug, 'conteudo' => $conteudo, 'imagem_capa' => $imagemCapa, 'anonimo' => isset($_POST['anonimo']), 'status' => $status, 'publicado_em' => $status === 'pendente' ? date('c') : null]);
        return $this->json(['success' => true, 'message' => 'Post criado!']);
    }
    
    private function apiCreateComentario()
    {
        $postId = intval($_POST['post_id'] ?? 0);
        $nome = trim($_POST['nome'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $conteudo = trim($_POST['conteudo'] ?? '');
        if (!$postId || !$nome || !$email || !$conteudo) return $this->json(['success' => false, 'error' => 'Preencha todos os campos']);
        $this->db->insert('comentarios', ['post_id' => $postId, 'usuario_id' => $_SESSION['user_id'] ?? null, 'nome' => $nome, 'email' => $email, 'conteudo' => $conteudo, 'ip' => $_SERVER['REMOTE_ADDR'] ?? null, 'aprovado' => false]);
        return $this->json(['success' => true, 'message' => 'Comentário enviado!']);
    }
    
    private function apiCreateDenuncia() { $data = $this->getJsonInput(); $this->db->insert('denuncias', ['post_id' => $data['post_id'] ?? null, 'comentario_id' => $data['comentario_id'] ?? null, 'motivo' => $data['motivo'] ?? '', 'ip' => $_SERVER['REMOTE_ADDR'] ?? null]); return $this->json(['success' => true]); }
    private function apiNewsletter() { $email = trim($_POST['email'] ?? ''); if (!$email) return $this->json(['success' => false, 'error' => 'Email inválido']); $this->db->insert('newsletter', ['email' => $email]); return $this->json(['success' => true, 'message' => 'Cadastrado!']); }
    private function apiContato() { $this->db->insert('contatos', ['nome' => $_POST['nome'] ?? '', 'email' => $_POST['email'] ?? '', 'assunto' => $_POST['assunto'] ?? '', 'mensagem' => $_POST['mensagem'] ?? '']); return $this->json(['success' => true, 'message' => 'Enviado!']); }
    
    private function apiAdminAprovarPost($id) { $this->db->update('posts', ['status' => 'aprovado', 'moderado_por' => $_SESSION['user_id'], 'moderado_em' => date('c'), 'publicado_em' => date('c')], ['id' => $id]); return $this->json(['success' => true]); }
    private function apiAdminRejeitarPost($id) { $data = $this->getJsonInput(); $this->db->update('posts', ['status' => 'rejeitado', 'moderado_por' => $_SESSION['user_id'], 'motivo_rejeicao' => $data['motivo'] ?? ''], ['id' => $id]); return $this->json(['success' => true]); }
    private function apiAdminGetPost($id) { $post = $this->db->select('posts', ['id' => $id], 1); return $this->json(['success' => true, 'post' => $post[0] ?? null]); }
    private function apiAdminAprovarComentario($id) { $this->db->update('comentarios', ['aprovado' => true], ['id' => $id]); return $this->json(['success' => true]); }
    private function apiAdminDeleteComentario($id) { $this->db->delete('comentarios', ['id' => $id]); return $this->json(['success' => true]); }
    private function apiAdminCreateUsuario() { $auth = new \ACidadeFala\Config\SupabaseAuth(); $result = $auth->signUp($_POST['email'], $_POST['senha']); if (!$result['success']) return $this->json(['success' => false, 'error' => $result['error'] ?? 'Erro']); $this->db->insert('usuarios', ['auth_id' => $result['user_id'] ?? null, 'email' => $_POST['email'], 'nome' => $_POST['nome'], 'tipo' => $_POST['tipo'] ?? 'autor', 'ativo' => true]); return $this->json(['success' => true]); }
    private function apiAdminUpdateUsuario($id) { $this->db->update('usuarios', ['nome' => $_POST['nome'] ?? '', 'tipo' => $_POST['tipo'] ?? 'autor', 'ativo' => isset($_POST['ativo'])], ['id' => $id]); return $this->json(['success' => true]); }
    private function apiAdminToggleUsuario($id, $ativar) { $this->db->update('usuarios', ['ativo' => $ativar], ['id' => $id]); return $this->json(['success' => true]); }
    private function apiAdminCreateCidade() { $this->db->insert('cidades', ['estado_id' => $_POST['estado_id'], 'nome' => $_POST['nome'], 'slug' => $this->slugify($_POST['nome']), 'ativo' => true]); return $this->json(['success' => true]); }
    private function apiAdminUpdateCidade($id) { $this->db->update('cidades', ['estado_id' => $_POST['estado_id'], 'nome' => $_POST['nome'], 'slug' => $_POST['slug'] ?: $this->slugify($_POST['nome']), 'ativo' => isset($_POST['ativo'])], ['id' => $id]); return $this->json(['success' => true]); }
    private function apiAdminDeleteCidade($id) { $this->db->delete('cidades', ['id' => $id]); return $this->json(['success' => true]); }
    private function apiAdminCreateBairro() { $this->db->insert('bairros', ['cidade_id' => $_POST['cidade_id'], 'nome' => $_POST['nome'], 'slug' => $this->slugify($_POST['nome']), 'ativo' => true]); return $this->json(['success' => true]); }
    private function apiAdminUpdateBairro($id) { $this->db->update('bairros', ['cidade_id' => $_POST['cidade_id'], 'nome' => $_POST['nome'], 'slug' => $_POST['slug'] ?: $this->slugify($_POST['nome']), 'ativo' => isset($_POST['ativo'])], ['id' => $id]); return $this->json(['success' => true]); }
    private function apiAdminDeleteBairro($id) { $this->db->delete('bairros', ['id' => $id]); return $this->json(['success' => true]); }
    private function apiAdminSaveConfig() { foreach ($_POST as $key => $value) { if (str_starts_with($key, 'config_')) { $this->db->upsert('configuracoes', ['chave' => substr($key, 7), 'valor' => $value], 'chave'); } } return $this->json(['success' => true]); }
    
    // ==================== HELPERS ====================
    
    private function view($name, $data = []) { extract($data); $viewPath = __DIR__ . '/Views/' . $name . '.php'; if (!file_exists($viewPath)) return $this->error404(); require $viewPath; }
    private function json($data, $statusCode = 200) { http_response_code($statusCode); echo json_encode($data); exit; }
    private function redirect($url) { header('Location: ' . $url); exit; }
    private function error404() { http_response_code(404); $this->view('errors/404'); exit; }
    private function isLoggedIn() { return isset($_SESSION['user_id']); }
    private function isAdmin() { return $this->isLoggedIn() && ($_SESSION['user_tipo'] ?? '') === 'admin'; }
    private function logout() { session_destroy(); $this->redirect(url('/')); }
    private function setCity() { $cidadeId = $_POST['cidade_id'] ?? $_GET['cidade_id'] ?? null; if ($cidadeId) setcookie('cidade_id', $cidadeId, time() + 365 * 24 * 60 * 60, '/'); $this->redirect(url($_POST['redirect'] ?? $_GET['redirect'] ?? '/')); }
    private function handleBannerClick($id) { $banner = $this->db->select('banners', ['id' => $id, 'status' => 'ativo'], 1); if (!empty($banner) && !empty($banner[0]['link_url'])) { $this->db->update('banners', ['cliques' => ($banner[0]['cliques'] ?? 0) + 1], ['id' => $id]); $this->redirect($banner[0]['link_url']); } $this->redirect(url('/')); }
    private function getJsonInput() { return json_decode(file_get_contents('php://input'), true) ?? $_POST; }
    private function slugify($text) { $text = preg_replace('/[^\pL\d]+/u', '-', $text); $text = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text); $text = preg_replace('/[^-\w]+/', '', $text); $text = trim($text, '-'); $text = preg_replace('/-+/', '-', $text); return strtolower($text) ?: 'n-a'; }
    private function uploadImage($file) { if (!in_array($file['type'], ['image/jpeg', 'image/png', 'image/webp', 'image/gif'])) return null; $ext = pathinfo($file['name'], PATHINFO_EXTENSION); $filename = uniqid() . '_' . time() . '.' . $ext; $uploadDir = __DIR__ . '/../uploads/images/'; if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true); if (move_uploaded_file($file['tmp_name'], $uploadDir . $filename)) return $filename; return null; }
}
