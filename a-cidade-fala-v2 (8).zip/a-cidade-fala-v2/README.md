# A Cidade Fala v2.0

Portal de jornalismo colaborativo local desenvolvido em PHP com Supabase.

## 📋 Visão Geral

O **A Cidade Fala** é uma plataforma que permite cidadãos publicarem notícias, opiniões e denúncias sobre sua cidade, promovendo o jornalismo cidadão e a transparência local.

## 🚀 Características

### Tipos de Conteúdo
- **Notícias**: Informações factuais sobre acontecimentos locais
- **Opiniões**: Artigos opinativos e editoriais
- **Denúncias**: Relatos de problemas que precisam de atenção (com opção de anonimato)

### Tipos de Usuários
- **Visitante**: Visualiza conteúdo público
- **Autor**: Publica notícias, opiniões e denúncias
- **Anunciante**: Gerencia anúncios e banners
- **Admin**: Modera conteúdo e gerencia o portal

### Funcionalidades
- ✅ Sistema multi-cidade
- ✅ Moderação de conteúdo
- ✅ Sistema de categorias
- ✅ Comentários moderados
- ✅ Sistema de anúncios com métricas
- ✅ Destaques pagos
- ✅ Newsletter
- ✅ Busca em tempo real
- ✅ Design responsivo
- ✅ Tema claro/escuro
- ✅ PWA-ready

## 🛠️ Tecnologias

- **Backend**: PHP 8.2+
- **Banco de Dados**: PostgreSQL (Supabase)
- **Autenticação**: Supabase Auth
- **Frontend**: HTML5, CSS3 (Custom Properties), JavaScript ES6+
- **Ícones**: Lucide Icons
- **Fontes**: Montserrat, Inter

## 📁 Estrutura do Projeto

```
a-cidade-fala-v2/
├── assets/
│   ├── css/
│   │   ├── variables.css    # Design system
│   │   ├── style.css        # Estilos principais
│   │   └── components.css   # Componentes
│   ├── js/
│   │   └── main.js          # JavaScript principal
│   └── images/
│       └── favicon.svg
├── database/
│   └── schema.sql           # Schema do banco
├── src/
│   ├── Config/
│   │   ├── Config.php       # Configurações
│   │   ├── Database.php     # Conexão Supabase
│   │   └── SupabaseAuth.php # Autenticação
│   ├── Controllers/         # (Inline no Router)
│   ├── Views/
│   │   ├── admin/           # Views do admin
│   │   ├── author/          # Views do autor
│   │   ├── advertiser/      # Views do anunciante
│   │   ├── public/          # Views públicas
│   │   ├── partials/        # Layout e componentes
│   │   └── errors/          # Páginas de erro
│   └── Router.php           # Roteamento
├── uploads/                 # Uploads de usuários
├── .htaccess               # Configuração Apache
├── index.php               # Entry point
└── README.md
```

## ⚙️ Instalação

### 1. Requisitos
- PHP 8.2 ou superior
- Extensões: curl, json, mbstring
- Apache com mod_rewrite
- Conta no Supabase

### 2. Configuração do Supabase

1. Crie um projeto no [Supabase](https://supabase.com)
2. Execute o arquivo `database/schema.sql` no SQL Editor
3. Copie as credenciais do projeto

### 3. Configuração do Projeto

1. Faça upload dos arquivos para seu servidor
2. Edite `src/Config/Database.php` com suas credenciais:

```php
private const SUPABASE_URL = 'https://SEU_PROJETO.supabase.co';
private const SUPABASE_ANON_KEY = 'sua_anon_key';
private const SUPABASE_SERVICE_KEY = 'sua_service_role_key';
```

3. Edite `src/Config/Config.php` se necessário:

```php
public const SITE_NAME = 'A Cidade Fala';
public const SITE_URL = 'https://seudominio.com.br';
```

4. Configure as permissões:
```bash
chmod 755 uploads/
chmod 755 uploads/images/
chmod 755 uploads/banners/
```

### 4. Criar Usuário Admin

1. Acesse `/registro` e crie uma conta
2. No Supabase, altere o tipo do usuário para 'admin':

```sql
UPDATE usuarios SET tipo = 'admin' WHERE email = 'seu@email.com';
```

## 🎨 Customização

### Cores
Edite `assets/css/variables.css`:
```css
:root {
    --color-primary: #1a365d;
    --color-secondary: #dc2626;
    --color-accent: #d97706;
}
```

### Categorias
Edite `src/Config/Config.php`:
```php
public const CATEGORIES = [
    1 => ['nome' => 'Política', 'slug' => 'politica', 'icon' => '🏛️', 'color' => '#1e40af'],
    // ...
];
```

### Preços
```php
public const HIGHLIGHT_PRICES = [
    '1_day' => 15.00,
    '7_days' => 50.00,
    // ...
];
```

## 📱 Páginas do Sistema

### Públicas (12)
- Home, Seletor de Cidade, Login, Registro
- Listagem (notícias, opiniões, denúncias)
- Visualização de post, Busca
- Sobre, Termos, Privacidade, Contato

### Autor (10)
- Dashboard, Meus Posts, Criar/Editar Post
- Comentários, Destaques, Perfil

### Anunciante (8)
- Dashboard, Meus Anúncios, Criar/Editar/Renovar
- Relatórios, Perfil

### Admin (12)
- Dashboard, Moderação, Gerenciar Posts
- Gerenciar Usuários, Anúncios, Cidades
- Financeiro, Logs, Configurações

## 🔒 Segurança

- Sanitização de inputs
- CSRF protection (via Supabase)
- Rate limiting no Supabase
- XSS prevention
- SQL injection prevention (API REST)
- Senhas hasheadas (Supabase Auth)

## 📊 Monetização

### Destaques de Posts
- 1 dia: R$ 15,00
- 7 dias: R$ 50,00
- 15 dias: R$ 90,00
- 30 dias: R$ 150,00
- Home (7 dias): R$ 250,00

### Anúncios
- Topo (970x90): R$ 300-900/mês
- Sidebar (300x250): R$ 150-450/mês
- Inline (728x90): R$ 200-600/mês
- Rodapé (970x90): R$ 100-300/mês

## 🤝 Suporte

Desenvolvido por **CTRL ADS**

---

© 2024 A Cidade Fala. Todos os direitos reservados.
